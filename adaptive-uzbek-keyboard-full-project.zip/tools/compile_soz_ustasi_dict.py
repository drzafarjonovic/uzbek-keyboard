import re
import struct
from pathlib import Path

"""
soz-ustasi.html faylidagi 100 816 so'zlik Tilmoch/O'zbek imlo lug'atini ajratib olib,
Unicode normalizatsiyasi (o‘/g‘ -> U+02BB, tutuq belgisi -> U+2019) va
Front-Coded DAWG binar indeksiga (uz_canonical_dawg.bin) kompilyatsiya qiluvchi skript.
"""

MODIFIER_TURNED_COMMA = "\u02BB"
RIGHT_SINGLE_QUOTE = "\u2019"
APOST_SET = {"'", "\u2018", "\u2019", "\u02BB", "\u02BC", "`", "\u00B4"}

def normalize_uzbek_word(w: str) -> str:
    w = w.strip().lower()
    out = []
    for i, ch in enumerate(w):
        if ch in APOST_SET:
            prev = w[i - 1] if i > 0 else ""
            out.append(MODIFIER_TURNED_COMMA if prev in ("o", "g") else RIGHT_SINGLE_QUOTE)
        else:
            out.append(ch)
    return "".join(out)

def compile_dictionary(html_path: Path, assets_dict_dir: Path):
    html_text = html_path.read_text(encoding="utf-8")
    match = re.search(r'window\.WORDLIST="([^"]+)";', html_text)
    if not match:
        raise ValueError("window.WORDLIST topilmadi!")
    raw_words = match.group(1).split("\\n")
    words = sorted({normalize_uzbek_word(w) for w in raw_words if len(w.strip()) >= 2})

    assets_dict_dir.mkdir(parents=True, exist_ok=True)
    (assets_dict_dir / "uz_lexicon_100k.txt").write_text("\n".join(words) + "\n", encoding="utf-8")

    with open(assets_dict_dir / "uz_canonical_dawg.bin", "wb") as bf:
        bf.write(b"UZDW")
        bf.write(struct.pack("<II", 1, len(words)))
        prev = b""
        for w in words:
            cur = w.encode("utf-8")
            common = 0
            limit = min(len(prev), len(cur), 255)
            while common < limit and prev[common] == cur[common]:
                common += 1
            suffix = cur[common:]
            bf.write(struct.pack("<BB", common, len(suffix)))
            bf.write(suffix)
            prev = cur
