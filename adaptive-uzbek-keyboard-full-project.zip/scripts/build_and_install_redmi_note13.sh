#!/usr/bin/env bash
set -euo pipefail

echo "=================================================================="
echo " Adaptive Uzbek Keyboard — Phase 7 Debug & Release APK Builder"
echo " Target Device: Xiaomi Redmi Note 13 (Snapdragon 685 / HyperOS)"
echo "=================================================================="

# 1. Agar release keystore mavjud bo'lmasa, avtomatik yaratish
KEYSTORE_FILE="adaptive-uzbek-release.jks"
if [ ! -f "$KEYSTORE_FILE" ]; then
    echo "[1/5] Generating Release Keystore ($KEYSTORE_FILE)..."
    keytool -genkeypair -v \
        -keystore "$KEYSTORE_FILE" \
        -alias adaptive_uzbek_key \
        -keyalg RSA \
        -keysize 2048 \
        -validity 10000 \
        -storepass UzbekKeyboard2026! \
        -keypass UzbekKeyboard2026! \
        -dname "CN=Adaptive Uzbek Keyboard, OU=Mobile NLP, O=UzbekIME, L=Namangan, ST=Namangan, C=UZ"

    cat > keystore.properties <<EOF
storeFile=$KEYSTORE_FILE
storePassword=UzbekKeyboard2026!
keyAlias=adaptive_uzbek_key
keyPassword=UzbekKeyboard2026!
EOF
fi

# 2. 12 ta majburiy JUnit testlarni ishga tushirish
echo "[2/5] Running Mandatory 12 Unit Tests (Phase 1-6)..."
./gradlew testDebugUnitTest

# 3. Debug va Release APK yig'ish
echo "[3/5] Building Debug & Release APKs..."
./gradlew assembleDebug assembleRelease

DEBUG_APK="app/build/outputs/apk/debug/app-debug.apk"
RELEASE_APK="app/build/outputs/apk/release/app-release.apk"

echo " -> Debug APK:   $DEBUG_APK"
echo " -> Release APK: $RELEASE_APK"

# 4. Agar Redmi Note 13 USB / Wireless Debugging orqali ulangan bo'lsa, avtomatik o'rnatish va yoqish
if command -v adb >/dev/null 2>&1 && [ "$(adb devices | grep -w 'device' | wc -l)" -gt 0 ]; then
    echo "[4/5] Redmi Note 13 detected via ADB! Installing Release APK..."
    adb install -r "$RELEASE_APK"
    echo "[5/5] Enabling and activating Adaptive Uzbek Keyboard IME..."
    adb shell ime enable uz.adaptive.keyboard/.ime.AdaptiveUzbekInputMethodService
    adb shell ime set uz.adaptive.keyboard/.ime.AdaptiveUzbekInputMethodService
    echo "SUCCESS: Adaptive Uzbek Keyboard is now active on your Redmi Note 13!"
else
    echo "[4/5] No ADB device connected. Copy $RELEASE_APK to your Redmi Note 13 and install."
fi
