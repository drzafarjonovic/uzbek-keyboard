# Adaptive Uzbek Keyboard — R8 / ProGuard Release Rules (Phase 7)
-optimizationpasses 5
-allowaccessmodification

# Keep Android InputMethodService entry point & SettingsActivity
-keep public class uz.adaptive.keyboard.ime.AdaptiveUzbekInputMethodService { *; }
-keep public class uz.adaptive.keyboard.ui.settings.SettingsActivity { *; }
-keep public class uz.adaptive.keyboard.ui.view.AdaptiveKeyboardView { *; }
-keep public class uz.adaptive.keyboard.ui.view.CandidateStripView { *; }

# Keep Room SQLite entities & DAOs for on-device personal dictionary
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao class * { *; }
-keep class uz.adaptive.keyboard.data.db.** { *; }

# Keep data models & enums
-keepclassmembers enum uz.adaptive.keyboard.** {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Strip verbose debug logs in Release APK for strict privacy
-assumenosideeffects class android.util.Log {
    public static int d(...);
    public static int v(...);
    public static int i(...);
}
