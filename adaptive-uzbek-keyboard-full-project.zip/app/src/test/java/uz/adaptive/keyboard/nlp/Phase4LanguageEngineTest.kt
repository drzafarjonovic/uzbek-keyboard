package uz.adaptive.keyboard.nlp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.model.ShiftState
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.MODIFIER_TURNED_COMMA
import java.io.File
import java.io.FileInputStream

/**
 * Phase 4 Multiscript Language Engine va `soz-ustasi.html` (100 816 so'z) lug'ati testlari.
 */
class Phase4LanguageEngineTest {

    private lateinit var predictiveEngine: PredictiveTextEngine

    @Before
    fun setUp() {
        val repo = SozUstasiDictionaryRepository()
        val dawgFile = File("src/main/assets/dict/uz_canonical_dawg.bin")
        if (dawgFile.exists()) {
            FileInputStream(dawgFile).use { repo.loadFromFrontCodedBinaryStream(it) }
        } else {
            repo.indexCanonicalWord("o${MODIFIER_TURNED_COMMA}zbekiston")
            repo.indexCanonicalWord("o${MODIFIER_TURNED_COMMA}zbek")
            repo.indexCanonicalWord("g${MODIFIER_TURNED_COMMA}alaba")
            repo.indexCanonicalWord("shahar")
            repo.indexCanonicalWord("chiroyli")
            repo.indexCanonicalWord("kitob")
        }
        predictiveEngine = PredictiveTextEngine(repo)
    }

    @Test
    fun testNewLatinConversionsAndPredictions() {
        val nl = predictiveEngine.newLatinEngine
        assertEquals("Özbekiston", nl.applyCasePattern(nl.fromCanonicalLexiconKey("o${MODIFIER_TURNED_COMMA}zbekiston"), "Ö", ShiftState.SINGLE_SHIFT))
        assertEquals("Ğalaba", nl.applyCasePattern(nl.fromCanonicalLexiconKey("g${MODIFIER_TURNED_COMMA}alaba"), "Ğ", ShiftState.SINGLE_SHIFT))
        assertEquals("Şahar", nl.applyCasePattern(nl.fromCanonicalLexiconKey("shahar"), "Ş", ShiftState.SINGLE_SHIFT))
        assertEquals("Çiroyli", nl.applyCasePattern(nl.fromCanonicalLexiconKey("chiroyli"), "Ç", ShiftState.SINGLE_SHIFT))

        val suggestions = predictiveEngine.getSuggestions("Özbek", null, ScriptType.NEW_LATIN, ShiftState.SINGLE_SHIFT)
        assertTrue("Yangi lotinda Özbekiston taklifi chiqishi shart", suggestions.any { it.startsWith("Özbek") })
    }

    @Test
    fun testTraditionalLatinApostropheVariantsNormalization() {
        val tl = predictiveEngine.traditionalLatinEngine
        val variants = listOf("O'zbekiston", "O\u2018zbekiston", "O\u2019zbekiston", "O\u02BBzbekiston")
        for (v in variants) {
            assertEquals("o${MODIFIER_TURNED_COMMA}zbekiston", tl.toCanonicalLexiconKey(v))
        }
    }

    @Test
    fun testCyrillicConversionsAndPredictions() {
        val cy = predictiveEngine.cyrillicEngine
        assertEquals("Ўзбекистон", cy.applyCasePattern(cy.fromCanonicalLexiconKey("o${MODIFIER_TURNED_COMMA}zbekiston"), "Ў", ShiftState.SINGLE_SHIFT))
        assertEquals("Ғалаба", cy.applyCasePattern(cy.fromCanonicalLexiconKey("g${MODIFIER_TURNED_COMMA}alaba"), "Ғ", ShiftState.SINGLE_SHIFT))
        assertEquals("Шаҳар", cy.applyCasePattern(cy.fromCanonicalLexiconKey("shahar"), "Ш", ShiftState.SINGLE_SHIFT))
        assertEquals("Чиройли", cy.applyCasePattern(cy.fromCanonicalLexiconKey("chiroyli"), "Ч", ShiftState.SINGLE_SHIFT))

        val suggestions = predictiveEngine.getSuggestions("Ўзбек", null, ScriptType.CYRILLIC, ShiftState.SINGLE_SHIFT)
        assertTrue("Kirillda Ўзбек... taklifi chiqishi shart", suggestions.any { it.startsWith("Ўзбек") })
    }

    @Test
    fun testAgglutinativeMorphologyAndAutocorrect() {
        val analysis = predictiveEngine.morphologyAnalyzer.analyze("kitoblarimizdan")
        assertTrue(analysis.isValidWord)
        assertEquals("kitob", analysis.rootStem)
        assertEquals("larimizdan", analysis.suffixChain)

        // Fonetik xato: "xarakat" yoki "galaba" -> "gʻalaba"
        val corrections = predictiveEngine.spellChecker.suggestCorrections("galaba")
        assertTrue(corrections.contains("g${MODIFIER_TURNED_COMMA}alaba"))
    }
}
