package uz.adaptive.keyboard.translit

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.MODIFIER_TURNED_COMMA
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.RIGHT_SINGLE_QUOTE

/**
 * PHASE 5 — 6-Yo'nalishli Kontekstli Transliteratsiya (`TranscriptionConverter`) va
 * Himoyalangan Bo'laklar (`ProtectedSpanTokenizer`) Avtomatlashtirilgan Testlari.
 */
class Phase5TransliterationTest {

    private lateinit var converter: TranscriptionConverter
    private val oMod = "o$MODIFIER_TURNED_COMMA"
    private val OMod = "O$MODIFIER_TURNED_COMMA"
    private val gMod = "g$MODIFIER_TURNED_COMMA"
    private val GMod = "G$MODIFIER_TURNED_COMMA"
    private val tutuq = "$RIGHT_SINGLE_QUOTE"

    @Before
    fun setUp() {
        converter = TranscriptionConverter(TransliterationRuleConfig())
    }

    @Test
    fun testDirection1_NewLatinToTraditionalLatin() {
        val src = "Özbekiston Ğalaba Şahar Çiroyli ng"
        val out = converter.convert(src, ScriptType.NEW_LATIN, ScriptType.TRADITIONAL_LATIN)
        assertEquals("${OMod}zbekiston ${GMod}alaba Shahar Chiroyli ng", out)
    }

    @Test
    fun testDirection2_TraditionalLatinToNewLatin() {
        val src = "${OMod}zbekiston ${GMod}alaba Shahar Chiroyli ming"
        val out = converter.convert(src, ScriptType.TRADITIONAL_LATIN, ScriptType.NEW_LATIN)
        assertEquals("Özbekiston Ğalaba Şahar Çiroyli ming", out)
    }

    @Test
    fun testDirection3_TraditionalLatinToCyrillic() {
        val src = "${OMod}zbekiston ${GMod}alaba Shahar Chiroyli Y${oMod}l Yosh Eshik Mening Is${tutuq}hoq"
        val out = converter.convert(src, ScriptType.TRADITIONAL_LATIN, ScriptType.CYRILLIC)
        assertEquals("Ўзбекистон Ғалаба Шаҳар Чиройли Йўл Ёш Эшик Менинг Исҳоқ", out)
    }

    @Test
    fun testDirection4_CyrillicToTraditionalLatin() {
        val src = "Ўзбекистон Ғалаба Шаҳар Чиройли Йўл Ёш Эшик Менинг Исҳоқ Етти"
        val out = converter.convert(src, ScriptType.CYRILLIC, ScriptType.TRADITIONAL_LATIN)
        assertEquals(
            "${OMod}zbekiston ${GMod}alaba Shahar Chiroyli Y${oMod}l Yosh Eshik Mening Is${tutuq}hoq Yetti",
            out
        )
    }

    @Test
    fun testDirection5_NewLatinToCyrillic() {
        val src = "Özbekiston Ğalaba Şahar Çiroyli Yöl Yoş"
        val out = converter.convert(src, ScriptType.NEW_LATIN, ScriptType.CYRILLIC)
        assertEquals("Ўзбекистон Ғалаба Шаҳар Чиройли Йўл Ёш", out)
    }

    @Test
    fun testDirection6_CyrillicToNewLatin() {
        val src = "Ўзбекистон Ғалаба Шаҳар Чиройли Йўл Ёш"
        val out = converter.convert(src, ScriptType.CYRILLIC, ScriptType.NEW_LATIN)
        assertEquals("Özbekiston Ğalaba Şahar Çiroyli Yöl Yoş", out)
    }

    @Test
    fun testProtectedSpansPreserved() {
        val input = "Salom Özbekiston! 🇺🇿 2026-yil, sayt: https://uzbekistan.uz/shahar va info@mail.uz #2026"
        val cyr = converter.convert(input, ScriptType.NEW_LATIN, ScriptType.CYRILLIC)
        assertTrue(cyr.contains("Салом Ўзбекистон!"))
        assertTrue(cyr.contains("🇺🇿"))
        assertTrue(cyr.contains("2026-йил"))
        assertTrue(cyr.contains("https://uzbekistan.uz/shahar"))
        assertTrue(cyr.contains("info@mail.uz"))
    }

    @Test
    fun testAmbiguousAlternativesGenerated() {
        val res1 = converter.transliterateWithAlternatives("sher", ScriptType.CYRILLIC)
        assertEquals("шер", res1.primaryOutput)
        assertTrue("Expected 'шеър' in alternatives", res1.alternatives.contains("шеър"))

        val res2 = converter.transliterateWithAlternatives("ishoq", ScriptType.CYRILLIC)
        assertTrue(
            res2.primaryOutput == "исҳоқ" || res2.alternatives.contains("исҳоқ")
        )
    }
}
