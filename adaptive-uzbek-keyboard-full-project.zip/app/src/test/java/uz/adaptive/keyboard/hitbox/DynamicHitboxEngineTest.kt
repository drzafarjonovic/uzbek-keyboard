package uz.adaptive.keyboard.hitbox

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import uz.adaptive.keyboard.model.KeyboardMode
import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.ui.layout.UzbekLayoutFactory

/**
 * Phase 3 DynamicHitboxEngine matematik invariantlarini tekshiruvchi JUnit 4 testlari:
 * 1. Hitbox hududlari hech qachon ustma-ust tushmasligi (Zero Overlap).
 * 2. Barcha hitboxlar klaviatura chegarasidan [0, W] x [0, H] chiqmasligi.
 * 3. Kontekst asosida keyingi harf ehtimolligi yuqori bo'lganda uning hitbox kengligi kengayishi.
 */
class DynamicHitboxEngineTest {

    private val screenWidth = 1080 // Redmi Note 13 kengligi (px)
    private val keyboardHeight = 680

    private fun prepareGeometry(script: ScriptType): Pair<DynamicHitboxEngine, uz.adaptive.keyboard.model.KeyboardLayoutModel> {
        val layout = UzbekLayoutFactory.createLayout(script, KeyboardMode.ALPHABET)
        val rows = layout.rows
        val rowH = keyboardHeight.toFloat() / rows.size
        for (r in rows.indices) {
            val row = rows[r]
            val totalWeight = row.sumOf { it.widthWeight.toDouble() }.toFloat()
            var left = 0f
            for (k in row) {
                val w = (k.widthWeight / totalWeight) * screenWidth
                k.visualRect.set(left + 4f, r * rowH + 6f, left + w - 4f, (r + 1) * rowH - 6f)
                left += w
            }
        }
        val engine = DynamicHitboxEngine()
        return Pair(engine, layout)
    }

    @Test
    fun testHitboxesNeverOverlapAndStayInsideBoundsAcrossAllThreeScripts() {
        for (script in ScriptType.entries) {
            val (engine, layout) = prepareGeometry(script)
            engine.updateDynamicBounds(layout, "O‘zbekist", screenWidth, keyboardHeight)

            for (row in layout.rows) {
                for (i in row.indices) {
                    val key = row[i]
                    val hb = key.hitboxRect
                    assertTrue("Chap chegara >= 0 bo'lishi shart", hb.left >= 0f)
                    assertTrue("O'ng chegara <= W bo'lishi shart", hb.right <= screenWidth.toFloat())
                    assertTrue("Yuqori chegara >= 0 bo'lishi shart", hb.top >= 0f)
                    assertTrue("Pastki chegara <= H bo'lishi shart", hb.bottom <= keyboardHeight.toFloat())
                    assertTrue("Hitbox kengligi musbat bo'lishi shart", hb.width() > 0f)

                    if (i < row.lastIndex) {
                        val nextKey = row[i + 1]
                        assertTrue(
                            "Qo'shni tugmalar to'qnashmasligi shart: ${key.id} va ${nextKey.id}",
                            hb.right <= nextKey.hitboxRect.left + 0.01f
                        )
                    }
                }
            }
        }
    }

    @Test
    fun testHighProbabilityNextLetterExpandsHitbox() {
        val (engine, layout) = prepareGeometry(ScriptType.NEW_LATIN)

        // 1. Bo'sh kontekstda 'o' tugmasining kengligi
        engine.updateDynamicBounds(layout, "", screenWidth, keyboardHeight)
        val keyO = layout.allKeys.first { it.lowerText == "o" }
        val neutralWidth = keyO.hitboxRect.width()

        // 2. "Özbekist" kontekstidan keyin 'o' ("Özbekiston") ehtimolligi keskin oshadi
        engine.updateDynamicBounds(layout, "Özbekist", screenWidth, keyboardHeight)
        val expandedWidth = keyO.hitboxRect.width()

        assertTrue(
            "'Özbekist' kontekstida 'o' tugmasining sensorli hududi kengayishi kerak ($expandedWidth > $neutralWidth)",
            expandedWidth > neutralWidth
        )

        // 3. 'i' va 'o' tugmalari orasidagi chegara nuqtasiga bosilganda 'o' tanlanishi kerak
        val keyI = layout.allKeys.first { it.lowerText == "i" }
        val borderTouchX = keyI.visualRect.right - 2f
        val borderTouchY = keyO.centerY
        val resolved = engine.resolveKeyAt(borderTouchX, borderTouchY, layout, "Özbekist")
        assertNotNull(resolved)
        assertEquals("o", resolved?.lowerText)
    }
}
