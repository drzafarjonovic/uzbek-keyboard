package uz.adaptive.keyboard.metrics

import kotlin.math.max
import kotlin.math.min

/**
 * PHASE 6 — KLAVIATURA SAMARADORLIGINI BAHOLASH METRIKALARI DVIGATELI.
 *
 * Quyidagi 5 ta xalqaro HCI va NLP ko'rsatkichlarini aniq matematik formulalar orqali hisoblaydi:
 * 1. CER (Character Error Rate): (S_c + D_c + I_c) / N_c * 100%
 * 2. WER (Word Error Rate):      (S_w + D_w + I_w) / N_w * 100%
 * 3. WPM (Words Per Minute):     (TotalChars / 5.0) / ElapsedMinutes
 * 4. Correction Rate (CR):       SuccessfullyRecoveredTypos / TotalSimulatedTypos * 100%
 * 5. False Touch Rate (FTR):     UnintendedKeyHits / TotalTouches * 100%
 */
data class TypingEvaluationReport(
    val scenarioName: String,
    val totalTouches: Int,
    val totalWords: Int,
    val totalChars: Int,
    val cerPercent: Double,
    val werPercent: Double,
    val wpm: Double,
    val correctionRatePercent: Double,
    val falseTouchRatePercent: Double
)

object KeyboardMetricsEvaluator {

    /**
     * 1. CER (Character Error Rate) — Belgilar darajasidagi Levenshtein xatolik ulushi (%).
     */
    fun computeCER(referenceText: String, hypothesisText: String): Double {
        if (referenceText.isEmpty()) return if (hypothesisText.isEmpty()) 0.0 else 100.0
        val dist = levenshteinDistanceChars(referenceText, hypothesisText)
        return (dist.toDouble() / referenceText.length.toDouble()) * 100.0
    }

    /**
     * 2. WER (Word Error Rate) — So'zlar darajasidagi Levenshtein xatolik ulushi (%).
     */
    fun computeWER(referenceText: String, hypothesisText: String): Double {
        val refWords = referenceText.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val hypWords = hypothesisText.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (refWords.isEmpty()) return if (hypWords.isEmpty()) 0.0 else 100.0
        val dist = levenshteinDistanceTokens(refWords, hypWords)
        return (dist.toDouble() / refWords.size.toDouble()) * 100.0
    }

    /**
     * 3. WPM (Words Per Minute) — Standart 5 belgi = 1 so'z o'lchovida yozish tezligi.
     */
    fun computeWPM(characterCount: Int, elapsedMillis: Long): Double {
        if (elapsedMillis <= 0L || characterCount <= 0) return 0.0
        val standardWords = characterCount / 5.0
        val minutes = elapsedMillis / 60_000.0
        return standardWords / minutes
    }

    /**
     * 4. Correction Rate (CR) — Dinamik Hitbox + Vaznli SpellChecker tomonidan
     * muvaffaqiyatli tiklangan barmoq siljishi va imlo xatolari foizi (%).
     */
    fun computeCorrectionRate(recoveredTypos: Int, totalSimulatedTypos: Int): Double {
        if (totalSimulatedTypos <= 0) return 100.0
        return (recoveredTypos.toDouble() / totalSimulatedTypos.toDouble()) * 100.0
    }

    /**
     * 5. False Touch Rate (FTR) — Chegara yaqinidagi bosishlarda qo'shni tugmaning
     * xato bosilib ketish foizi (%).
     */
    fun computeFalseTouchRate(unintendedNeighborTouches: Int, totalTouches: Int): Double {
        if (totalTouches <= 0) return 0.0
        return (unintendedNeighborTouches.toDouble() / totalTouches.toDouble()) * 100.0
    }

    private fun levenshteinDistanceChars(a: String, b: String): Int {
        val n = a.length
        val m = b.length
        if (n == 0) return m
        if (m == 0) return n

        var prev = IntArray(m + 1) { it }
        var curr = IntArray(m + 1)

        for (i in 1..n) {
            curr[0] = i
            val ca = a[i - 1]
            for (j in 1..m) {
                val cost = if (ca == b[j - 1]) 0 else 1
                curr[j] = min(
                    min(curr[j - 1] + 1, prev[j] + 1),
                    prev[j - 1] + cost
                )
            }
            val tmp = prev
            prev = curr
            curr = tmp
        }
        return prev[m]
    }

    private fun levenshteinDistanceTokens(a: List<String>, b: List<String>): Int {
        val n = a.size
        val m = b.size
        if (n == 0) return m
        if (m == 0) return n

        var prev = IntArray(m + 1) { it }
        var curr = IntArray(m + 1)

        for (i in 1..n) {
            curr[0] = i
            val wa = a[i - 1]
            for (j in 1..m) {
                val cost = if (wa == b[j - 1]) 0 else 1
                curr[j] = min(
                    min(curr[j - 1] + 1, prev[j] + 1),
                    prev[j - 1] + cost
                )
            }
            val tmp = prev
            prev = curr
            curr = tmp
        }
        return prev[m]
    }
}
