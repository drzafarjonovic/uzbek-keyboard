package uz.adaptive.keyboard.hitbox

import uz.adaptive.keyboard.model.KeyActionType
import uz.adaptive.keyboard.model.KeySpec
import uz.adaptive.keyboard.model.KeyboardLayoutModel
import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer

/**
 * Uchala o'zbek yozuv tizimi (Yangi Lotin, Amaldagi Lotin, Kirill) uchun umumiy
 * 34-fonemali kanonik Bigram/Trigram fonotaktik ehtimollik modeli.
 *
 * O(1) massiv qidiruvi orqali < 0.03 ms ichida (heap xotiradan joy ajratmasdan)
 * keyingi harflarning shartli ehtimolligi P(k | c_{t-2}, c_{t-1}) ni hisoblaydi.
 */
class UzbekPhoneticBigramModel {

    companion object {
        const val PHONEME_COUNT = 35
        const val ID_BOS = 0 // So'z boshi (Beginning of Word)
        const val ID_A = 1
        const val ID_B = 2
        const val ID_D = 3
        const val ID_E = 4
        const val ID_F = 5
        const val ID_G = 6
        const val ID_H = 7
        const val ID_I = 8
        const val ID_J = 9
        const val ID_K = 10
        const val ID_L = 11
        const val ID_M = 12
        const val ID_N = 13
        const val ID_O = 14
        const val ID_P = 15
        const val ID_Q = 16
        const val ID_R = 17
        const val ID_S = 18
        const val ID_T = 19
        const val ID_U = 20
        const val ID_V = 21
        const val ID_X = 22
        const val ID_Y = 23
        const val ID_Z = 24
        const val ID_O_MOD = 25 // Ö / O‘ / Ў
        const val ID_G_MOD = 26 // Ğ / G‘ / Ғ
        const val ID_SH = 27    // Ş / Sh / Ш
        const val ID_CH = 28    // Ç / Ch / Ч
        const val ID_NG = 29    // ng / нг
        const val ID_C_TS = 30  // C / Ц
        const val ID_W = 31     // W
        const val ID_YO = 32    // Ё
        const val ID_YU = 33    // Ю
        const val ID_YA = 34    // Я

        private val VOWEL_IDS = intArrayOf(ID_A, ID_E, ID_I, ID_O, ID_U, ID_O_MOD, ID_YO, ID_YU, ID_YA)
    }

    // bigramWeights[prevId * PHONEME_COUNT + nextId] -> log-normalized weight
    private val bigramTable = FloatArray(PHONEME_COUNT * PHONEME_COUNT) { 1.0f }

    // Maxsus yuqori chastotali o'zbekcha trigram qoidalari: (c_{t-2}, c_{t-1}) -> boosted nextId
    private val trigramBoostMap = HashMap<Int, IntArray>(128)

    init {
        initializeUzbekPhonotactics()
    }

    private fun initializeUzbekPhonotactics() {
        val isVowel = BooleanArray(PHONEME_COUNT)
        for (v in VOWEL_IDS) isVowel[v] = true

        // 1. O'zbek fonotaktikasi asosiy qonuni: Unli -> Undosh va Undosh -> Unli o'tishlari yuqori ehtimollikka ega
        for (prev in 1 until PHONEME_COUNT) {
            for (next in 1 until PHONEME_COUNT) {
                val baseWeight = when {
                    isVowel[prev] && !isVowel[next] -> 2.4f
                    !isVowel[prev] && isVowel[next] -> 2.8f
                    !isVowel[prev] && !isVowel[next] -> 0.75f
                    else -> 0.35f // Ketma-ket ikki unli o'zbek tilida kam uchraydi
                }
                setBigram(prev, next, baseWeight)
            }
        }

        // 2. So'z boshi (BOS) chastotalari (O'zbek tilida so'z ko'p boshlanadigan harflar)
        val bosHigh = intArrayOf(ID_B, ID_K, ID_M, ID_O, ID_Q, ID_S, ID_T, ID_Y, ID_A, ID_I, ID_U, ID_O_MOD, ID_SH, ID_CH, ID_G_MOD)
        for (id in bosHigh) {
            setBigram(ID_BOS, id, 3.2f)
        }

        // 3. O'zbek tilidagi eng ko'p uchraydigan harf juftliklari (ildizlar va qo'shimchalar: -lar, -ning, -ga, -da, -dan, -iston, -lik)
        val highPairs = arrayOf(
            intArrayOf(ID_O_MOD, ID_Z, 6.8f.toBits()),   // o'z / öz / ўз
            intArrayOf(ID_Z, ID_B, 5.2f.toBits()),       // o'zb...
            intArrayOf(ID_B, ID_E, 5.5f.toBits()),       // o'zbek
            intArrayOf(ID_E, ID_K, 5.4f.toBits()),       // bek
            intArrayOf(ID_K, ID_I, 5.6f.toBits()),       // ki / kitob
            intArrayOf(ID_I, ID_S, 5.2f.toBits()),       // iston / ish
            intArrayOf(ID_S, ID_T, 6.2f.toBits()),       // ist -> t
            intArrayOf(ID_T, ID_O, 6.4f.toBits()),       // isto -> o
            intArrayOf(ID_O, ID_N, 6.5f.toBits()),       // iston -> n
            intArrayOf(ID_L, ID_A, 6.8f.toBits()),       // -lar
            intArrayOf(ID_A, ID_R, 6.6f.toBits()),       // -lar
            intArrayOf(ID_N, ID_I, 6.5f.toBits()),       // -ni / -ning
            intArrayOf(ID_I, ID_N, 6.1f.toBits()),       // -ing / -ning
            intArrayOf(ID_N, ID_G, 6.9f.toBits()),       // -ng / -ning
            intArrayOf(ID_G, ID_A, 6.0f.toBits()),       // -ga
            intArrayOf(ID_D, ID_A, 6.4f.toBits()),       // -da / -dan
            intArrayOf(ID_A, ID_N, 6.2f.toBits()),       // -dan / -gan
            intArrayOf(ID_G_MOD, ID_A, 6.5f.toBits()),   // g'a / ğa / ға (g'alaba)
            intArrayOf(ID_A, ID_L, 5.8f.toBits()),       // g'al...
            intArrayOf(ID_A, ID_B, 5.4f.toBits()),       // g'alab...
            intArrayOf(ID_B, ID_A, 5.9f.toBits()),       // g'alaba / va
            intArrayOf(ID_SH, ID_A, 6.4f.toBits()),      // shahar / şahar / шаҳар
            intArrayOf(ID_A, ID_H, 5.7f.toBits()),       // shah...
            intArrayOf(ID_H, ID_A, 6.1f.toBits()),       // shaha...
            intArrayOf(ID_CH, ID_I, 6.5f.toBits()),      // chiroyli / çiroyli / чиройли
            intArrayOf(ID_I, ID_R, 5.8f.toBits()),       // chir...
            intArrayOf(ID_R, ID_O, 5.9f.toBits()),       // chiro...
            intArrayOf(ID_O, ID_Y, 6.1f.toBits()),       // chiroy...
            intArrayOf(ID_Y, ID_L, 5.7f.toBits()),       // chiroyl...
            intArrayOf(ID_L, ID_I, 6.3f.toBits()),       // -li / -lik
            intArrayOf(ID_Q, ID_A, 6.0f.toBits()),       // qa...
            intArrayOf(ID_Q, ID_O_MOD, 6.2f.toBits()),   // qo'... / qö... / қў...
            intArrayOf(ID_Q, ID_I, 5.9f.toBits())        // qi...
        )

        for (entry in highPairs) {
            setBigram(entry[0], entry[1], Float.fromBits(entry[2]))
        }

        // 4. Trigram kontekst kuchaytirgichlari: (prev2, prev1) -> Ustuvor keyingi fonema IDlari
        registerTrigram(ID_S, ID_T, intArrayOf(ID_O, ID_A, ID_I))          // "...st" -> "o" (O'zbekiston)
        registerTrigram(ID_T, ID_O, intArrayOf(ID_N, ID_B, ID_R))          // "...to" -> "n" (O'zbekiston), "b" (kitob)
        registerTrigram(ID_L, ID_A, intArrayOf(ID_R, ID_B, ID_N))          // "...la" -> "r" (-lar), "b" (g'alaba)
        registerTrigram(ID_N, ID_I, intArrayOf(ID_N, ID_Z, ID_M))          // "...ni" -> "n" (-ning)
        registerTrigram(ID_I, ID_N, intArrayOf(ID_G, ID_I, ID_Z))          // "...in" -> "g" (-ning)
        registerTrigram(ID_SH, ID_A, intArrayOf(ID_H, ID_R, ID_V))         // "sha" / "şa" -> "h" (shahar)
        registerTrigram(ID_CH, ID_I, intArrayOf(ID_R, ID_Q, ID_Z))         // "chi" / "çi" -> "r" (chiroyli)
        registerTrigram(ID_G_MOD, ID_A, intArrayOf(ID_L, ID_Z, ID_R))      // "g'a" / "ğa" -> "l" (g'alaba)
        registerTrigram(ID_O_MOD, ID_Z, intArrayOf(ID_B, ID_I, ID_G))      // "o'z" / "öz" -> "b" (O'zbekiston)
    }

    private fun setBigram(prev: Int, next: Int, weight: Float) {
        bigramTable[prev * PHONEME_COUNT + next] = weight
    }

    private fun registerTrigram(prev2: Int, prev1: Int, boostedTargets: IntArray) {
        val key = (prev2 shl 6) or prev1
        trigramBoostMap[key] = boostedTargets
    }

    /**
     * Joriy so'z prefiksini tahlil qilib, aktiv layoutdagi barcha tugmalar uchun
     * normallashtirilgan ehtimollik massivini outProbabilities ichiga yozadi (Zero-Allocation).
     */
    fun computeKeyProbabilities(
        prefix: String,
        layout: KeyboardLayoutModel,
        outProbabilities: FloatArray
    ) {
        val keys = layout.allKeys
        val count = keys.size.coerceAtMost(outProbabilities.size)
        if (count == 0) return

        val (prev2, prev1) = extractLastTwoPhonemes(prefix, layout.scriptType)
        val trigramKey = (prev2 shl 6) or prev1
        val boostedTargets = trigramBoostMap[trigramKey]

        var sum = 0f
        for (i in 0 until count) {
            val keySpec = keys[i]
            if (keySpec.isFunctional || keySpec.actionType == KeyActionType.SPACE) {
                outProbabilities[i] = 1.0f / count
                sum += outProbabilities[i]
                continue
            }

            val phonemeId = mapKeyToPhonemeId(keySpec, layout.scriptType)
            var weight = if (phonemeId in 1 until PHONEME_COUNT) {
                bigramTable[prev1 * PHONEME_COUNT + phonemeId]
            } else {
                1.0f
            }

            if (boostedTargets != null && phonemeId != 0) {
                for (bIdx in boostedTargets.indices) {
                    if (boostedTargets[bIdx] == phonemeId) {
                        // 1-o'rindagi trigram nomzodiga eng katta ko'paytiruvchi
                        weight *= (2.4f - bIdx * 0.45f).coerceAtLeast(1.3f)
                        break
                    }
                }
            }

            outProbabilities[i] = weight
            sum += weight
        }

        if (sum > 0f) {
            val invSum = 1.0f / sum
            for (i in 0 until count) {
                outProbabilities[i] *= invSum
            }
        }
    }

    /**
     * So'z prefiksining oxirgi 2 ta fonemasini uchta yozuv tizimiga mos ravishda ajratib oladi.
     */
    fun extractLastTwoPhonemes(prefix: String, script: ScriptType): Pair<Int, Int> {
        if (prefix.isEmpty()) return Pair(ID_BOS, ID_BOS)
        val normalized = if (script == ScriptType.TRADITIONAL_LATIN) {
            UzbekUnicodeNormalizer.normalizeTraditionalLatin(prefix).lowercase()
        } else {
            prefix.lowercase()
        }

        val tokens = IntArray(normalized.length)
        var tCount = 0
        var i = 0
        while (i < normalized.length) {
            val ch = normalized[i]
            val next = if (i + 1 < normalized.length) normalized[i + 1] else '\u0000'

            // Amaldagi lotin digraflari (sh, ch, o‘, g‘, ng) tekshiruvi
            if (ch == 's' && next == 'h') {
                tokens[tCount++] = ID_SH
                i += 2
                continue
            }
            if (ch == 'c' && next == 'h') {
                tokens[tCount++] = ID_CH
                i += 2
                continue
            }
            if (ch == 'o' && next == UzbekUnicodeNormalizer.MODIFIER_TURNED_COMMA) {
                tokens[tCount++] = ID_O_MOD
                i += 2
                continue
            }
            if (ch == 'g' && next == UzbekUnicodeNormalizer.MODIFIER_TURNED_COMMA) {
                tokens[tCount++] = ID_G_MOD
                i += 2
                continue
            }
            if (ch == 'n' && next == 'g') {
                tokens[tCount++] = ID_NG
                i += 2
                continue
            }

            val singleId = mapSingleCharToPhonemeId(ch)
            if (singleId != ID_BOS) {
                tokens[tCount++] = singleId
            }
            i++
        }

        return when (tCount) {
            0 -> Pair(ID_BOS, ID_BOS)
            1 -> Pair(ID_BOS, tokens[0])
            else -> Pair(tokens[tCount - 2], tokens[tCount - 1])
        }
    }

    private fun mapKeyToPhonemeId(key: KeySpec, script: ScriptType): Int {
        val text = key.lowerText
        if (text.isEmpty()) return ID_BOS
        return when (text) {
            "sh", "ş", "ш" -> ID_SH
            "ch", "ç", "ч" -> ID_CH
            "o‘", "ö", "ў" -> ID_O_MOD
            "g‘", "ğ", "ғ" -> ID_G_MOD
            "ng", "нг" -> ID_NG
            else -> mapSingleCharToPhonemeId(text[0])
        }
    }

    private fun mapSingleCharToPhonemeId(ch: Char): Int = when (ch) {
        'a', 'а' -> ID_A
        'b', 'б' -> ID_B
        'd', 'д' -> ID_D
        'e', 'е', 'э' -> ID_E
        'f', 'ф' -> ID_F
        'g', 'г' -> ID_G
        'h', 'ҳ' -> ID_H
        'i', 'и' -> ID_I
        'j', 'ж' -> ID_J
        'k', 'к' -> ID_K
        'l', 'л' -> ID_L
        'm', 'м' -> ID_M
        'n', 'н' -> ID_N
        'o', 'о' -> ID_O
        'p', 'п' -> ID_P
        'q', 'қ' -> ID_Q
        'r', 'р' -> ID_R
        's', 'с' -> ID_S
        't', 'т' -> ID_T
        'u', 'у' -> ID_U
        'v', 'в' -> ID_V
        'x', 'х' -> ID_X
        'y', 'й' -> ID_Y
        'z', 'з' -> ID_Z
        'ö', 'ў' -> ID_O_MOD
        'ğ', 'ғ' -> ID_G_MOD
        'ş', 'ш' -> ID_SH
        'ç', 'ч' -> ID_CH
        'c', 'ц' -> ID_C_TS
        'w' -> ID_W
        'ё' -> ID_YO
        'ю' -> ID_YU
        'я' -> ID_YA
        else -> ID_BOS
    }
}
