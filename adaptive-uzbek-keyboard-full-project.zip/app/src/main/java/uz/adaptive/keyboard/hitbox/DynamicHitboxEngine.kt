package uz.adaptive.keyboard.hitbox

import uz.adaptive.keyboard.model.KeyActionType
import uz.adaptive.keyboard.model.KeySpec
import uz.adaptive.keyboard.model.KeyboardLayoutModel
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * PHASE 3 — ADAPTIVE ENGINE (Bayes-Voronoi Dynamic Hitbox Algorithm).
 *
 * Matematik model:
 *   Score(k | x, y, c) = -0.5 * [ ((x - mu_x,k)/sigma_x,k)^2 + ((y - mu_y,k)/sigma_y,k)^2 ]
 *                        + lambda * ln P_LM(k | c_{t-2}, c_{t-1})
 *
 * Kafolatlangan invariantlar:
 * 1. Vizual tugmalar o'lchami (visualRect) hech qachon o'zgarmaydi (barmoq xotirasi saqlanadi).
 * 2. Har bir tugmaning 65% markaziy yadrosi (Protected Core) daxlsiz qoladi.
 * 3. Qo'shni tugmalar orasidagi dinamik chegara yagona umumiy gipertekislik bo'yicha bo'linadi,
 *    shu bois hitboxRect hududlari HECH QACHON ustma-ust tushmaydi (to'qnashmaydi).
 * 4. Tashqi chegaralar [0, keyboardWidth] va [0, keyboardHeight] ichida qat'iy qirqiladi.
 */
class DynamicHitboxEngine(
    private val languageModel: UzbekPhoneticBigramModel = UzbekPhoneticBigramModel(),
    private val habitTracker: UserHabitTracker = UserHabitTracker(null)
) : HitboxResolver {

    companion object {
        // Lingvistik prior og'irligi (Bayes lambda)
        private const val LAMBDA_LM_WEIGHT = 0.38f

        // Tugma kengayishining maksimal chegarasi: bazaviy o'lchamning +35% gacha (qisqarishi -35% gacha)
        private const val MAX_EXPANSION_RATIO = 0.35f

        // Har bir tugmaning daxlsiz markaziy yadrosi (65%)
        private const val PROTECTED_CORE_RATIO = 0.65f

        private const val MAX_KEYS = 64
        private const val EPSILON_PROB = 1e-4f
    }

    /**
     * Phase 6 benchmark va diagnostika uchun real-vaqt telemetriya ko'rsatkichlari.
     */
    data class HitboxTelemetry(
        var totalTouchQueries: Long = 0L,
        var adaptiveBoundarySaves: Long = 0L,
        var lastResolutionDurationNs: Long = 0L,
        var avgResolutionDurationNs: Long = 0L
    )

    val telemetry = HitboxTelemetry()

    private val spatialGrid = SpatialKeyGrid()
    private val keyProbabilities = FloatArray(MAX_KEYS) { 1f / 32f }
    private val candidateBuffer = IntArray(16)
    private var cachedLayout: KeyboardLayoutModel? = null
    private var cachedWidth: Int = 0
    private var cachedHeight: Int = 0

    override fun updateDynamicBounds(
        layout: KeyboardLayoutModel,
        contextPrefix: String,
        keyboardWidth: Int,
        keyboardHeight: Int
    ) {
        if (keyboardWidth <= 0 || keyboardHeight <= 0) return

        if (cachedLayout !== layout || cachedWidth != keyboardWidth || cachedHeight != keyboardHeight) {
            spatialGrid.rebuildGrid(layout, keyboardWidth, keyboardHeight)
            cachedLayout = layout
            cachedWidth = keyboardWidth
            cachedHeight = keyboardHeight
        }

        // 1. Kontekst (oldin yozilgan harflar) asosida keyingi harflar ehtimolligini hisoblaymiz
        languageModel.computeKeyProbabilities(contextPrefix, layout, keyProbabilities)

        val rows = layout.rows
        if (rows.isEmpty()) return

        val kbdW = keyboardWidth.toFloat()
        val kbdH = keyboardHeight.toFloat()
        val uniformProb = 1.0f / layout.allKeys.size.coerceAtLeast(1)

        // 2. Har bir qator ichida gorizontal qo'shnilar orasidagi to'qnashmas Voronoi chegarasini hisoblaymiz
        var globalKeyIdx = 0
        val rowTopBounds = FloatArray(rows.size)
        val rowBottomBounds = FloatArray(rows.size)

        // Qatorlararo vertikal chegaralar (yopishgan va klaviatura ramkasidan chiqmaydigan)
        for (r in rows.indices) {
            val firstInRow = rows[r].firstOrNull()
            rowTopBounds[r] = if (r == 0) {
                0f
            } else {
                val prevBottom = rows[r - 1].firstOrNull()?.visualRect?.bottom ?: 0f
                val currTop = firstInRow?.visualRect?.top ?: prevBottom
                (prevBottom + currTop) * 0.5f
            }
            rowBottomBounds[r] = if (r == rows.lastIndex) {
                kbdH
            } else {
                val currBottom = firstInRow?.visualRect?.bottom ?: kbdH
                val nextTop = rows[r + 1].firstOrNull()?.visualRect?.top ?: currBottom
                (currBottom + nextTop) * 0.5f
            }
        }

        for (r in rows.indices) {
            val row = rows[r]
            val n = row.size
            if (n == 0) continue

            val rowStartIdx = globalKeyIdx

            // Qo'shni tugmalar orasidagi n+1 ta vertikal ajratuvchi chiziq (dividers[0..n])
            // dividers[0] = 0f, dividers[n] = kbdW -> klaviatura chegarasidan hech qachon chiqmaydi!
            val dividers = FloatArray(n + 1)
            dividers[0] = 0f
            dividers[n] = kbdW

            for (i in 0 until n - 1) {
                val leftKey = row[i]
                val rightKey = row[i + 1]
                val leftProb = keyProbabilities[rowStartIdx + i].coerceAtLeast(EPSILON_PROB)
                val rightProb = keyProbabilities[rowStartIdx + i + 1].coerceAtLeast(EPSILON_PROB)

                // Vizual tugmalar orasidagi o'rta nuqta + foydalanuvchining barmoq siljish odati
                val leftHabit = habitTracker.getProfile(leftKey.id)
                val rightHabit = habitTracker.getProfile(rightKey.id)
                val baseMidX = (leftKey.visualRect.right + rightKey.visualRect.left) * 0.5f +
                    (leftHabit.offsetX + rightHabit.offsetX) * 0.35f

                // Funksional tugmalar (Shift, Backspace, 123, Enter) o'z chegarasini barqaror saqlaydi
                val shiftPx = if (leftKey.isFunctional || rightKey.isFunctional) {
                    0f
                } else {
                    val logRatio = ln(leftProb / rightProb)
                    val minWidth = min(leftKey.visualRect.width(), rightKey.visualRect.width())
                    val maxShift = minWidth * MAX_EXPANSION_RATIO
                    (logRatio * minWidth * 0.14f).coerceIn(-maxShift, maxShift)
                }

                // Har ikki tugmaning kamida 65% markaziy yadrosi saqlanishini kafolatlash
                val minAllowedDivider = leftKey.visualRect.left + leftKey.visualRect.width() * PROTECTED_CORE_RATIO
                val maxAllowedDivider = rightKey.visualRect.right - rightKey.visualRect.width() * PROTECTED_CORE_RATIO

                dividers[i + 1] = (baseMidX + shiftPx)
                    .coerceIn(minAllowedDivider, maxAllowedDivider)
                    .coerceIn(0f, kbdW)
            }

            // Har bir tugmaga o'zining chap va o'ng divider'ini biriktiramiz (0% overlap!)
            for (i in 0 until n) {
                val key = row[i]
                val prob = keyProbabilities[rowStartIdx + i].coerceAtLeast(EPSILON_PROB)
                val leftBound = dividers[i]
                val rightBound = max(leftBound + 1f, dividers[i + 1])

                // Yuqori ehtimolli harflar vertikal bo'yicha ham qatorlararo tirqish hisobiga 2-4px kengayadi,
                // ammo qatorning birinchi va oxirgi chegarasidan (rowTopBounds/rowBottomBounds) oshmaydi.
                val probBoost = ln(prob / uniformProb).coerceIn(-1.5f, 1.5f)
                val vPad = if (key.isFunctional) 0f else (probBoost * 1.8f).coerceIn(-2f, 2.5f)

                val topBound = (rowTopBounds[r] - vPad).coerceIn(rowTopBounds[r], key.visualRect.top)
                val bottomBound = (rowBottomBounds[r] + vPad).coerceIn(key.visualRect.bottom, rowBottomBounds[r])

                key.hitboxRect.set(
                    leftBound.coerceIn(0f, kbdW),
                    topBound.coerceIn(0f, kbdH),
                    rightBound.coerceIn(0f, kbdW),
                    bottomBound.coerceIn(0f, kbdH)
                )
            }

            globalKeyIdx += n
        }
    }

    override fun resolveKeyAt(
        x: Float,
        y: Float,
        layout: KeyboardLayoutModel,
        contextPrefix: String
    ): KeySpec? {
        val startTimeNs = System.nanoTime()
        val allKeys = layout.allKeys
        if (allKeys.isEmpty()) return null

        val clampedX = x.coerceIn(0f, cachedWidth.toFloat().coerceAtLeast(1f))
        val clampedY = y.coerceIn(0f, cachedHeight.toFloat().coerceAtLeast(1f))

        // 1-QADAM: O(1) Spatial Grid orqali yaqin atrofdagi tugma indekslarini olamiz
        val candCount = spatialGrid.queryCandidateIndices(clampedX, clampedY, candidateBuffer)

        // 2-QADAM: Agar barmoq tugmaning 65% daxlsiz markaziy yadrosiga (Protected Core) tushgan bo'lsa,
        // hech qanday ehtimollik uni boshqa tugmaga burib yubormasligi kerak.
        for (i in 0 until candCount) {
            val kIdx = candidateBuffer[i]
            val key = allKeys[kIdx]
            val halfCoreW = key.visualRect.width() * (PROTECTED_CORE_RATIO * 0.5f)
            val halfCoreH = key.visualRect.height() * (PROTECTED_CORE_RATIO * 0.5f)
            if (clampedX >= key.centerX - halfCoreW && clampedX <= key.centerX + halfCoreW &&
                clampedY >= key.centerY - halfCoreH && clampedY <= key.centerY + halfCoreH
            ) {
                recordTelemetry(startTimeNs, wasAdaptiveSave = false)
                return key
            }
        }

        // 3-QADAM: Chegaraviy (tugmalararo bahsli) zonada 2D Gauss + Bayes-Voronoi aposterior baholash
        var bestKey: KeySpec? = null
        var bestScore = -Float.MAX_VALUE
        var visualHitKey: KeySpec? = null

        val searchCount = if (candCount > 0) candCount else allKeys.size
        for (i in 0 until searchCount) {
            val kIdx = if (candCount > 0) candidateBuffer[i] else i
            val key = allKeys[kIdx]

            if (key.visualRect.contains(clampedX, clampedY)) {
                visualHitKey = key
            }

            val habit = habitTracker.getProfile(key.id)
            val muX = key.centerX + habit.offsetX
            val muY = key.centerY + habit.offsetY

            val baseSigmaX = (key.visualRect.width() * 0.46f * habit.scaleSigmaX).coerceAtLeast(8f)
            val baseSigmaY = (key.visualRect.height() * 0.46f * habit.scaleSigmaY).coerceAtLeast(8f)

            val normDx = (clampedX - muX) / baseSigmaX
            val normDy = (clampedY - muY) / baseSigmaY
            val spatialLogLikelihood = -0.5f * (normDx * normDx + normDy * normDy)

            val priorProb = if (kIdx < keyProbabilities.size) {
                keyProbabilities[kIdx].coerceAtLeast(EPSILON_PROB)
            } else {
                EPSILON_PROB
            }

            val languageLogPrior = if (key.isFunctional || key.actionType == KeyActionType.SPACE) {
                0f
            } else {
                LAMBDA_LM_WEIGHT * ln(priorProb)
            }

            // Agar nuqta dinamik Voronoi to'g'ri to'rtburchagi ichida bo'lsa, qo'shimcha moslik bonusi
            val voronoiBonus = if (key.hitboxRect.contains(clampedX, clampedY)) 0.28f else 0f

            val totalScore = spatialLogLikelihood + languageLogPrior + voronoiBonus
            if (totalScore > bestScore) {
                bestScore = totalScore
                bestKey = key
            }
        }

        val resolved = bestKey ?: visualHitKey
        if (resolved != null) {
            val wasAdaptiveSave = (visualHitKey != null && visualHitKey !== resolved)
            recordTelemetry(startTimeNs, wasAdaptiveSave)
        }
        return resolved
    }

    /**
     * Harf muvaffaqiyatli kiritilganda foydalanuvchining barmoq og'ish profilini yangilash.
     */
    fun notifyKeyCommitted(
        key: KeySpec,
        touchX: Float,
        touchY: Float,
        isSensitiveField: Boolean
    ) {
        if (!key.isFunctional && key.actionType != KeyActionType.SPACE) {
            habitTracker.recordTentativeTouch(
                keyId = key.id,
                touchX = touchX,
                touchY = touchY,
                keyCenterX = key.centerX,
                keyCenterY = key.centerY,
                keyWidth = key.visualRect.width(),
                keyHeight = key.visualRect.height(),
                isSensitiveField = isSensitiveField
            )
        }
    }

    fun notifyBackspacePressed() {
        habitTracker.onBackspacePressed()
    }

    private fun recordTelemetry(startNs: Long, wasAdaptiveSave: Boolean) {
        val elapsed = (System.nanoTime() - startNs).coerceAtLeast(1L)
        telemetry.totalTouchQueries++
        if (wasAdaptiveSave) {
            telemetry.adaptiveBoundarySaves++
        }
        telemetry.lastResolutionDurationNs = elapsed
        telemetry.avgResolutionDurationNs = if (telemetry.totalTouchQueries == 1L) {
            elapsed
        } else {
            ((telemetry.avgResolutionDurationNs * 7L) + elapsed) / 8L
        }
    }
}
