package uz.adaptive.keyboard.hitbox

import uz.adaptive.keyboard.model.KeySpec
import uz.adaptive.keyboard.model.KeyboardLayoutModel

/**
 * Sensorli nuqta (x, y) qaysi tugmaga tegishli ekanligini hal qiluvchi interfeys.
 * Phase 2 da Bazaviy Voronoi/Nearest-Key ishlaydi; Phase 3 da Bayes-Voronoi DynamicHitboxEngine ulanadi.
 */
interface HitboxResolver {
    fun resolveKeyAt(
        x: Float,
        y: Float,
        layout: KeyboardLayoutModel,
        contextPrefix: String
    ): KeySpec?

    fun updateDynamicBounds(
        layout: KeyboardLayoutModel,
        contextPrefix: String,
        keyboardWidth: Int,
        keyboardHeight: Int
    )
}

/**
 * Phase 2 bazaviy Hitbox rezolveri: tugmalar orasidagi bo'shliqlarni (dead-zone) yo'qotib,
 * eng yaqin markaziy tugmaga bog'laydi.
 */
class BaseNearestHitboxResolver : HitboxResolver {

    override fun resolveKeyAt(
        x: Float,
        y: Float,
        layout: KeyboardLayoutModel,
        contextPrefix: String
    ): KeySpec? {
        // 1. Avval dinamik hitbox to'g'ridan-to'g'ri qamrab olgan tugmani tekshiramiz
        for (key in layout.allKeys) {
            if (key.hitboxRect.contains(x, y)) {
                return key
            }
        }
        // 2. Agar barmoq tugmalar orasidagi 2-3 dp tirqishga tushsa, Evklid masofasi bo'yicha eng yaqin tugmani topamiz
        var bestKey: KeySpec? = null
        var minDistSq = Float.MAX_VALUE
        for (key in layout.allKeys) {
            val dx = x - key.centerX
            val dy = y - key.centerY
            val distSq = dx * dx + dy * dy
            if (distSq < minDistSq) {
                minDistSq = distSq
                bestKey = key
            }
        }
        return bestKey
    }

    override fun updateDynamicBounds(
        layout: KeyboardLayoutModel,
        contextPrefix: String,
        keyboardWidth: Int,
        keyboardHeight: Int
    ) {
        // Phase 2 bazaviy holatda hitboxRect vizual tugma va uning atrofidagi yarim-oraliqni qamrab oladi
        for (key in layout.allKeys) {
            key.hitboxRect.set(
                (key.visualRect.left - 4f).coerceAtLeast(0f),
                (key.visualRect.top - 5f).coerceAtLeast(0f),
                (key.visualRect.right + 4f).coerceAtMost(keyboardWidth.toFloat()),
                (key.visualRect.bottom + 5f).coerceAtMost(keyboardHeight.toFloat())
            )
        }
    }
}
