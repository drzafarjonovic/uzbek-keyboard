package uz.adaptive.keyboard.translit

import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer

/**
 * PHASE 5 — PROTECTED SPAN TOKENIZER.
 *
 * Matndagi tinish belgilari, raqamlar, URL havolalar, email manzillar, @mention,
 * #hashtag va emojilar transliteratsiya vaqtida buzilmasligini kafolatlaydi.
 */
enum class TokenType {
    TRANSLITERABLE_WORD,
    PROTECTED_SPAN
}

data class TextToken(
    val text: String,
    val type: TokenType
)

object ProtectedSpanTokenizer {

    private val PROTECTED_REGEX = Regex(
        pattern = "(https?://\\S+|www\\.\\S+|[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}|@[a-zA-Z0-9_]+)"
    )

    /**
     * Matnni so'z va himoyalangan bo'laklarga (URL, email, raqam, tinish belgisi, emoji) ajratadi.
     */
    fun tokenize(input: String): List<TextToken> {
        if (input.isEmpty()) return emptyList()

        val result = ArrayList<TextToken>()
        var lastEnd = 0

        for (match in PROTECTED_REGEX.findAll(input)) {
            if (match.range.first > lastEnd) {
                tokenizePlainSegment(input.substring(lastEnd, match.range.first), result)
            }
            result.add(TextToken(match.value, TokenType.PROTECTED_SPAN))
            lastEnd = match.range.last + 1
        }

        if (lastEnd < input.length) {
            tokenizePlainSegment(input.substring(lastEnd), result)
        }

        return result
    }

    private fun tokenizePlainSegment(segment: String, out: MutableList<TextToken>) {
        var i = 0
        val n = segment.length
        while (i < n) {
            if (isUzbekWordChar(segment, i)) {
                val start = i
                i++
                while (i < n && isUzbekWordChar(segment, i)) {
                    i++
                }
                out.add(TextToken(segment.substring(start, i), TokenType.TRANSLITERABLE_WORD))
            } else {
                val start = i
                i++
                while (i < n && !isUzbekWordChar(segment, i)) {
                    i++
                }
                out.add(TextToken(segment.substring(start, i), TokenType.PROTECTED_SPAN))
            }
        }
    }

    /**
     * Harf yoki so'z ichida kelgan apostrof (`O‘`, `G‘`, `ma’lum`, `Is’hoq`) ekanini tekshiradi.
     */
    private fun isUzbekWordChar(s: String, index: Int): Boolean {
        val c = s[index]
        if (c.isLetter()) return true
        if (c in UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS) {
            val prevIsLetter = index > 0 && s[index - 1].isLetter()
            val nextIsLetter = index + 1 < s.length && s[index + 1].isLetter()
            return prevIsLetter || nextIsLetter
        }
        return false
    }
}
