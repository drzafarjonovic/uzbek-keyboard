package uz.adaptive.keyboard.ui.view

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import uz.adaptive.keyboard.hitbox.DynamicHitboxEngine
import uz.adaptive.keyboard.hitbox.HitboxResolver
import uz.adaptive.keyboard.hitbox.UserHabitTracker
import uz.adaptive.keyboard.model.KeyActionType
import uz.adaptive.keyboard.model.KeySpec
import uz.adaptive.keyboard.model.KeyboardLayoutModel
import uz.adaptive.keyboard.model.KeyboardMode
import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.model.ShiftState
import uz.adaptive.keyboard.ui.layout.UzbekLayoutFactory
import uz.adaptive.keyboard.ui.theme.KeyboardPalette
import uz.adaptive.keyboard.ui.theme.KeyboardTheme
import kotlin.math.abs

/**
 * Redmi Note 13 (120Hz AMOLED, 240Hz Touch Sampling) uchun maxsus optimallashtirilgan,
 * dizayni va ishlash mexanizmi Apple iPhone (iOS 17/18) klaviaturasiga 1:1 moslashtirilgan
 * Zero-Allocation Custom Canvas klaviatura ko'rinishi.
 *
 * iPhone ishlash mexanizmlari:
 * 1. Vizual tugmalar ekranda 100% qimirlamasdan turadi, ularning ostidagi ko'rinmas sensorli
 *    hududlar (Bayesian-Voronoi Hitbox) esa har bir yozilgan harfdan so'ng dinamik kengayadi.
 * 2. iOS Unified Key Callout Balloon ("Qo'ziqorin" shaklidagi Bezier egri chiziqli tugma lupasi).
 * 3. Uzoq bosilganda (Long-Press) barmoqni uzmasdan chapga/o'ngga surib diakritik harfni
 *    (o -> oʻ | ö | ў | 9) iOS ko'k (#007AFF) rangida tanlash mexanizmi.
 * 4. iOS Trackpad Mode: Bo'sh joy (Spacebar) bosib turilganda barcha tugma yozuvlari so'nib,
 *    klaviatura yuzasi silliq sensorli trekpadga aylanadi.
 * 5. iOS Quick-Symbol Slide: "123" tugmasini bosib, barmoqni uzmasdan istalgan raqam/belgiga
 *    olib borib qo'yib yuborilganda belgi yoziladi va klaviatura avtomatik "ABC" harf rejimiga qaytadi.
 * 6. iOS Quick-Shift Slide: "⇧" tugmasini bosib, barmoqni uzmasdan harfga surib qo'yib yuborish.
 */
class AdaptiveKeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    interface KeyboardActionListener {
        fun onTextCommit(text: String)
        fun onSmartApostrophe()
        fun onBackspace(deleteWholeWord: Boolean = false)
        fun onEnter()
        fun onSpace()
        fun onCursorMove(deltaChars: Int)
        fun onScriptSwitched(newScript: ScriptType)
        fun onEmojiPanelToggle()
    }

    var actionListener: KeyboardActionListener? = null
    val habitTracker = UserHabitTracker(context)
    val dynamicHitboxEngine = DynamicHitboxEngine(habitTracker = habitTracker)
    var hitboxResolver: HitboxResolver = dynamicHitboxEngine

    var currentScript: ScriptType = ScriptType.NEW_LATIN
        private set
    var currentMode: KeyboardMode = KeyboardMode.ALPHABET
        private set
    var shiftState: ShiftState = ShiftState.UNSHIFTED

    var isHapticEnabled: Boolean = true
    var showDebugHitboxes: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var currentWordPrefix: String = ""
        set(value) {
            field = value
            if (width > 0 && height > 0) {
                hitboxResolver.updateDynamicBounds(layoutModel, value, width, height)
                if (showDebugHitboxes) invalidate()
            }
        }

    private var palette: KeyboardPalette = KeyboardTheme.resolvePalette(context)
    private var layoutModel: KeyboardLayoutModel =
        UzbekLayoutFactory.createLayout(currentScript, currentMode)

    // Oldindan ajratilgan Paint va geometriya obyektlari (onDraw ichida GC chaqirilmasligi uchun)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val keyFillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val keyShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val keyTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val hintTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.RIGHT
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val popupPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val popupStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * resources.displayMetrics.density
    }
    private val accentHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val debugStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.0f * resources.displayMetrics.density
    }

    private val tempShadowRect = RectF()
    private val popupRect = RectF()
    private val optionHighlightRect = RectF()
    private val calloutBalloonPath = Path()

    // Bosilgan tugma va iPhone imo-ishoralari (gestures) holati
    private var activeKey: KeySpec? = null
    private var isLongPressActive: Boolean = false
    private var longPressOptions: List<String> = emptyList()
    private var selectedLongPressIndex: Int = 0

    // iOS Trackpad Mode (Spacebar bosib turilganda barcha harflar ko'rinmas bo'lib trekpadga aylanadi)
    private var isTrackpadModeActive: Boolean = false
    private var touchDownX: Float = 0f
    private var touchDownY: Float = 0f
    private var lastCursorStepX: Float = 0f

    // iOS Slide-from-123 va Slide-from-Shift holatlari
    private var isSlideFromModeSwitch: Boolean = false
    private var isSlideFromShift: Boolean = false
    private var lastShiftTapTimeMs: Long = 0L

    private val mainHandler = Handler(Looper.getMainLooper())
    private val density = resources.displayMetrics.density

    private val longPressRunnable = Runnable {
        val key = activeKey ?: return@Runnable
        when {
            key.actionType == KeyActionType.SPACE -> {
                // iPhone Trackpad Mode: tugma yozuvlari yo'qoladi va kursor boshqaruvi yoqiladi
                isTrackpadModeActive = true
                triggerHaptic()
                invalidate()
            }
            key.longPressCandidates.isNotEmpty() -> {
                isLongPressActive = true
                val primary = key.resolveOutputText(shiftState)
                val extras = key.longPressCandidates.map { cand ->
                    if (shiftState == ShiftState.UNSHIFTED) cand else cand.uppercase()
                }
                longPressOptions = listOf(primary) + extras.filter { it != primary }
                selectedLongPressIndex = 0
                triggerHaptic()
                invalidate()
            }
            key.actionType == KeyActionType.BACKSPACE -> {
                actionListener?.onBackspace(deleteWholeWord = true)
                triggerHaptic()
            }
        }
    }

    fun setScript(script: ScriptType) {
        if (currentScript != script || currentMode != KeyboardMode.ALPHABET) {
            currentScript = script
            currentMode = KeyboardMode.ALPHABET
            rebuildLayout()
        }
    }

    fun setShift(newShiftState: ShiftState) {
        if (shiftState != newShiftState) {
            shiftState = newShiftState
            invalidate()
        }
    }

    fun refreshTheme(forceDark: Boolean? = null) {
        palette = KeyboardTheme.resolvePalette(context, forceDark)
        invalidate()
    }

    private fun rebuildLayout() {
        layoutModel = UzbekLayoutFactory.createLayout(currentScript, currentMode)
        if (width > 0 && height > 0) {
            computeKeyGeometry(width, height)
            hitboxResolver.updateDynamicBounds(layoutModel, currentWordPrefix, width, height)
        }
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val desiredWidth = MeasureSpec.getSize(widthMeasureSpec)
        // iPhone iOS 17/18 standart 4 qatorli klaviatura balandligi: 216dp + pastki padding = 228dp
        val desiredHeight = (228f * density).toInt()
        setMeasuredDimension(desiredWidth, desiredHeight)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        computeKeyGeometry(w, h)
        hitboxResolver.updateDynamicBounds(layoutModel, currentWordPrefix, w, h)
    }

    /**
     * Har bir qator va tugmaning iPhone iOS 17/18 proporsiyalariga mos piksel koordinatalarini hisoblaydi
     * (5.5dp burchak radiusi, 6dp gorizontal oraliq, 11dp vertikal qator oralig'i).
     */
    private fun computeKeyGeometry(totalWidth: Int, totalHeight: Int) {
        val rows = layoutModel.rows
        if (rows.isEmpty()) return

        val rowCount = rows.size
        val topPadding = 6f * density
        val bottomPadding = 8f * density
        val horizontalPadding = 3.5f * density
        val keyGapX = 5.5f * density
        val keyGapY = 10.5f * density

        val availableHeight = totalHeight - topPadding - bottomPadding
        val rowHeight = availableHeight / rowCount

        for (rIndex in rows.indices) {
            val row = rows[rIndex]
            val totalWeight = row.sumOf { it.widthWeight.toDouble() }.toFloat()
            val rowAvailableWidth = totalWidth - (horizontalPadding * 2f)
            var currentLeft = horizontalPadding
            val top = topPadding + rIndex * rowHeight + (keyGapY * 0.5f)
            val bottom = topPadding + (rIndex + 1) * rowHeight - (keyGapY * 0.5f)

            for (key in row) {
                val cellWidth = (key.widthWeight / totalWeight) * rowAvailableWidth
                key.visualRect.set(
                    currentLeft + keyGapX * 0.5f,
                    top,
                    currentLeft + cellWidth - keyGapX * 0.5f,
                    bottom
                )
                currentLeft += cellWidth
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        bgPaint.color = palette.keyboardBackground
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // iPhone iOS 17/18 tugma burchak radiusi (5.5dp) va 1dp pastki soya
        val cornerRadius = 5.5f * density
        val shadowOffset = 1.15f * density
        hintTextPaint.textSize = 9.5f * density

        for (key in layoutModel.allKeys) {
            val isPressed = (key === activeKey)

            // 1. Tugma osti soyasi (iOS crisp bottom keycap shadow)
            tempShadowRect.set(key.visualRect)
            tempShadowRect.offset(0f, shadowOffset)
            keyShadowPaint.color = palette.keyShadowColor
            canvas.drawRoundRect(tempShadowRect, cornerRadius, cornerRadius, keyShadowPaint)

            // 2. Tugma foni (iPhone Shift bosilganda oq fonda qora strelka ko'rinadi)
            val isShiftActive = key.actionType == KeyActionType.SHIFT && shiftState != ShiftState.UNSHIFTED
            keyFillPaint.color = when {
                key.actionType == KeyActionType.ENTER -> palette.enterKeyBackground
                isShiftActive -> palette.characterKeyBackground
                isPressed && key.isFunctional -> palette.characterKeyBackground
                isPressed -> palette.characterKeyPressedBackground
                key.isFunctional -> palette.functionalKeyBackground
                else -> palette.characterKeyBackground
            }
            canvas.drawRoundRect(key.visualRect, cornerRadius, cornerRadius, keyFillPaint)

            // 3. iOS Trackpad rejimida barcha tugma yozuvlari ko'rinmas bo'ladi (faqat silliq tugma yuzasi qoladi)
            if (!isTrackpadModeActive) {
                keyTextPaint.color = when {
                    key.actionType == KeyActionType.ENTER -> palette.enterKeyText
                    isShiftActive -> Color.BLACK
                    else -> palette.primaryKeyText
                }

                val label = when (key.actionType) {
                    KeyActionType.SHIFT -> when (shiftState) {
                        ShiftState.UNSHIFTED -> "⇧"
                        ShiftState.SINGLE_SHIFT -> "⬆"
                        ShiftState.CAPS_LOCK -> "⇪"
                    }
                    else -> key.resolveOutputText(shiftState)
                }

                keyTextPaint.textSize = when {
                    key.actionType == KeyActionType.SPACE -> 15.5f * density
                    key.isFunctional && label.length > 1 -> 14.5f * density
                    label.length > 2 -> 14f * density
                    shiftState == ShiftState.UNSHIFTED && !key.isFunctional -> 22.0f * density
                    else -> 20.5f * density
                }

                val textY = key.visualRect.centerY() - ((keyTextPaint.descent() + keyTextPaint.ascent()) / 2f)
                canvas.drawText(label, key.visualRect.centerX(), textY, keyTextPaint)

                // 4. Yuqori o'ng burchakdagi raqam ko'rsatkichi (1..0)
                val hint = key.topHint
                if (hint != null && !key.isFunctional) {
                    hintTextPaint.color = palette.secondaryHintText
                    canvas.drawText(
                        hint,
                        key.visualRect.right - 4f * density,
                        key.visualRect.top + 10.5f * density,
                        hintTextPaint
                    )
                }
            }

            // 5. Debug rejimida dinamik Hitbox chegaralarini chizish
            if (showDebugHitboxes) {
                debugStrokePaint.color = palette.debugHitboxStroke
                canvas.drawRect(key.hitboxRect, debugStrokePaint)
            }
        }

        // 6. iPhone iOS 17/18 Unified Key Callout Balloon (yoki Long-Press Slide-to-Select Accent Bar)
        val currentActive = activeKey
        if (currentActive != null &&
            !currentActive.isFunctional &&
            currentActive.actionType != KeyActionType.SPACE &&
            !isTrackpadModeActive
        ) {
            if (isLongPressActive && longPressOptions.size > 1) {
                drawIosLongPressAccentBar(canvas, currentActive)
            } else {
                drawIosUnifiedKeyCalloutBalloon(canvas, currentActive)
            }
        }
    }

    /**
     * iPhone iOS 17/18 ning mashhur "Qo'ziqorin" (Unified Keycap Callout Balloon) ko'rinishi:
     * Bosilgan tugma asosi kubik Bezier egri chiziqlari orqali yuqoridagi kattalashtirilgan
     * lupa pufagiga uzviy birlashadi.
     */
    private fun drawIosUnifiedKeyCalloutBalloon(canvas: Canvas, key: KeySpec) {
        val base = key.visualRect
        val baseRadius = 5.5f * density
        val topRadius = 9.5f * density

        val balloonWidth = (base.width() * 1.44f).coerceAtLeast(48f * density)
        val balloonHeight = 52f * density
        val balloonTop = (base.top - balloonHeight - 4f * density).coerceAtLeast(2f * density)
        val balloonBottom = base.top - 3f * density

        val balloonLeft = (base.centerX() - balloonWidth * 0.5f)
            .coerceIn(3f * density, width - balloonWidth - 3f * density)
        val balloonRight = balloonLeft + balloonWidth

        calloutBalloonPath.reset()
        // Pastki chap burchakdan boshlaymiz (tugmaning o'z asosi)
        calloutBalloonPath.moveTo(base.left, base.bottom - baseRadius)
        calloutBalloonPath.quadTo(base.left, base.bottom, base.left + baseRadius, base.bottom)
        calloutBalloonPath.lineTo(base.right - baseRadius, base.bottom)
        calloutBalloonPath.quadTo(base.right, base.bottom, base.right, base.bottom - baseRadius)
        calloutBalloonPath.lineTo(base.right, base.top + baseRadius)

        // O'ng bo'yin qismi (Bezier egri chizig'i orqali yuqori pufakka kengayish)
        calloutBalloonPath.cubicTo(
            base.right,
            base.top,
            balloonRight,
            balloonBottom + 4f * density,
            balloonRight,
            balloonBottom - topRadius
        )
        calloutBalloonPath.lineTo(balloonRight, balloonTop + topRadius)
        calloutBalloonPath.quadTo(balloonRight, balloonTop, balloonRight - topRadius, balloonTop)
        calloutBalloonPath.lineTo(balloonLeft + topRadius, balloonTop)
        calloutBalloonPath.quadTo(balloonLeft, balloonTop, balloonLeft, balloonTop + topRadius)
        calloutBalloonPath.lineTo(balloonLeft, balloonBottom - topRadius)

        // Chap bo'yin qismi (yuqori pufakdan tugma asosiga qaytish)
        calloutBalloonPath.cubicTo(
            balloonLeft,
            balloonBottom + 4f * density,
            base.left,
            base.top,
            base.left,
            base.top + baseRadius
        )
        calloutBalloonPath.close()

        popupPaint.color = palette.popupBackground
        canvas.drawPath(calloutBalloonPath, popupPaint)

        popupStrokePaint.color = palette.popupBorder
        canvas.drawPath(calloutBalloonPath, popupStrokePaint)

        val previewText = key.resolveOutputText(shiftState)
        keyTextPaint.color = palette.primaryKeyText
        keyTextPaint.textSize = 27.5f * density
        val textCenterY = (balloonTop + balloonBottom) * 0.5f -
            ((keyTextPaint.descent() + keyTextPaint.ascent()) * 0.5f)
        canvas.drawText(previewText, (balloonLeft + balloonRight) * 0.5f, textCenterY, keyTextPaint)
    }

    /**
     * iPhone iOS 17/18 Long-Press Multi-Option Accent Picker Bar:
     * Barmoqni uzmasdan chapga/o'ngga surish orqali kerakli maxsus harf (oʻ, ö, ў, ş, ç, ğ)
     * iOS ko'k (#007AFF) fonida ajratib ko'rsatiladi va qo'yib yuborilganda yoziladi.
     */
    private fun drawIosLongPressAccentBar(canvas: Canvas, key: KeySpec) {
        val cellWidth = 42f * density
        val barWidth = cellWidth * longPressOptions.size + 8f * density
        val barHeight = 50f * density

        val left = (key.centerX - barWidth * 0.5f)
            .coerceIn(4f * density, width - barWidth - 4f * density)
        val top = (key.visualRect.top - barHeight - 8f * density).coerceAtLeast(2f * density)

        popupRect.set(left, top, left + barWidth, top + barHeight)
        popupPaint.color = palette.popupBackground
        canvas.drawRoundRect(popupRect, 10f * density, 10f * density, popupPaint)

        popupStrokePaint.color = palette.popupBorder
        canvas.drawRoundRect(popupRect, 10f * density, 10f * density, popupStrokePaint)

        for (i in longPressOptions.indices) {
            val cellLeft = left + 4f * density + i * cellWidth
            val cellRight = cellLeft + cellWidth
            val isSelected = (i == selectedLongPressIndex)

            if (isSelected) {
                optionHighlightRect.set(
                    cellLeft + 2f * density,
                    top + 4f * density,
                    cellRight - 2f * density,
                    top + barHeight - 4f * density
                )
                accentHighlightPaint.color = palette.accentColor
                canvas.drawRoundRect(optionHighlightRect, 7f * density, 7f * density, accentHighlightPaint)
            }

            keyTextPaint.color = if (isSelected) Color.WHITE else palette.primaryKeyText
            keyTextPaint.textSize = 21f * density
            val textY = popupRect.centerY() - ((keyTextPaint.descent() + keyTextPaint.ascent()) * 0.5f)
            canvas.drawText(longPressOptions[i], (cellLeft + cellRight) * 0.5f, textY, keyTextPaint)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchDownX = x
                touchDownY = y
                lastCursorStepX = x
                isTrackpadModeActive = false
                isLongPressActive = false
                longPressOptions = emptyList()
                selectedLongPressIndex = 0
                isSlideFromModeSwitch = false
                isSlideFromShift = false

                val hitKey = hitboxResolver.resolveKeyAt(x, y, layoutModel, currentWordPrefix)
                activeKey = hitKey
                if (hitKey != null) {
                    triggerHaptic()

                    // iOS Quick-Symbol Slide: "123" bosilishi bilanoq belgilar qatlami ochiladi;
                    // agar foydalanuvchi barmog'ini uzmay belgiga surib qo'yib yuborsa, avtomatik ABC ga qaytadi!
                    if (hitKey.actionType == KeyActionType.MODE_SWITCH &&
                        currentMode == KeyboardMode.ALPHABET &&
                        hitKey.id == "key_123"
                    ) {
                        isSlideFromModeSwitch = true
                        currentMode = KeyboardMode.SYMBOLS_PRIMARY
                        rebuildLayout()
                        return true
                    }

                    // iOS Quick-Shift Slide: Shift bosilib barmoq uzilmasdan harfga surilsa
                    if (hitKey.actionType == KeyActionType.SHIFT && shiftState == ShiftState.UNSHIFTED) {
                        isSlideFromShift = true
                    }

                    mainHandler.removeCallbacks(longPressRunnable)
                    mainHandler.postDelayed(longPressRunnable, 210L)
                    invalidate()
                }
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val current = activeKey

                // 1. iPhone Trackpad Mode yoki Spacebar ustida gorizontal surish -> kursorni harakatlantirish
                if (isTrackpadModeActive || current?.actionType == KeyActionType.SPACE) {
                    val stepThreshold = 14f * density
                    val dx = x - lastCursorStepX
                    if (abs(dx) >= stepThreshold) {
                        isTrackpadModeActive = true
                        mainHandler.removeCallbacks(longPressRunnable)
                        val steps = (dx / stepThreshold).toInt()
                        if (steps != 0) {
                            actionListener?.onCursorMove(steps)
                            lastCursorStepX += steps * stepThreshold
                            triggerHaptic()
                            invalidate()
                        }
                    }
                    return true
                }

                // 2. iOS Long-Press Accent Bar ochiq bo'lsa -> barmoqni chapga/o'ngga surib variant tanlash
                if (isLongPressActive && longPressOptions.size > 1 && current != null) {
                    val cellWidth = 42f * density
                    val barWidth = cellWidth * longPressOptions.size + 8f * density
                    val barLeft = (current.centerX - barWidth * 0.5f)
                        .coerceIn(4f * density, width - barWidth - 4f * density)
                    val relX = (x - (barLeft + 4f * density)).coerceIn(0f, cellWidth * longPressOptions.size - 1f)
                    val newIndex = (relX / cellWidth).toInt().coerceIn(0, longPressOptions.lastIndex)
                    if (newIndex != selectedLongPressIndex) {
                        selectedLongPressIndex = newIndex
                        triggerHaptic()
                        invalidate()
                    }
                    return true
                }

                // 3. iOS Slide-from-Shift: Shift bosilib harf ustiga surilganda Shift yoqiladi
                if (isSlideFromShift && current?.actionType != KeyActionType.SHIFT && shiftState == ShiftState.UNSHIFTED) {
                    shiftState = ShiftState.SINGLE_SHIFT
                }

                // 4. Oddiy barmoq siljishi (iPhone da barmoq qaysi tugma ustida uzilsa, o'sha tugma yoziladi)
                if (!isLongPressActive) {
                    val newKey = hitboxResolver.resolveKeyAt(x, y, layoutModel, currentWordPrefix)
                    if (newKey !== activeKey) {
                        activeKey = newKey
                        mainHandler.removeCallbacks(longPressRunnable)
                        if (newKey != null) {
                            mainHandler.postDelayed(longPressRunnable, 210L)
                        }
                        invalidate()
                    }
                }
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mainHandler.removeCallbacks(longPressRunnable)
                val releasedKey = activeKey
                val wasLongPress = isLongPressActive
                val wasTrackpad = isTrackpadModeActive
                val wasModeSlide = isSlideFromModeSwitch
                val chosenOptionIndex = selectedLongPressIndex
                val optionsSnapshot = longPressOptions

                activeKey = null
                isLongPressActive = false
                isTrackpadModeActive = false
                isSlideFromModeSwitch = false
                isSlideFromShift = false
                invalidate()

                if (event.actionMasked == MotionEvent.ACTION_UP && releasedKey != null) {
                    // Agar "123" tugmasining o'zida barmoq ko'tarilgan bo'lsa, SYMBOLS_PRIMARY rejimida qoladi
                    if (wasModeSlide && releasedKey.actionType == KeyActionType.MODE_SWITCH) {
                        return true
                    }

                    // Backspace ustida chapga tez surish -> butun so'zni o'chirish
                    if (releasedKey.actionType == KeyActionType.BACKSPACE &&
                        (touchDownX - x) > 40f * density
                    ) {
                        actionListener?.onBackspace(deleteWholeWord = true)
                        return true
                    }

                    if (!wasTrackpad) {
                        if (wasLongPress && optionsSnapshot.isNotEmpty()) {
                            val chosen = optionsSnapshot[chosenOptionIndex.coerceIn(0, optionsSnapshot.lastIndex)]
                            actionListener?.onTextCommit(chosen)
                            consumeSingleShiftIfNeeded()
                        } else {
                            dynamicHitboxEngine.notifyKeyCommitted(releasedKey, x, y, isSensitiveField = false)
                            dispatchKeyExecution(releasedKey)
                        }

                        // iOS Quick-Symbol Slide yakuni: "123" dan belgiga surib qo'yib yuborilganda ABC ga qaytish
                        if (wasModeSlide && !releasedKey.isFunctional) {
                            currentMode = KeyboardMode.ALPHABET
                            rebuildLayout()
                        }
                    }
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun dispatchKeyExecution(key: KeySpec) {
        when (key.actionType) {
            KeyActionType.CHARACTER, KeyActionType.DIGRAPH -> {
                val out = key.resolveOutputText(shiftState)
                actionListener?.onTextCommit(out)
                consumeSingleShiftIfNeeded()
            }
            KeyActionType.SMART_APOSTROPHE -> {
                actionListener?.onSmartApostrophe()
            }
            KeyActionType.SHIFT -> {
                handleShiftTap()
            }
            KeyActionType.BACKSPACE -> {
                dynamicHitboxEngine.notifyBackspacePressed()
                actionListener?.onBackspace(deleteWholeWord = false)
            }
            KeyActionType.SPACE -> {
                actionListener?.onSpace()
            }
            KeyActionType.ENTER -> {
                actionListener?.onEnter()
            }
            KeyActionType.MODE_SWITCH -> {
                currentMode = when (key.id) {
                    "key_123", "sym2_123" -> KeyboardMode.SYMBOLS_PRIMARY
                    "sym_more" -> KeyboardMode.SYMBOLS_SECONDARY
                    else -> KeyboardMode.ALPHABET
                }
                rebuildLayout()
            }
            KeyActionType.SCRIPT_SWITCH -> {
                val nextScript = currentScript.next()
                setScript(nextScript)
                actionListener?.onScriptSwitched(nextScript)
            }
            KeyActionType.EMOJI_TOGGLE -> {
                actionListener?.onEmojiPanelToggle()
            }
        }
    }

    private fun handleShiftTap() {
        val now = System.currentTimeMillis()
        shiftState = when (shiftState) {
            ShiftState.UNSHIFTED -> ShiftState.SINGLE_SHIFT
            ShiftState.SINGLE_SHIFT -> {
                // iPhone kabi ikki marta tez bosilganda Caps Lock (⇪) yoqiladi
                if (now - lastShiftTapTimeMs < 300L) ShiftState.CAPS_LOCK else ShiftState.UNSHIFTED
            }
            ShiftState.CAPS_LOCK -> ShiftState.UNSHIFTED
        }
        lastShiftTapTimeMs = now
        invalidate()
    }

    private fun consumeSingleShiftIfNeeded() {
        if (shiftState == ShiftState.SINGLE_SHIFT) {
            shiftState = ShiftState.UNSHIFTED
            invalidate()
        }
    }

    private fun triggerHaptic() {
        if (isHapticEnabled) {
            performHapticFeedback(
                HapticFeedbackConstants.KEYBOARD_TAP,
                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
            )
        }
    }
}
