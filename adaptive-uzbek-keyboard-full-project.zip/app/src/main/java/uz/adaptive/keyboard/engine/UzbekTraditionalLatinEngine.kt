package uz.adaptive.keyboard.engine

import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.model.ShiftState
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.MODIFIER_TURNED_COMMA
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.RIGHT_SINGLE_QUOTE

/**
 * 2. UzbekTraditionalLatinEngine — Amaldagi o'zbek lotin alifbosi dvigateli:
 *    Sh/sh, Ch/ch, O‘/o‘, G‘/g‘, Ng/ng va 4 xil Unicode apostrof normalizatori bilan.
 */
class UzbekTraditionalLatinEngine : MultiscriptLanguageEngine {

    override val scriptType: ScriptType = ScriptType.TRADITIONAL_LATIN

    override fun normalizeInput(rawText: CharSequence): String {
        return UzbekUnicodeNormalizer.normalizeTraditionalLatin(rawText)
    }

    override fun toCanonicalLexiconKey(word: CharSequence): String {
        return UzbekUnicodeNormalizer.normalizeTraditionalLatin(word).lowercase()
    }

    override fun fromCanonicalLexiconKey(canonicalWord: String): String {
        return UzbekUnicodeNormalizer.normalizeTraditionalLatin(canonicalWord)
    }

    override fun applyCasePattern(word: String, referenceInput: String, shiftState: ShiftState): String {
        if (word.isEmpty()) return word
        val isAllCaps = shiftState == ShiftState.CAPS_LOCK ||
            (referenceInput.length >= 2 && referenceInput.all { !it.isLetter() || it.isUpperCase() })

        if (isAllCaps) {
            return word.uppercase()
        }

        val isTitleCase = shiftState == ShiftState.SINGLE_SHIFT ||
            referenceInput.firstOrNull()?.isUpperCase() == true

        if (isTitleCase) {
            // Sh, Ch, O‘, G‘ bilan boshlanadigan so'zlarda TitleCase qoidasi: "Shahar", "Chiroyli", "O‘zbekiston", "G‘alaba"
            return when {
                word.startsWith("sh") -> "Sh" + word.substring(2)
                word.startsWith("ch") -> "Ch" + word.substring(2)
                word.startsWith("o$MODIFIER_TURNED_COMMA") -> "O$MODIFIER_TURNED_COMMA" + word.substring(2)
                word.startsWith("g$MODIFIER_TURNED_COMMA") -> "G$MODIFIER_TURNED_COMMA" + word.substring(2)
                else -> word.replaceFirstChar { it.uppercaseChar() }
            }
        }
        return word
    }

    override fun isOrthographicallyValid(word: String): Boolean {
        if (word.isBlank()) return false
        val norm = normalizeInput(word)
        for (ch in norm) {
            val lower = ch.lowercaseChar()
            val valid = (lower in 'a'..'z') || ch == MODIFIER_TURNED_COMMA ||
                ch == RIGHT_SINGLE_QUOTE || ch == '-'
            if (!valid) return false
        }
        return true
    }
}
