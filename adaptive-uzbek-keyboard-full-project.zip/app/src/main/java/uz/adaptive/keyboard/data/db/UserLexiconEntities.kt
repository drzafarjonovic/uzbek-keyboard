package uz.adaptive.keyboard.data.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context

/**
 * Foydalanuvchining shaxsiy lug'ati jadvali (kanonik shaklda saqlanadi va uchala alifboda ishlaydi).
 */
@Entity(tableName = "user_words")
data class UserWordEntity(
    @PrimaryKey val canonicalWord: String,
    val frequency: Int = 1,
    val lastUsedTimestamp: Long = System.currentTimeMillis()
)

/**
 * Foydalanuvchining 2-so'zli iboralar (Bigram) tarixi jadvali.
 */
@Entity(tableName = "user_bigrams", primaryKeys = ["prevCanonicalWord", "nextCanonicalWord"])
data class UserBigramEntity(
    val prevCanonicalWord: String,
    val nextCanonicalWord: String,
    val frequency: Int = 1,
    val lastUsedTimestamp: Long = System.currentTimeMillis()
)

@Dao
interface UserLexiconDao {

    @Query("SELECT * FROM user_words WHERE canonicalWord LIKE :prefix || '%' ORDER BY frequency DESC, lastUsedTimestamp DESC LIMIT :limit")
    suspend fun findUserWordsByPrefix(prefix: String, limit: Int = 5): List<UserWordEntity>

    @Query("SELECT * FROM user_bigrams WHERE prevCanonicalWord = :prevWord ORDER BY frequency DESC, lastUsedTimestamp DESC LIMIT :limit")
    suspend fun findNextWords(prevWord: String, limit: Int = 3): List<UserBigramEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWord(entity: UserWordEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBigram(entity: UserBigramEntity)
}

@Database(
    entities = [UserWordEntity::class, UserBigramEntity::class],
    version = 1,
    exportSchema = false
)
abstract class KeyboardDatabase : RoomDatabase() {
    abstract fun userLexiconDao(): UserLexiconDao

    companion object {
        @Volatile
        private var INSTANCE: KeyboardDatabase? = null

        fun getInstance(context: Context): KeyboardDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KeyboardDatabase::class.java,
                    "adaptive_uzbek_keyboard.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
