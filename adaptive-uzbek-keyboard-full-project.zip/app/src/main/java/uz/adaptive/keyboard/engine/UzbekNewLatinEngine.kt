package uz.adaptive.keyboard.engine

import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.model.ShiftState
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.MODIFIER_TURNED_COMMA
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.RIGHT_SINGLE_QUOTE
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS

/**
 * 1. UzbekNewLatinEngine — Yangi o'zbek lotin alifbosi dvigateli:
 *    Ş/ş (Sh), Ç/ç (Ch), Ö/ö (O‘), Ğ/ğ (G‘), ng (o'zgarishsiz qoladi).
 */
class UzbekNewLatinEngine : MultiscriptLanguageEngine {

    override val scriptType: ScriptType = ScriptType.NEW_LATIN

    companion object {
        // S+H birikmasi "Ş" emas, balki alohida "s" va "h" tovushlari bo'lib o'qiladigan o'zaklar
        private val SEPARATE_S_H_ROOTS = setOf(
            "ishoq", "is’hoq", "ashob", "as’hob", "mushaf", "mus’haf", "ashaddiy"
        )
    }

    override fun normalizeInput(rawText: CharSequence): String {
        if (rawText.isEmpty()) return ""
        val sb = StringBuilder(rawText.length)
        var i = 0
        while (i < rawText.length) {
            val ch = rawText[i]
            val next = if (i + 1 < rawText.length) rawText[i + 1] else '\u0000'

            if ((ch == 'O' || ch == 'o') && next in APOSTROPHE_VARIANTS) {
                sb.append(if (ch == 'O') 'Ö' else 'ö')
                i += 2
                continue
            }
            if ((ch == 'G' || ch == 'g') && next in APOSTROPHE_VARIANTS) {
                sb.append(if (ch == 'G') 'Ğ' else 'ğ')
                i += 2
                continue
            }
            if (ch in APOSTROPHE_VARIANTS) {
                sb.append(RIGHT_SINGLE_QUOTE)
                i++
                continue
            }
            sb.append(ch)
            i++
        }
        return sb.toString()
    }

    override fun toCanonicalLexiconKey(word: CharSequence): String {
        val norm = normalizeInput(word).lowercase()
        val sb = StringBuilder(norm.length + 4)
        for (ch in norm) {
            when (ch) {
                'ş' -> sb.append("sh")
                'ç' -> sb.append("ch")
                'ö' -> sb.append("o").append(MODIFIER_TURNED_COMMA)
                'ğ' -> sb.append("g").append(MODIFIER_TURNED_COMMA)
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    override fun fromCanonicalLexiconKey(canonicalWord: String): String {
        if (canonicalWord.isEmpty()) return ""
        val lower = canonicalWord.lowercase()
        val preserveSeparateSH = SEPARATE_S_H_ROOTS.any { lower.startsWith(it) }

        val sb = StringBuilder(canonicalWord.length)
        var i = 0
        while (i < canonicalWord.length) {
            val ch = canonicalWord[i]
            val next = if (i + 1 < canonicalWord.length) canonicalWord[i + 1] else '\u0000'

            if ((ch == 'o' || ch == 'O') && next == MODIFIER_TURNED_COMMA) {
                sb.append(if (ch.isUpperCase()) 'Ö' else 'ö')
                i += 2
                continue
            }
            if ((ch == 'g' || ch == 'G') && next == MODIFIER_TURNED_COMMA) {
                sb.append(if (ch.isUpperCase()) 'Ğ' else 'ğ')
                i += 2
                continue
            }
            if ((ch == 's' || ch == 'S') && (next == 'h' || next == 'H') && !preserveSeparateSH) {
                sb.append(if (ch.isUpperCase()) 'Ş' else 'ş')
                i += 2
                continue
            }
            if ((ch == 'c' || ch == 'C') && (next == 'h' || next == 'H')) {
                sb.append(if (ch.isUpperCase()) 'Ç' else 'ç')
                i += 2
                continue
            }
            sb.append(ch)
            i++
        }
        return sb.toString()
    }

    override fun applyCasePattern(word: String, referenceInput: String, shiftState: ShiftState): String {
        if (word.isEmpty()) return word
        if (shiftState == ShiftState.CAPS_LOCK || (referenceInput.length >= 2 && referenceInput.all { !it.isLetter() || it.isUpperCase() })) {
            return word.uppercase()
        }
        if (shiftState == ShiftState.SINGLE_SHIFT || referenceInput.firstOrNull()?.isUpperCase() == true) {
            return word.replaceFirstChar { it.uppercaseChar() }
        }
        return word
    }

    override fun isOrthographicallyValid(word: String): Boolean {
        if (word.isBlank()) return false
        for (ch in word) {
            val lower = ch.lowercaseChar()
            val valid = (lower in 'a'..'z') || lower == 'ş' || lower == 'ç' ||
                lower == 'ö' || lower == 'ğ' || ch == RIGHT_SINGLE_QUOTE || ch == '-'
            if (!valid) return false
        }
        return true
    }
}
