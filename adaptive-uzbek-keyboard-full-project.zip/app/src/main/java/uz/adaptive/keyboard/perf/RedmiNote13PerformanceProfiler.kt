package uz.adaptive.keyboard.perf

import android.content.ComponentCallbacks2
import android.os.SystemClock
import uz.adaptive.keyboard.nlp.PredictiveTextEngine

/**
 * PHASE 6 — XIAOMI REDMI NOTE 13 (SNAPDRAGON 685, 120Hz AMOLED, 240Hz TOUCH)
 * UNUMDORLIK PROFILERI VA XOTIRA OPTIMALLASHTIRUVCHISI.
 *
 * Texnik mezonlar (SLAs):
 * - 120Hz AMOLED Frame Budget: <= 8.33 ms (8 333 333 ns)
 * - 240Hz Touch Sampling Interval: <= 4.16 ms (4 166 666 ns)
 * - Bayesian-Voronoi Hitbox qidiruvi: <= 0.35 ms (350 000 ns)
 * - 100 816 so'zlik `soz-ustasi.html` lug'atidan bashorat olish: <= 1.50 ms
 * - Maksimal RAM (PSS) sarfi: <= 22 MB (GC Pause = 0 ms `onDraw` va `onTouchEvent` ichida)
 */
data class PerformanceSnapshot(
    val sampleCount: Int,
    val avgTouchResolveUs: Double,
    val p99TouchResolveUs: Double,
    val avgFrameDrawMs: Double,
    val p99FrameDrawMs: Double,
    val avgPredictionMs: Double,
    val p99PredictionMs: Double,
    val droppedFramesOver8_33Ms: Int,
    val estimatedHeapUsedKb: Long
)

class RedmiNote13PerformanceProfiler(
    private val ringBufferSize: Int = 256
) {

    // Zero-allocation ibtidoiy halqa buferlari (GC bosimini 0 ga tushirish uchun)
    private val touchResolveSamplesNs = LongArray(ringBufferSize)
    private val frameDrawSamplesNs = LongArray(ringBufferSize)
    private val predictionSamplesNs = LongArray(ringBufferSize)

    private var touchCursor = 0
    private var frameCursor = 0
    private var predictionCursor = 0
    private var totalSamplesRecorded = 0
    private var dropped120HzFrames = 0

    companion object {
        const val FRAME_BUDGET_120HZ_NS = 8_333_333L // 8.33 ms
        const val TOUCH_BUDGET_240HZ_NS = 4_166_666L // 4.16 ms
        const val HITBOX_TARGET_NS = 350_000L        // 0.35 ms
    }

    inline fun <T> measureTouchResolve(block: () -> T): T {
        val start = SystemClock.elapsedRealtimeNanos()
        val result = block()
        val elapsed = SystemClock.elapsedRealtimeNanos() - start
        recordTouchResolveNs(elapsed)
        return result
    }

    inline fun <T> measureFrameDraw(block: () -> T): T {
        val start = SystemClock.elapsedRealtimeNanos()
        val result = block()
        val elapsed = SystemClock.elapsedRealtimeNanos() - start
        recordFrameDrawNs(elapsed)
        return result
    }

    inline fun <T> measurePrediction(block: () -> T): T {
        val start = SystemClock.elapsedRealtimeNanos()
        val result = block()
        val elapsed = SystemClock.elapsedRealtimeNanos() - start
        recordPredictionNs(elapsed)
        return result
    }

    fun recordTouchResolveNs(durationNs: Long) {
        touchResolveSamplesNs[touchCursor] = durationNs
        touchCursor = (touchCursor + 1) % ringBufferSize
        totalSamplesRecorded++
    }

    fun recordFrameDrawNs(durationNs: Long) {
        frameDrawSamplesNs[frameCursor] = durationNs
        frameCursor = (frameCursor + 1) % ringBufferSize
        if (durationNs > FRAME_BUDGET_120HZ_NS) {
            dropped120HzFrames++
        }
    }

    fun recordPredictionNs(durationNs: Long) {
        predictionSamplesNs[predictionCursor] = durationNs
        predictionCursor = (predictionCursor + 1) % ringBufferSize
    }

    /**
     * MIUI / HyperOS (Redmi Note 13 6GB/8GB RAM) xotira bosimi ostida
     * vaqtinchalik keshlarni xavfsiz tozalash mexanizmi.
     */
    fun onTrimMemory(level: Int, predictiveEngine: PredictiveTextEngine?) {
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
            level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND
        ) {
            // Asosiy 522 KB DAWG lug'at saqlanadi, faqat ikkilamchi ob'ektlar tozalanadi
            System.gc()
        }
    }

    fun captureSnapshot(): PerformanceSnapshot {
        val count = totalSamplesRecorded.coerceAtMost(ringBufferSize).coerceAtLeast(1)

        val touchSlice = touchResolveSamplesNs.take(count).sorted()
        val frameSlice = frameDrawSamplesNs.take(count).sorted()
        val predSlice = predictionSamplesNs.take(count).sorted()

        val p99Idx = ((count - 1) * 0.99).toInt().coerceIn(0, count - 1)

        val runtime = Runtime.getRuntime()
        val usedKb = (runtime.totalMemory() - runtime.freeMemory()) / 1024L

        return PerformanceSnapshot(
            sampleCount = count,
            avgTouchResolveUs = touchSlice.average() / 1_000.0,
            p99TouchResolveUs = touchSlice[p99Idx] / 1_000.0,
            avgFrameDrawMs = frameSlice.average() / 1_000_000.0,
            p99FrameDrawMs = frameSlice[p99Idx] / 1_000_000.0,
            avgPredictionMs = predSlice.average() / 1_000_000.0,
            p99PredictionMs = predSlice[p99Idx] / 1_000_000.0,
            droppedFramesOver8_33Ms = dropped120HzFrames,
            estimatedHeapUsedKb = usedKb
        )
    }
}
