package uz.adaptive.keyboard.nlp

import uz.adaptive.keyboard.engine.MultiscriptLanguageEngine
import uz.adaptive.keyboard.engine.UzbekCyrillicEngine
import uz.adaptive.keyboard.engine.UzbekNewLatinEngine
import uz.adaptive.keyboard.engine.UzbekTraditionalLatinEngine
import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.model.ShiftState
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.MODIFIER_TURNED_COMMA

/**
 * PHASE 4 — PREDICTIVE TEXT & MULTISCRIPT LANGUAGE ENGINE ORCHESTRATOR.
 *
 * `soz-ustasi.html` dagi 100 816 ta so'zlik lug'at, aglyutinativ o'zbek morfologiyasi,
 * vaznli Damerau-Levenshtein avtotuzatish, ko'p ishlatiladigan iboralar (N-gram)
 * va foydalanuvchi shaxsiy lug'atini uchala yozuv tizimida (New Latin, Traditional Latin, Cyrillic)
 * birlashtiruvchi markaziy NLP dvigateli.
 */
class PredictiveTextEngine(
    val dictionary: SozUstasiDictionaryRepository = SozUstasiDictionaryRepository()
) {

    val newLatinEngine = UzbekNewLatinEngine()
    val traditionalLatinEngine = UzbekTraditionalLatinEngine()
    val cyrillicEngine = UzbekCyrillicEngine()

    val morphologyAnalyzer = UzbekMorphologyAnalyzer(dictionary)
    val spellChecker = WeightedSpellChecker(dictionary, morphologyAnalyzer)

    // Foydalanuvchining operativ sessiyadagi shaxsiy so'z va ibora xotirasi (Room DB bilan sinxron)
    private val personalWordFreq = HashMap<String, Int>(256)
    private val phraseBigrams = HashMap<String, List<String>>(128)

    init {
        initializeCommonUzbekPhrases()
    }

    fun getEngineForScript(scriptType: ScriptType): MultiscriptLanguageEngine = when (scriptType) {
        ScriptType.NEW_LATIN -> newLatinEngine
        ScriptType.TRADITIONAL_LATIN -> traditionalLatinEngine
        ScriptType.CYRILLIC -> cyrillicEngine
    }

    private fun initializeCommonUzbekPhrases() {
        val oMod = "o$MODIFIER_TURNED_COMMA"
        val gMod = "g$MODIFIER_TURNED_COMMA"
        phraseBigrams["assalomu"] = listOf("alaykum", "alaykum!", "alaykum,")
        phraseBigrams["va"] = listOf("alaykum", "boshqa", "uning")
        phraseBigrams["${oMod}zbekiston"] = listOf("respublikasi", "milliy", "xalqi")
        phraseBigrams["yangi"] = listOf("${oMod}zbekiston", "yil", "loyiha")
        phraseBigrams["katta"] = listOf("rahmat", "ahamiyatga", "${oMod}zgarishlar")
        phraseBigrams["sog${MODIFIER_TURNED_COMMA}"] = listOf("bo${MODIFIER_TURNED_COMMA}ling", "salomat", "bo${MODIFIER_TURNED_COMMA}lsin")
        phraseBigrams["xayrli"] = listOf("tong", "kun", "kech")
        phraseBigrams["avvalambor"] = listOf("assalomu", "barchangizga", "shuni")
    }

    /**
     * Joriy prefiks va oldingi so'z konteksti asosida uchta eng yaxshi so'z taklifini
     * tanlangan yozuv tizimida (Yangi Lotin, Eski Lotin yoki Kirill) qaytaradi.
     */
    fun getSuggestions(
        currentPrefix: String,
        previousWord: String?,
        scriptType: ScriptType,
        shiftState: ShiftState = ShiftState.UNSHIFTED,
        maxSuggestions: Int = 3
    ): List<String> {
        val engine = getEngineForScript(scriptType)

        // 1. Agar foydalanuvchi hali yangi so'zning birinchi harfini yozmagan bo'lsa -> Keyingi so'z bashorati (Bigram)
        if (currentPrefix.isBlank()) {
            if (!previousWord.isNullOrBlank()) {
                val prevCanonical = engine.toCanonicalLexiconKey(previousWord)
                val nextCandidates = phraseBigrams[prevCanonical]
                if (!nextCandidates.isNullOrEmpty()) {
                    return nextCandidates.take(maxSuggestions).map { cand ->
                        val converted = engine.fromCanonicalLexiconKey(cand)
                        engine.applyCasePattern(converted, "", shiftState)
                    }
                }
            }
            return defaultGreetings(scriptType, shiftState)
        }

        val canonicalPrefix = engine.toCanonicalLexiconKey(currentPrefix)
        val canonicalResults = LinkedHashSet<String>()

        // 2. Shaxsiy lug'atda shu prefiks bilan boshlanadigan yuqori chastotali so'zlar
        personalWordFreq.entries
            .filter { it.key.startsWith(canonicalPrefix) }
            .sortedByDescending { it.value }
            .forEach { canonicalResults.add(it.key) }

        // 3. `soz-ustasi.html` (100 816 ta so'z) bazasidan prefiks qidiruvi
        val dictMatches = dictionary.queryPrefixMatches(canonicalPrefix, maxResults = 6)
        canonicalResults.addAll(dictMatches)

        // 4. Agar kiritilgan so'z to'liq o'zak bo'lsa, aglyutinativ qo'shimchalar (-lar, -ning, -ga, -da) taklif qilinadi
        if (dictionary.containsCanonicalWord(canonicalPrefix)) {
            val inflected = morphologyAnalyzer.generateInflectedForms(canonicalPrefix, maxForms = 3)
            canonicalResults.addAll(inflected)
        }

        // 5. Agar hech qanday prefiks topilmasa -> Vaznli Damerau-Levenshtein Autocorrect ishga tushadi
        if (canonicalResults.isEmpty()) {
            val corrections = spellChecker.suggestCorrections(canonicalPrefix, maxSuggestions)
            canonicalResults.addAll(corrections)
        }

        // 6. Har doim foydalanuvchining o'zi tergan so'zni ham (normalizatsiya qilingan holda) ro'yxatda saqlaymiz
        if (canonicalResults.isEmpty()) {
            canonicalResults.add(canonicalPrefix)
        }

        return canonicalResults
            .take(maxSuggestions)
            .map { canonicalCand ->
                val targetScriptWord = engine.fromCanonicalLexiconKey(canonicalCand)
                engine.applyCasePattern(targetScriptWord, currentPrefix, shiftState)
            }
    }

    /**
     * Foydalanuvchi so'zni yozib bo'lib Bo'shliq (Space) bosganda, shaxsiy lug'atni boyitish
     * (faqat maxfiy bo'lmagan maydonlarda).
     */
    fun learnCommittedWord(
        word: String,
        scriptType: ScriptType,
        isSensitiveField: Boolean
    ) {
        if (isSensitiveField || word.length < 2) return
        val engine = getEngineForScript(scriptType)
        if (!engine.isOrthographicallyValid(word)) return

        val canonical = engine.toCanonicalLexiconKey(word)
        personalWordFreq[canonical] = (personalWordFreq[canonical] ?: 0) + 1
        dictionary.indexCanonicalWord(canonical)
    }

    private fun defaultGreetings(scriptType: ScriptType, shiftState: ShiftState): List<String> {
        val engine = getEngineForScript(scriptType)
        val base = listOf("assalomu", "o${MODIFIER_TURNED_COMMA}zbekiston", "chiroyli")
        return base.map { engine.applyCasePattern(engine.fromCanonicalLexiconKey(it), "A", shiftState) }
    }
}
