package uz.adaptive.keyboard.translit

import org.json.JSONObject
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.MODIFIER_TURNED_COMMA
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.RIGHT_SINGLE_QUOTE
import java.io.InputStream

/**
 * PHASE 5 — Konfiguratsiya orqali boshqariladigan Transliteratsiya Qoidalari modeli.
 * `assets/rules/transliteration_rules.json` faylidan yoki xotiradagi standart konfiguratsiyadan yuklanadi.
 */
data class TransliterationRuleConfig(
    val sHDisambiguationRoots: Set<String> = DEFAULT_SH_DISAMBIGUATION_ROOTS,
    val glottalStopExceptions: Map<String, String> = DEFAULT_GLOTTAL_EXCEPTIONS,
    val modifierORoots: Map<String, String> = DEFAULT_MODIFIER_O_ROOTS,
    val cyrillicTsLoanwords: Set<String> = DEFAULT_CYRILLIC_TS_LOANWORDS,
    val ambiguousHomographs: Map<String, List<String>> = DEFAULT_AMBIGUOUS_HOMOGRAPHS
) {
    companion object {
        private val oMod = "o$MODIFIER_TURNED_COMMA"
        private val gMod = "g$MODIFIER_TURNED_COMMA"
        private val tutuq = "$RIGHT_SINGLE_QUOTE"

        val DEFAULT_SH_DISAMBIGUATION_ROOTS = setOf(
            "is'hoq", "is${tutuq}hoq", "ash'or", "ash${tutuq}or", "mas'h", "mus'haf"
        )

        val DEFAULT_GLOTTAL_EXCEPTIONS = mapOf(
            "malum" to "ma${tutuq}lum",
            "malumot" to "ma${tutuq}lumot",
            "masul" to "mas${tutuq}ul",
            "masuliyat" to "mas${tutuq}uliyat",
            "mani" to "ma${tutuq}ni",
            "mano" to "ma${tutuq}no",
            "manaviy" to "ma${tutuq}naviy",
            "manaviyat" to "ma${tutuq}naviyat",
            "marifat" to "ma${tutuq}rifat",
            "mamuriy" to "ma${tutuq}muriy",
            "maqul" to "ma${tutuq}qul",
            "maruza" to "ma${tutuq}ruza",
            "sanat" to "san${tutuq}at",
            "qatiy" to "qat${tutuq}iy",
            "jurat" to "jur${tutuq}at",
            "talat" to "tal${tutuq}at",
            "inom" to "in${tutuq}om",
            "elon" to "e${tutuq}lon",
            "etibor" to "e${tutuq}tibor",
            "etiqod" to "e${tutuq}tiqod",
            "etirof" to "e${tutuq}tirof",
            "etiroz" to "e${tutuq}tiroz",
            "azo" to "a${tutuq}zo",
            "alo" to "a${tutuq}lo",
            "anana" to "an${tutuq}ana"
        )

        val DEFAULT_MODIFIER_O_ROOTS = mapOf(
            "mojiza" to "m${oMod}jiza",
            "mo${tutuq}jiza" to "m${oMod}jiza",
            "motabar" to "m${oMod}tabar",
            "mo${tutuq}tabar" to "m${oMod}tabar",
            "motadil" to "m${oMod}tadil",
            "mo${tutuq}tadil" to "m${oMod}tadil",
            "mojaz" to "m${oMod}jaz",
            "moljal" to "m${oMod}ljal"
        )

        val DEFAULT_CYRILLIC_TS_LOANWORDS = setOf(
            "tsirk", "tsilindr", "tsikl", "tsement", "tsenzura", "tsex", "tsitrus",
            "tsivilizatsiya", "konstitutsiya", "informatsiya", "operatsiya",
            "organizatsiya", "reaksiya", "stansiya", "politsiya", "investitsiya",
            "innovatsiya", "delegatsiya", "kompensatsiya", "registratsiya",
            "sertifikatsiya", "kvalifikatsiya", "integratsiya", "navigatsiya",
            "avtomatizatsiya", "modernizatsiya", "stabilizatsiya", "transliteratsiya"
        )

        val DEFAULT_AMBIGUOUS_HOMOGRAPHS = mapOf(
            "sher" to listOf("sher", "she${tutuq}r"),
            "sur" to listOf("sur", "su${tutuq}r"),
            "tala" to listOf("tala", "tal${tutuq}a"),
            "ishoq" to listOf("is${tutuq}hoq", "ishoq"),
            "shox" to listOf("shox", "shoh"),
            "xol" to listOf("xol", "hol"),
            "urik" to listOf("${oMod}rik", "urik"),
            "uzbek" to listOf("${oMod}zbek", "uzbek"),
            "ozbek" to listOf("${oMod}zbek", "ozbek"),
            "ozbekiston" to listOf("${oMod}zbekiston", "ozbekiston"),
            "galaba" to listOf("${gMod}alaba", "galaba")
        )

        fun fromJsonStream(inputStream: InputStream): TransliterationRuleConfig {
            val jsonText = inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return fromJsonString(jsonText)
        }

        fun fromJsonString(jsonText: String): TransliterationRuleConfig {
            val root = JSONObject(jsonText)

            val shSet = LinkedHashSet<String>(DEFAULT_SH_DISAMBIGUATION_ROOTS)
            root.optJSONArray("sHDisambiguationRoots")?.let { arr ->
                for (i in 0 until arr.length()) shSet.add(arr.getString(i).lowercase())
            }

            val glottalMap = LinkedHashMap<String, String>(DEFAULT_GLOTTAL_EXCEPTIONS)
            root.optJSONObject("glottalStopExceptions")?.let { obj ->
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    glottalMap[k.lowercase()] = obj.getString(k)
                }
            }

            val modOMap = LinkedHashMap<String, String>(DEFAULT_MODIFIER_O_ROOTS)
            root.optJSONObject("modifierORoots")?.let { obj ->
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    modOMap[k.lowercase()] = obj.getString(k)
                }
            }

            val tsSet = LinkedHashSet<String>(DEFAULT_CYRILLIC_TS_LOANWORDS)
            root.optJSONArray("cyrillicTsLoanwords")?.let { arr ->
                for (i in 0 until arr.length()) tsSet.add(arr.getString(i).lowercase())
            }

            val ambigMap = LinkedHashMap<String, List<String>>(DEFAULT_AMBIGUOUS_HOMOGRAPHS)
            root.optJSONObject("ambiguousHomographs")?.let { obj ->
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val arr = obj.getJSONArray(k)
                    val list = ArrayList<String>(arr.length())
                    for (i in 0 until arr.length()) list.add(arr.getString(i))
                    ambigMap[k.lowercase()] = list
                }
            }

            return TransliterationRuleConfig(
                sHDisambiguationRoots = shSet,
                glottalStopExceptions = glottalMap,
                modifierORoots = modOMap,
                cyrillicTsLoanwords = tsSet,
                ambiguousHomographs = ambigMap
            )
        }
    }
}
