package uz.adaptive.keyboard.engine

import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.model.ShiftState

/**
 * Uchta o'zbek yozuv tizimi (New Latin, Traditional Latin, Cyrillic) modullari uchun
 * yagona lingvistik interfeys.
 */
interface MultiscriptLanguageEngine {
    val scriptType: ScriptType

    /**
     * Kiritilgan xom matnni joriy yozuv tizimining qat'iy Unicode va imlo me'yoriga keltiradi.
     */
    fun normalizeInput(rawText: CharSequence): String

    /**
     * Har qanday yozuvdagi so'zni kanonik baza shakliga (Traditional Latin + U+02BB/U+2019) o'tkazadi.
     * Lug'at (soz-ustasi.html dagi 100 816 ta so'z) aynan shu kanonik shaklda saqlanadi.
     */
    fun toCanonicalLexiconKey(word: CharSequence): String

    /**
     * Kanonik lug'atdagi so'zni joriy yozuv tizimiga (Yangi Lotin, Eski Lotin yoki Kirill) o'giradi.
     */
    fun fromCanonicalLexiconKey(canonicalWord: String): String

    /**
     * So'zni foydalanuvchi kiritgan prefiks registriga (kichik, Bosh harf yoki CAPS LOCK) moslaydi.
     */
    fun applyCasePattern(word: String, referenceInput: String, shiftState: ShiftState): String

    /**
     * So'z joriy yozuv tizimining imlo qoidalariga to'g'ri kelishini tekshiradi.
     */
    fun isOrthographicallyValid(word: String): Boolean
}
