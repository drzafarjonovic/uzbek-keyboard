package uz.adaptive.keyboard.nlp

import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.MODIFIER_TURNED_COMMA

/**
 * O'zbek tilining aglyutinativ morfologiyasini (ildiz + qo'shimchalar: ko'plik, egalik,
 * kelishik, fe'l zamonlari hamda k->g va q->g‘ fonetik o'zgarishlarini) tahlil qiluvchi
 * va yangi so'z shakllarini generatsiya qiluvchi modul.
 */
class UzbekMorphologyAnalyzer(
    private val dictionary: SozUstasiDictionaryRepository
) {

    data class MorphologicalAnalysis(
        val originalCanonical: String,
        val rootStem: String,
        val suffixChain: String,
        val isValidWord: Boolean
    )

    companion object {
        private val gMod = "g$MODIFIER_TURNED_COMMA"

        // Eng ko'p ishlatiladigan o'zbekcha ot va fe'l qo'shimchalari (uzunlik bo'yicha kamayish tartibida)
        private val produktivSuffixes = listOf(
            "larimizdan", "laringizdan", "larimizga", "larimizda", "larimizni",
            "larining", "laridan", "lariga", "larida", "larini", "lardan", "larga", "larda", "larni", "larim", "laring", "lari", "lar",
            "imizdan", "ingizdan", "imizga", "imizda", "imizni", "ingizga", "ingizda", "ingizni",
            "ning", "niki", "dagi", "gacha", "day", "dek", "dan", "ga", "qa", "ka", "da", "ni",
            "imiz", "ingiz", "im", "ing", "si", "i",
            "yapman", "yapsan", "yapti", "yapmiz", "yapsiz", "yaptilar",
            "moqdaman", "moqdasan", "moqda", "moqdamiz", "moqdasiz",
            "ganman", "gansan", "ganmiz", "gansiz", "ganlar", "gan",
            "dim", "ding", "dik", "dingiz", "dilar", "di",
            "ajak", "moqchi", "moq", "ish", "uv", "uvchi", "lik", "chi", "siz", "li", "roq",
            "mi", "chi", "ku", "oq", "yoq"
        )

        // Kontekstli takliflar uchun eng faol davom ettiruvchi qo'shimchalar
        private val topCompletionSuffixes = listOf("lar", "ning", "ni", "ga", "da", "dan", "dagi", "i")
    }

    /**
     * So'zni ildiz (root) va qo'shimchalar zanjiriga (suffixChain) ajratadi.
     * Masalan: "kitoblarimizdan" -> root="kitob", suffix="larimizdan", isValid=true.
     * Fonetik o'zgarishlar: "yuragim" -> root="yurak", "qishloqqa" -> root="qishloq".
     */
    fun analyze(canonicalWord: String): MorphologicalAnalysis {
        if (dictionary.containsCanonicalWord(canonicalWord)) {
            return MorphologicalAnalysis(canonicalWord, canonicalWord, "", true)
        }

        for (sfx in produktivSuffixes) {
            if (canonicalWord.length > sfx.length + 1 && canonicalWord.endsWith(sfx)) {
                val rawStem = canonicalWord.substring(0, canonicalWord.length - sfx.length)
                if (dictionary.containsCanonicalWord(rawStem)) {
                    return MorphologicalAnalysis(canonicalWord, rawStem, sfx, true)
                }

                // k -> g fonetik almashinuvi (masalan: yurag + im -> yurak)
                if (rawStem.endsWith("g")) {
                    val restoredK = rawStem.dropLast(1) + "k"
                    if (dictionary.containsCanonicalWord(restoredK)) {
                        return MorphologicalAnalysis(canonicalWord, restoredK, sfx, true)
                    }
                }

                // q -> g‘ fonetik almashinuvi (masalan: qishlog‘ + im -> qishloq)
                if (rawStem.endsWith(gMod)) {
                    val restoredQ = rawStem.removeSuffix(gMod) + "q"
                    if (dictionary.containsCanonicalWord(restoredQ)) {
                        return MorphologicalAnalysis(canonicalWord, restoredQ, sfx, true)
                    }
                }
            }
        }

        return MorphologicalAnalysis(canonicalWord, canonicalWord, "", false)
    }

    /**
     * Foydalanuvchi to'liq o'zak so'zni yozib bo'lganda (masalan: "oʻzbekiston" yoki "kitob"),
     * grammatik va fonetik jihatdan to'g'ri qo'shimchalangan variantlarni generatsiya qiladi.
     */
    fun generateInflectedForms(canonicalStem: String, maxForms: Int = 4): List<String> {
        if (canonicalStem.length < 2) return emptyList()
        val forms = ArrayList<String>(maxForms)

        for (sfx in topCompletionSuffixes) {
            val combined = when {
                sfx == "ga" && canonicalStem.endsWith("q") -> canonicalStem + "qa"
                sfx == "ga" && (canonicalStem.endsWith("k") || canonicalStem.endsWith("g")) -> canonicalStem + "ka"
                sfx == "i" && canonicalStem.endsWith("k") -> canonicalStem.dropLast(1) + "gi"
                sfx == "i" && canonicalStem.endsWith("q") -> canonicalStem.dropLast(1) + "${gMod}i"
                sfx == "i" && canonicalStem.last() in setOf('a', 'e', 'i', 'o', 'u') -> canonicalStem + "si"
                else -> canonicalStem + sfx
            }
            if (combined != canonicalStem && !forms.contains(combined)) {
                forms.add(combined)
                if (forms.size >= maxForms) break
            }
        }
        return forms
    }
}
