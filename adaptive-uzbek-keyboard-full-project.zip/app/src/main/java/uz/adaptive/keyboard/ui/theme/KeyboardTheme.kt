package uz.adaptive.keyboard.ui.theme

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color

/**
 * iPhone iOS 17/18 (SF Pro / System Keyboard) uslubidagi 1:1 Light Mode va Dark Mode ranglar palitrasi.
 */
data class KeyboardPalette(
    val keyboardBackground: Int,
    val candidateBarBackground: Int,
    val candidateDividerColor: Int,
    val candidateCenterPillBackground: Int,
    val characterKeyBackground: Int,
    val characterKeyPressedBackground: Int,
    val functionalKeyBackground: Int,
    val enterKeyBackground: Int,
    val keyShadowColor: Int,
    val primaryKeyText: Int,
    val secondaryHintText: Int,
    val enterKeyText: Int,
    val popupBackground: Int,
    val popupBorder: Int,
    val accentColor: Int,
    val debugHitboxStroke: Int
)

object KeyboardTheme {

    /**
     * Apple iOS 17/18 Default Light Keyboard Palette (#D1D3D9 backdrop, #FFFFFF alpha keys, #ACB0BC system keys).
     */
    val IOS_LIGHT = KeyboardPalette(
        keyboardBackground = Color.parseColor("#D1D3D9"),
        candidateBarBackground = Color.parseColor("#D1D3D9"),
        candidateDividerColor = Color.parseColor("#BDBEC2"),
        candidateCenterPillBackground = Color.parseColor("#EBEDF0"),
        characterKeyBackground = Color.parseColor("#FFFFFF"),
        characterKeyPressedBackground = Color.parseColor("#E5E6EB"),
        functionalKeyBackground = Color.parseColor("#ACB0BC"),
        enterKeyBackground = Color.parseColor("#007AFF"),
        keyShadowColor = Color.parseColor("#898A8D"),
        primaryKeyText = Color.parseColor("#000000"),
        secondaryHintText = Color.parseColor("#6C6C70"),
        enterKeyText = Color.parseColor("#FFFFFF"),
        popupBackground = Color.parseColor("#FFFFFF"),
        popupBorder = Color.parseColor("#B5B7BF"),
        accentColor = Color.parseColor("#007AFF"),
        debugHitboxStroke = Color.parseColor("#66007AFF")
    )

    /**
     * Apple iOS 17/18 Default Dark Keyboard Palette (#1C1C1E backdrop, #48484A alpha keys, #2C2C2E system keys).
     */
    val AMOLED_DARK = KeyboardPalette(
        keyboardBackground = Color.parseColor("#1C1C1E"),
        candidateBarBackground = Color.parseColor("#1C1C1E"),
        candidateDividerColor = Color.parseColor("#38383A"),
        candidateCenterPillBackground = Color.parseColor("#3A3A3C"),
        characterKeyBackground = Color.parseColor("#48484A"),
        characterKeyPressedBackground = Color.parseColor("#636366"),
        functionalKeyBackground = Color.parseColor("#2C2C2E"),
        enterKeyBackground = Color.parseColor("#0A84FF"),
        keyShadowColor = Color.parseColor("#000000"),
        primaryKeyText = Color.parseColor("#FFFFFF"),
        secondaryHintText = Color.parseColor("#98989D"),
        enterKeyText = Color.parseColor("#FFFFFF"),
        popupBackground = Color.parseColor("#545458"),
        popupBorder = Color.parseColor("#6C6C70"),
        accentColor = Color.parseColor("#0A84FF"),
        debugHitboxStroke = Color.parseColor("#880A84FF")
    )

    fun resolvePalette(context: Context, forceDark: Boolean? = null): KeyboardPalette {
        if (forceDark != null) {
            return if (forceDark) AMOLED_DARK else IOS_LIGHT
        }
        val nightModeFlags = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) AMOLED_DARK else IOS_LIGHT
    }
}
