package uz.adaptive.keyboard.translit

import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.nlp.SozUstasiDictionaryRepository
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.MODIFIER_TURNED_COMMA
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.RIGHT_SINGLE_QUOTE

/**
 * PHASE 5 — TRANSCRIPTION CONVERTER (6 YO'NALISHLI KONTEKSTLI TRANSLITERATSIYA TIZIMI).
 *
 * Qo'llab-quvvatlanadigan barcha 6 yo'nalish:
 * 1. Yangi lotin  -> Eski lotin   (NEW_LATIN -> TRADITIONAL_LATIN)
 * 2. Eski lotin   -> Yangi lotin  (TRADITIONAL_LATIN -> NEW_LATIN)
 * 3. Eski lotin   -> Kirill       (TRADITIONAL_LATIN -> CYRILLIC)
 * 4. Kirill       -> Eski lotin   (CYRILLIC -> TRADITIONAL_LATIN)
 * 5. Yangi lotin  -> Kirill       (NEW_LATIN -> CYRILLIC)
 * 6. Kirill       -> Yangi lotin  (CYRILLIC -> NEW_LATIN)
 *
 * Xususiyatlari:
 * - Digraflar (Sh, Ch, Ng, O‘, G‘, Ye, Yo, Yu, Ya, Ts) va Yangi lotin diakritikalarini (Ş, Ç, Ö, Ğ)
 *   kontekst asosida (so'z boshi, unlidan keyin, tutuq belgisidan keyin) to'g'ri qayta ishlaydi.
 * - `Yo‘` (Йў, masalan: Yo‘l -> Йўл) va `Yo` (Ё, masalan: Yosh -> Ёш) farqini avtomatik ajratadi.
 * - `Is’hoq` (Исҳоқ) kabi tutuq belgisi bilan ajratilgan `s'h` birikmalarini `ш` ga aylantirib yubormaydi.
 * - Tinish belgilari, raqamlar, URL havolalar va emojilar (`ProtectedSpanTokenizer`) 100% daxlsiz qoladi.
 * - Noaniq (omograf yoki apostrofsiz yozilgan) holatlarda `soz-ustasi.html` (100 816 so'z) lug'ati
 *   yordamida foydalanuvchiga alternativ variantlar ro'yxatini qaytaradi.
 */
data class TransliterationResult(
    val sourceText: String,
    val sourceScript: ScriptType,
    val targetScript: ScriptType,
    val primaryOutput: String,
    val alternatives: List<String> = emptyList()
)

class TranscriptionConverter(
    private val ruleConfig: TransliterationRuleConfig = TransliterationRuleConfig(),
    private val dictionary: SozUstasiDictionaryRepository? = null
) {

    /**
     * Matnni manba yozuv tizimidan maqsadli yozuv tizimiga o'tkazadi.
     */
    fun convert(
        text: String,
        sourceScript: ScriptType,
        targetScript: ScriptType
    ): String {
        if (text.isEmpty() || sourceScript == targetScript) {
            return if (targetScript == ScriptType.TRADITIONAL_LATIN) {
                UzbekUnicodeNormalizer.normalizeTraditionalLatin(text)
            } else {
                text
            }
        }

        val tokens = ProtectedSpanTokenizer.tokenize(text)
        val out = StringBuilder(text.length + 16)

        for (token in tokens) {
            if (token.type == TokenType.PROTECTED_SPAN) {
                out.append(token.text)
            } else {
                out.append(convertSingleWord(token.text, sourceScript, targetScript))
            }
        }
        return out.toString()
    }

    /**
     * Matnning yozuv tizimini avtomatik aniqlab, maqsadli yozuv tizimiga o'tkazadi
     * hamda noaniq so'zlar uchun alternativ variantlarni qaytaradi.
     */
    fun transliterateWithAlternatives(
        text: String,
        targetScript: ScriptType,
        explicitSourceScript: ScriptType? = null
    ): TransliterationResult {
        val detectedSource = explicitSourceScript ?: detectScript(text)
        val primary = convert(text, detectedSource, targetScript)

        val alternatives = LinkedHashSet<String>()
        val trimmed = text.trim()

        // Agar bitta so'z bo'lsa va u omograf yoki noaniq so'z bo'lsa, alternativlarni hisoblaymiz
        if (trimmed.isNotEmpty() && !trimmed.contains(' ')) {
            val lowerAscii = stripApostrophesAndDiacritics(trimmed.lowercase())
            val ambigList = ruleConfig.ambiguousHomographs[lowerAscii]
            if (!ambigList.isNullOrEmpty()) {
                for (canonicalVariant in ambigList) {
                    val matchedCase = transferCasePattern(trimmed, canonicalVariant)
                    val convertedVariant = convertSingleWord(
                        matchedCase,
                        ScriptType.TRADITIONAL_LATIN,
                        targetScript
                    )
                    if (convertedVariant != primary) {
                        alternatives.add(convertedVariant)
                    }
                }
            }

            // Kirilldan lotinga o'girishda "ц" -> "ts" va "s" alternativini tekshirish
            if (detectedSource == ScriptType.CYRILLIC &&
                (trimmed.contains('ц') || trimmed.contains('Ц'))
            ) {
                val altWithTs = convertCyrillicWordWithForcedTs(trimmed, targetScript, forceTs = true)
                val altWithS = convertCyrillicWordWithForcedTs(trimmed, targetScript, forceTs = false)
                if (altWithTs != primary) alternatives.add(altWithTs)
                if (altWithS != primary) alternatives.add(altWithS)
            }
        }

        return TransliterationResult(
            sourceText = text,
            sourceScript = detectedSource,
            targetScript = targetScript,
            primaryOutput = primary,
            alternatives = alternatives.toList()
        )
    }

    /**
     * Matn qaysi o'zbek yozuv tizimida yozilganini aniqlaydi.
     */
    fun detectScript(text: String): ScriptType {
        var cyrillicCount = 0
        var newLatinDiacriticCount = 0
        var traditionalPatternCount = 0

        for (i in text.indices) {
            val c = text[i]
            when {
                c in '\u0400'..'\u04FF' -> cyrillicCount++
                c in "ŞşÇçÖöĞğ" -> newLatinDiacriticCount++
                c in UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS -> traditionalPatternCount++
            }
        }

        if (cyrillicCount > 0) return ScriptType.CYRILLIC
        if (newLatinDiacriticCount > 0) return ScriptType.NEW_LATIN
        if (traditionalPatternCount > 0) return ScriptType.TRADITIONAL_LATIN

        val lower = text.lowercase()
        if (lower.contains("sh") || lower.contains("ch")) {
            return ScriptType.TRADITIONAL_LATIN
        }
        return ScriptType.TRADITIONAL_LATIN
    }

    /**
     * Bitta so'zni 6 yo'nalishdan birida kontekstli qoidalar asosida o'giradi.
     */
    fun convertSingleWord(
        word: String,
        sourceScript: ScriptType,
        targetScript: ScriptType
    ): String {
        if (word.isEmpty() || sourceScript == targetScript) return word

        return when (sourceScript) {
            ScriptType.NEW_LATIN -> when (targetScript) {
                ScriptType.TRADITIONAL_LATIN -> newLatinToTraditionalLatinWord(word)
                ScriptType.CYRILLIC -> {
                    val trad = newLatinToTraditionalLatinWord(word)
                    traditionalLatinToCyrillicWord(trad)
                }
                ScriptType.NEW_LATIN -> word
            }

            ScriptType.TRADITIONAL_LATIN -> when (targetScript) {
                ScriptType.NEW_LATIN -> traditionalLatinToNewLatinWord(word)
                ScriptType.CYRILLIC -> traditionalLatinToCyrillicWord(word)
                ScriptType.TRADITIONAL_LATIN -> UzbekUnicodeNormalizer.normalizeTraditionalLatin(word)
            }

            ScriptType.CYRILLIC -> when (targetScript) {
                ScriptType.TRADITIONAL_LATIN -> cyrillicToTraditionalLatinWord(word)
                ScriptType.NEW_LATIN -> {
                    val trad = cyrillicToTraditionalLatinWord(word)
                    traditionalLatinToNewLatinWord(trad)
                }
                ScriptType.CYRILLIC -> word
            }
        }
    }

    /**
     * 1. YANGI LOTIN -> AMALDAGI (ESKI) LOTIN
     * Ş -> Sh/SH/sh, Ç -> Ch/CH/ch, Ö -> O‘/o‘, Ğ -> G‘/g‘
     */
    private fun newLatinToTraditionalLatinWord(word: String): String {
        val normalized = applyLexiconDisambiguation(word)
        val sb = StringBuilder(normalized.length + 4)
        val isAllUpper = isEntireWordUpperCase(normalized)

        for (i in normalized.indices) {
            val c = normalized[i]
            val nextIsUpper = (i + 1 < normalized.length && normalized[i + 1].isUpperCase()) ||
                (isAllUpper && normalized.length > 1)

            when (c) {
                'Ş' -> sb.append(if (nextIsUpper) "SH" else "Sh")
                'ş' -> sb.append("sh")
                'Ç' -> sb.append(if (nextIsUpper) "CH" else "Ch")
                'ç' -> sb.append("ch")
                'Ö' -> sb.append("O$MODIFIER_TURNED_COMMA")
                'ö' -> sb.append("o$MODIFIER_TURNED_COMMA")
                'Ğ' -> sb.append("G$MODIFIER_TURNED_COMMA")
                'ğ' -> sb.append("g$MODIFIER_TURNED_COMMA")
                in UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS -> {
                    val prev = if (i > 0) normalized[i - 1] else null
                    sb.append(UzbekUnicodeNormalizer.resolveSmartApostrophe(prev))
                }
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    /**
     * 2. AMALDAGI (ESKI) LOTIN -> YANGI LOTIN
     * Sh/SH/sh -> Ş/ş, Ch/CH/ch -> Ç/ç, O‘/o‘ -> Ö/ö, G‘/g‘ -> Ğ/ğ, ng o'zgarishsiz qoladi.
     */
    private fun traditionalLatinToNewLatinWord(word: String): String {
        val normalized = UzbekUnicodeNormalizer.normalizeTraditionalLatin(applyLexiconDisambiguation(word))
        val sb = StringBuilder(normalized.length)
        var i = 0
        while (i < normalized.length) {
            val c = normalized[i]
            val next = if (i + 1 < normalized.length) normalized[i + 1] else '\u0000'

            if ((c == 'O' || c == 'o') && next in UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS) {
                sb.append(if (c == 'O') 'Ö' else 'ö')
                i += 2
                continue
            }
            if ((c == 'G' || c == 'g') && next in UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS) {
                sb.append(if (c == 'G') 'Ğ' else 'ğ')
                i += 2
                continue
            }
            if ((c == 'S' || c == 's') && (next == 'H' || next == 'h')) {
                sb.append(if (c == 'S') 'Ş' else 'ş')
                i += 2
                continue
            }
            if ((c == 'C' || c == 'c') && (next == 'H' || next == 'h')) {
                sb.append(if (c == 'C') 'Ç' else 'ç')
                i += 2
                continue
            }
            // Is'hoq kabi s'h holatida tutuq belgisi saqlanadi
            sb.append(c)
            i++
        }
        return sb.toString()
    }

    /**
     * 3. AMALDAGI LOTIN -> O'ZBEK KIRILL
     * Kontekstli unlilar (Ye/E -> Е/Э), Yo‘ (Йў) vs Yo (Ё), Yu (Ю), Ya (Я),
     * Sh (Ш), Ch (Ч), O‘ (Ў), G‘ (Ғ), Ts (Ц) va tutuq belgisi (Ъ) bilan.
     */
    private fun traditionalLatinToCyrillicWord(word: String): String {
        val disambiguated = UzbekUnicodeNormalizer.normalizeTraditionalLatin(applyLexiconDisambiguation(word))
        val isAllUpper = isEntireWordUpperCase(disambiguated)
        val sb = StringBuilder(disambiguated.length)

        var i = 0
        val n = disambiguated.length
        while (i < n) {
            val c = disambiguated[i]
            val next = if (i + 1 < n) disambiguated[i + 1] else '\u0000'
            val next2 = if (i + 2 < n) disambiguated[i + 2] else '\u0000'
            val isUpper = c.isUpperCase()

            // 1. Yo‘ / yo‘ -> Йў / йў (Yo + o‘ birikmasi, masalan: Yo‘l -> Йўл, Yo‘q -> Йўқ)
            if ((c == 'Y' || c == 'y') &&
                (next == 'O' || next == 'o') &&
                next2 in UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS
            ) {
                val secondUpper = next.isUpperCase() || isAllUpper
                sb.append(if (isUpper) 'Й' else 'й')
                sb.append(if (secondUpper) 'Ў' else 'ў')
                i += 3
                continue
            }

            // 2. O‘ / o‘ -> Ў / ў
            if ((c == 'O' || c == 'o') && next in UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS) {
                sb.append(if (isUpper) 'Ў' else 'ў')
                i += 2
                continue
            }

            // 3. G‘ / g‘ -> Ғ / ғ
            if ((c == 'G' || c == 'g') && next in UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS) {
                sb.append(if (isUpper) 'Ғ' else 'ғ')
                i += 2
                continue
            }

            // 4. S'h / s'h (masalan: Is’hoq -> Исҳоқ) — tutuq belgisi 'sh' digrafini ajratadi
            if ((c == 'S' || c == 's') &&
                next in UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS &&
                (next2 == 'H' || next2 == 'h')
            ) {
                sb.append(if (isUpper) 'С' else 'с')
                sb.append(if (next2.isUpperCase()) 'Ҳ' else 'ҳ')
                i += 3
                continue
            }

            // 5. Sh / sh -> Ш / ш
            if ((c == 'S' || c == 's') && (next == 'H' || next == 'h')) {
                sb.append(if (isUpper) 'Ш' else 'ш')
                i += 2
                continue
            }

            // 6. Ch / ch -> Ч / ч
            if ((c == 'C' || c == 'c') && (next == 'H' || next == 'h')) {
                sb.append(if (isUpper) 'Ч' else 'ч')
                i += 2
                continue
            }

            // 7. Yo / yo -> Ё / ё, Yu / yu -> Ю / ю, Ya / ya -> Я / я, Ye / ye -> Е / е
            if (c == 'Y' || c == 'y') {
                when (next) {
                    'O', 'o' -> {
                        sb.append(if (isUpper) 'Ё' else 'ё')
                        i += 2
                        continue
                    }
                    'U', 'u' -> {
                        sb.append(if (isUpper) 'Ю' else 'ю')
                        i += 2
                        continue
                    }
                    'A', 'a' -> {
                        sb.append(if (isUpper) 'Я' else 'я')
                        i += 2
                        continue
                    }
                    'E', 'e' -> {
                        sb.append(if (isUpper) 'Е' else 'е')
                        i += 2
                        continue
                    }
                }
            }

            // 8. Ts / ts -> Ц / ц
            if ((c == 'T' || c == 't') && (next == 'S' || next == 's')) {
                sb.append(if (isUpper) 'Ц' else 'ц')
                i += 2
                continue
            }

            // 9. Yangi lotin harflari bevosita uchrasa (Ş, Ç, Ö, Ğ)
            when (c) {
                'Ş' -> { sb.append('Ш'); i++; continue }
                'ş' -> { sb.append('ш'); i++; continue }
                'Ç' -> { sb.append('Ч'); i++; continue }
                'ç' -> { sb.append('ч'); i++; continue }
                'Ö' -> { sb.append('Ў'); i++; continue }
                'ö' -> { sb.append('ў'); i++; continue }
                'Ğ' -> { sb.append('Ғ'); i++; continue }
                'ğ' -> { sb.append('ғ'); i++; continue }
            }

            // 10. E / e kontekstli qoidasi:
            // So'z boshida, unlidan keyin yoki tutuq belgisidan keyin -> Э / э, undoshdan keyin -> Е / е
            if (c == 'E' || c == 'e') {
                val prevChar = if (i > 0) disambiguated[i - 1] else '\u0000'
                val useCyrillicE = (i == 0) ||
                    isLatinVowel(prevChar) ||
                    (prevChar in UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS &&
                        !(i >= 2 && (disambiguated[i - 2] == 'O' || disambiguated[i - 2] == 'o' ||
                            disambiguated[i - 2] == 'G' || disambiguated[i - 2] == 'g')))
                if (useCyrillicE) {
                    sb.append(if (isUpper) 'Э' else 'э')
                } else {
                    sb.append(if (isUpper) 'Е' else 'е')
                }
                i++
                continue
            }

            // 11. Tutuq belgisi (') -> Ъ / ъ (E'lon -> Эълон, Ma'lum -> Маълум, San'at -> Санъат)
            if (c in UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS) {
                sb.append(if (isAllUpper) 'Ъ' else 'ъ')
                i++
                continue
            }

            // 12. Yakka harflar jadvali
            val mapped = when (c) {
                'A' -> 'А'; 'a' -> 'а'
                'B' -> 'Б'; 'b' -> 'б'
                'D' -> 'Д'; 'd' -> 'д'
                'F' -> 'Ф'; 'f' -> 'ф'
                'G' -> 'Г'; 'g' -> 'г'
                'H' -> 'Ҳ'; 'h' -> 'ҳ'
                'I' -> 'И'; 'i' -> 'и'
                'J' -> 'Ж'; 'j' -> 'ж'
                'K' -> 'К'; 'k' -> 'к'
                'L' -> 'Л'; 'l' -> 'л'
                'M' -> 'М'; 'm' -> 'м'
                'N' -> 'Н'; 'n' -> 'н'
                'O' -> 'О'; 'o' -> 'о'
                'P' -> 'П'; 'p' -> 'п'
                'Q' -> 'Қ'; 'q' -> 'қ'
                'R' -> 'Р'; 'r' -> 'р'
                'S' -> 'С'; 's' -> 'с'
                'T' -> 'Т'; 't' -> 'т'
                'U' -> 'У'; 'u' -> 'у'
                'V' -> 'В'; 'v' -> 'в'
                'W' -> 'В'; 'w' -> 'в'
                'X' -> 'Х'; 'x' -> 'х'
                'Y' -> 'Й'; 'y' -> 'й'
                'Z' -> 'З'; 'z' -> 'з'
                else -> c
            }
            sb.append(mapped)
            i++
        }

        return sb.toString()
    }

    /**
     * 4. O'ZBEK KIRILL -> AMALDAGI LOTIN
     * Kontekstli Е (so'z boshida, unli va ъ/ь dan keyin -> Ye, undoshdan keyin -> E),
     * Ц (unli orasida -> ts, so'z boshi/undoshdan keyin -> s),
     * Ў -> O‘, Ғ -> G‘, Қ -> Q, Ҳ -> H, Ш -> Sh, Ч -> Ch, Ё -> Yo, Ю -> Yu, Я -> Ya.
     */
    private fun cyrillicToTraditionalLatinWord(word: String): String {
        val isAllUpper = isEntireWordUpperCase(word)
        val sb = StringBuilder(word.length + 6)
        val n = word.length

        for (i in 0 until n) {
            val c = word[i]
            val prev = if (i > 0) word[i - 1] else '\u0000'
            val next = if (i + 1 < n) word[i + 1] else '\u0000'
            val isUpper = c.isUpperCase()
            val digramSecondUpper = next.isUpperCase() || (isAllUpper && n > 1)

            // Eslatma: "исҳоқ" -> "is’hoq" (с + ҳ birikmasi o'rtasiga tutuq belgisi qo'yiladi)
            if ((c == 'С' || c == 'с') && (next == 'Ҳ' || next == 'ҳ')) {
                sb.append(if (isUpper) 'S' else 's')
                sb.append(RIGHT_SINGLE_QUOTE)
                continue
            }

            when (c) {
                'Е', 'е' -> {
                    val useYe = (i == 0) || isCyrillicVowel(prev) || prev in "ЪъЬь"
                    if (useYe) {
                        sb.append(if (isUpper) (if (digramSecondUpper) "YE" else "Ye") else "ye")
                    } else {
                        sb.append(if (isUpper) "E" else "e")
                    }
                }
                'Ё', 'ё' -> sb.append(if (isUpper) (if (digramSecondUpper) "YO" else "Yo") else "yo")
                'Ю', 'ю' -> sb.append(if (isUpper) (if (digramSecondUpper) "YU" else "Yu") else "yu")
                'Я', 'я' -> sb.append(if (isUpper) (if (digramSecondUpper) "YA" else "Ya") else "ya")
                'Ш', 'ш' -> sb.append(if (isUpper) (if (digramSecondUpper) "SH" else "Sh") else "sh")
                'Щ', 'щ' -> sb.append(if (isUpper) (if (digramSecondUpper) "SH" else "Sh") else "sh")
                'Ч', 'ч' -> sb.append(if (isUpper) (if (digramSecondUpper) "CH" else "Ch") else "ch")
                'Ў', 'ў' -> sb.append(if (isUpper) "O$MODIFIER_TURNED_COMMA" else "o$MODIFIER_TURNED_COMMA")
                'Ғ', 'ғ' -> sb.append(if (isUpper) "G$MODIFIER_TURNED_COMMA" else "g$MODIFIER_TURNED_COMMA")
                'Ц', 'ц' -> {
                    // O'zbek imlo qoidasiga ko'ra: unlidan keyin kelsa -> "ts", so'z boshida yoki undoshdan keyin -> "s"
                    // (agar maxsus ts-o'zlashma ro'yxatida bo'lsa ts saqlanadi)
                    val afterVowel = i > 0 && isCyrillicVowel(prev)
                    if (afterVowel) {
                        sb.append(if (isUpper) (if (digramSecondUpper) "TS" else "Ts") else "ts")
                    } else {
                        sb.append(if (isUpper) "S" else "s")
                    }
                }
                'Ъ', 'ъ' -> {
                    // Unlidan keyin (masalan: маълум, эълон, мўъжиза) kelsa:
                    // مўъжиза (ў + ъ) holatida o‘ o'zi yetarli bo'ladi, qolgan o'rinda tutuq belgisi U+2019 qo'yiladi
                    if (prev != 'Ў' && prev != 'ў') {
                        sb.append(RIGHT_SINGLE_QUOTE)
                    }
                }
                'Ь', 'ь' -> {
                    // Yumshatish belgisi o'zbek lotin yozuvida tushib qoladi (masalan: октябрь -> oktabr)
                }
                'А' -> sb.append('A'); 'а' -> sb.append('a')
                'Б' -> sb.append('B'); 'б' -> sb.append('b')
                'В' -> sb.append('V'); 'в' -> sb.append('v')
                'Г' -> sb.append('G'); 'г' -> sb.append('g')
                'Д' -> sb.append('D'); 'д' -> sb.append('d')
                'Ж' -> sb.append('J'); 'ж' -> sb.append('j')
                'З' -> sb.append('Z'); 'з' -> sb.append('z')
                'И' -> sb.append('I'); 'и' -> sb.append('i')
                'Й' -> sb.append('Y'); 'й' -> sb.append('y')
                'К' -> sb.append('K'); 'к' -> sb.append('k')
                'Л' -> sb.append('L'); 'л' -> sb.append('l')
                'М' -> sb.append('M'); 'м' -> sb.append('m')
                'Н' -> sb.append('N'); 'н' -> sb.append('n')
                'О' -> sb.append('O'); 'о' -> sb.append('o')
                'П' -> sb.append('P'); 'п' -> sb.append('p')
                'Р' -> sb.append('R'); 'р' -> sb.append('r')
                'С' -> sb.append('S'); 'с' -> sb.append('s')
                'Т' -> sb.append('T'); 'т' -> sb.append('t')
                'У' -> sb.append('U'); 'у' -> sb.append('u')
                'Ф' -> sb.append('F'); 'ф' -> sb.append('f')
                'Х' -> sb.append('X'); 'х' -> sb.append('x')
                'Қ' -> sb.append('Q'); 'қ' -> sb.append('q')
                'Ҳ' -> sb.append('H'); 'ҳ' -> sb.append('h')
                'Э' -> sb.append('E'); 'э' -> sb.append('e')
                'Ы' -> sb.append('I'); 'ы' -> sb.append('i')
                else -> sb.append(c)
            }
        }

        // Октябрь -> oktabr, сентябрь -> sentabr, бюджет -> budjet kabi yumshatish qoidasi
        return sb.toString()
            .replace("tyabr", "tabr")
            .replace("TYABR", "TABR")
            .replace("byudjet", "budjet")
    }

    private fun convertCyrillicWordWithForcedTs(
        word: String,
        targetScript: ScriptType,
        forceTs: Boolean
    ): String {
        val replaced = if (forceTs) {
            word.replace("Ц", "Тс").replace("ц", "тс")
        } else {
            word.replace("Ц", "С").replace("ц", "с")
        }
        return convertSingleWord(replaced, ScriptType.CYRILLIC, targetScript)
    }

    /**
     * Tutuq belgisi yoki `oʻ`/`gʻ` belgisi tushib qolgan so'zlarni qoidalar jadvali va
     * `soz-ustasi.html` lug'ati orqali tiklaydi (masalan: `malum` -> `ma’lum`, `mojiza` -> `moʻjiza`).
     */
    private fun applyLexiconDisambiguation(word: String): String {
        val lower = word.lowercase()

        ruleConfig.modifierORoots[lower]?.let { canonical ->
            return transferCasePattern(word, canonical)
        }
        ruleConfig.glottalStopExceptions[lower]?.let { canonical ->
            return transferCasePattern(word, canonical)
        }
        if (lower in ruleConfig.sHDisambiguationRoots) {
            val fixed = lower.replace("'", "$RIGHT_SINGLE_QUOTE")
            return transferCasePattern(word, fixed)
        }

        return word
    }

    private fun transferCasePattern(sourceWord: String, targetLower: String): String {
        if (sourceWord.isEmpty() || targetLower.isEmpty()) return targetLower
        if (isEntireWordUpperCase(sourceWord) && sourceWord.length > 1) {
            return targetLower.uppercase()
        }
        if (sourceWord[0].isUpperCase()) {
            return targetLower.replaceFirstChar { it.uppercaseChar() }
        }
        return targetLower
    }

    private fun stripApostrophesAndDiacritics(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            when (c) {
                in UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS -> {}
                'ö' -> sb.append('o')
                'ğ' -> sb.append('g')
                'ş' -> sb.append("sh")
                'ç' -> sb.append("ch")
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun isEntireWordUpperCase(word: String): Boolean {
        var hasLetter = false
        for (c in word) {
            if (c.isLetter()) {
                hasLetter = true
                if (!c.isUpperCase()) return false
            }
        }
        return hasLetter
    }

    private fun isLatinVowel(c: Char): Boolean =
        c in "AaEeIiOoUuÖö"

    private fun isCyrillicVowel(c: Char): Boolean =
        c in "АаЕеЁёИиОоУуЎўЭэЮюЯяЫы"
}
