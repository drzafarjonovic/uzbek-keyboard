package uz.adaptive.keyboard.model

import android.graphics.RectF

/**
 * Tugma bajaradigan harakat turlari.
 */
enum class KeyActionType {
    CHARACTER,          // Yagona belgi yoki harf (masalan: a, ş, ç, ö, ğ, ў, ғ)
    DIGRAPH,            // Ikki belgili birikma (masalan: Sh/sh/SH, Ch/ch/CH, O'/o', G'/g', Ng/ng)
    SMART_APOSTROPHE,   // Kontekstli apostrof: O/G dan keyin U+02BB (ʻ), unlidan keyin U+2019 (’)
    SHIFT,              // Registr o'zgartirish (bitta bosish -> SINGLE_SHIFT, ikki marta -> CAPS_LOCK)
    BACKSPACE,          // O'chirish (bosib turish yoki chapga surish -> butun so'zni o'chirish)
    SPACE,              // Bo'shliq (gorizontal surish -> kursorni harakatlantirish)
    ENTER,              // Qator tashlash yoki qidiruv/yuborish amali
    MODE_SWITCH,        // 123 / ABC / #+= rejimlari orasida o'tish
    SCRIPT_SWITCH,      // Uchta yozuv tizimi orasida tezkor almashish
    EMOJI_TOGGLE        // Emoji va Clipboard panelini ochish
}

/**
 * Har bir tugmaning o'zgarmas vizual va dinamik sensorli (Hitbox) modeli.
 */
data class KeySpec(
    val id: String,
    val lowerText: String,
    val upperText: String = lowerText.uppercase(),
    val titleCaseText: String = upperText,
    val actionType: KeyActionType = KeyActionType.CHARACTER,
    val widthWeight: Float = 1.0f,
    val isFunctional: Boolean = false,
    val longPressCandidates: List<String> = emptyList(),
    val topHint: String? = null
) {
    // Vizual chizish chegarasi (doimiy o'lcham — iPhone uslubida)
    val visualRect: RectF = RectF()

    // Dinamik sensorli hudud (Phase 3 DynamicHitboxEngine tomonidan kengaytiriladi)
    val hitboxRect: RectF = RectF()

    // Tugmaning vizual markazi
    val centerX: Float get() = visualRect.centerX()
    val centerY: Float get() = visualRect.centerY()

    /**
     * Joriy ShiftState asosida ekranga chiqariladigan yoki kiritiladigan matnni qaytaradi.
     * Digraflar (Sh, Ch, O‘, G‘, Ng) uchun SINGLE_SHIFT da "Sh", CAPS_LOCK da "SH" qaytaradi.
     */
    fun resolveOutputText(shiftState: ShiftState): String = when (shiftState) {
        ShiftState.UNSHIFTED -> lowerText
        ShiftState.SINGLE_SHIFT -> titleCaseText
        ShiftState.CAPS_LOCK -> upperText
    }
}

/**
 * To'liq klaviatura qatorlari modeli.
 */
data class KeyboardLayoutModel(
    val scriptType: ScriptType,
    val mode: KeyboardMode,
    val rows: List<List<KeySpec>>
) {
    val allKeys: List<KeySpec> = rows.flatten()
}
