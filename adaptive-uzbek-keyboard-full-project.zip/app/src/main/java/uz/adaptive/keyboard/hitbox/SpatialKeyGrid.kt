package uz.adaptive.keyboard.hitbox

import uz.adaptive.keyboard.model.KeySpec
import uz.adaptive.keyboard.model.KeyboardLayoutModel

/**
 * Redmi Note 13 ekranidagi klaviatura yuzasini 16x8 fazoviy katakchalarga (Spatial Hash Grid)
 * bo'lib, barmoq tekkan (x, y) nuqta atrofidagi nomzod tugmalarni O(1) vaqtda qaytaruvchi modul.
 */
class SpatialKeyGrid {

    companion object {
        private const val GRID_COLS = 16
        private const val GRID_ROWS = 8
        private const val MAX_CANDIDATES_PER_CELL = 8
    }

    // Har bir katakda maksimal 8 ta yaqin tugma indeksi saqlanadi
    private val cellKeyIndices = Array(GRID_COLS * GRID_ROWS) { IntArray(MAX_CANDIDATES_PER_CELL) { -1 } }
    private val cellKeyCounts = IntArray(GRID_COLS * GRID_ROWS)

    private var gridWidth: Float = 1f
    private var gridHeight: Float = 1f

    /**
     * Layout o'lchami o'zgarganda yoki yangi alifboga o'tilganda 1 marta quriladi.
     */
    fun rebuildGrid(layout: KeyboardLayoutModel, width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        gridWidth = width.toFloat()
        gridHeight = height.toFloat()

        val cellW = gridWidth / GRID_COLS
        val cellH = gridHeight / GRID_ROWS
        val keys = layout.allKeys

        for (c in 0 until GRID_COLS * GRID_ROWS) {
            cellKeyCounts[c] = 0
        }

        val searchRadiusX = cellW * 1.6f
        val searchRadiusY = cellH * 1.6f

        for (row in 0 until GRID_ROWS) {
            val cy = (row + 0.5f) * cellH
            for (col in 0 until GRID_COLS) {
                val cx = (col + 0.5f) * cellW
                val cellIdx = row * GRID_COLS + col
                var count = 0

                for (kIdx in keys.indices) {
                    val r = keys[kIdx].visualRect
                    if (cx >= r.left - searchRadiusX && cx <= r.right + searchRadiusX &&
                        cy >= r.top - searchRadiusY && cy <= r.bottom + searchRadiusY
                    ) {
                        if (count < MAX_CANDIDATES_PER_CELL) {
                            cellKeyIndices[cellIdx][count++] = kIdx
                        }
                    }
                }
                cellKeyCounts[cellIdx] = count
            }
        }
    }

    /**
     * Berilgan (x, y) koordinata tushgan katakdagi nomzod tugma indekslarini qaytaradi.
     */
    fun queryCandidateIndices(x: Float, y: Float, outIndices: IntArray): Int {
        val col = ((x / gridWidth) * GRID_COLS).toInt().coerceIn(0, GRID_COLS - 1)
        val row = ((y / gridHeight) * GRID_ROWS).toInt().coerceIn(0, GRID_ROWS - 1)
        val cellIdx = row * GRID_COLS + col
        val count = cellKeyCounts[cellIdx]
        val src = cellKeyIndices[cellIdx]
        for (i in 0 until count) {
            outIndices[i] = src[i]
        }
        return count
    }
}
