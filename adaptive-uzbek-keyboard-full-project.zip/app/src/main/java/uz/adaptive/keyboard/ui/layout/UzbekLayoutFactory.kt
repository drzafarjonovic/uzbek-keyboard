package uz.adaptive.keyboard.ui.layout

import uz.adaptive.keyboard.model.KeyActionType
import uz.adaptive.keyboard.model.KeySpec
import uz.adaptive.keyboard.model.KeyboardLayoutModel
import uz.adaptive.keyboard.model.KeyboardMode
import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.MODIFIER_TURNED_COMMA

/**
 * Redmi Note 13 (1080x2400px, 20:9) uchun uchta o'zbek yozuv tizimi va belgilar qatlamini
 * yaratuvchi fabrika.
 */
object UzbekLayoutFactory {

    fun createLayout(scriptType: ScriptType, mode: KeyboardMode): KeyboardLayoutModel {
        return when (mode) {
            KeyboardMode.ALPHABET -> when (scriptType) {
                ScriptType.NEW_LATIN -> buildNewLatinAlphabet()
                ScriptType.TRADITIONAL_LATIN -> buildTraditionalLatinAlphabet()
                ScriptType.CYRILLIC -> buildCyrillicAlphabet()
            }
            KeyboardMode.SYMBOLS_PRIMARY -> buildPrimarySymbols(scriptType)
            KeyboardMode.SYMBOLS_SECONDARY -> buildSecondarySymbols(scriptType)
            KeyboardMode.EMOJI_CLIPBOARD -> buildNewLatinAlphabet()
        }
    }

    /**
     * 1. YANGI O'ZBEK LOTIN ALIFBOSI LAYOUTI
     * Maxsus harflar: Ş/ş, Ç/ç, Ö/ö, Ğ/ğ; ng o'zgarishsiz qoladi.
     */
    private fun buildNewLatinAlphabet(): KeyboardLayoutModel {
        val row1 = listOf(
            charKey("nl_q", "q", "Q", listOf("1"), "1"),
            charKey("nl_w", "w", "W", listOf("2"), "2"),
            charKey("nl_e", "e", "E", listOf("3", "ë"), "3"),
            charKey("nl_r", "r", "R", listOf("4"), "4"),
            charKey("nl_t", "t", "T", listOf("5"), "5"),
            charKey("nl_y", "y", "Y", listOf("6"), "6"),
            charKey("nl_u", "u", "U", listOf("7", "ü"), "7"),
            charKey("nl_i", "i", "I", listOf("8", "ı"), "8"),
            charKey("nl_o", "o", "O", listOf("9", "ö"), "9"),
            charKey("nl_p", "p", "P", listOf("0"), "0"),
            charKey("nl_g_breve", "ğ", "Ğ", listOf("g‘"))
        )

        val row2 = listOf(
            charKey("nl_a", "a", "A", listOf("@", "â")),
            charKey("nl_s", "s", "S", listOf("ş", "$")),
            charKey("nl_d", "d", "D", listOf("#")),
            charKey("nl_f", "f", "F", listOf("&")),
            charKey("nl_g", "g", "G", listOf("ğ")),
            charKey("nl_h", "h", "H", listOf("-")),
            charKey("nl_j", "j", "J", listOf("+")),
            charKey("nl_k", "k", "K", listOf("(")),
            charKey("nl_l", "l", "L", listOf(")")),
            charKey("nl_o_umlaut", "ö", "Ö", listOf("o‘"))
        )

        val row3 = listOf(
            KeySpec(
                id = "nl_shift",
                lowerText = "⇧",
                upperText = "⇧",
                actionType = KeyActionType.SHIFT,
                widthWeight = 1.25f,
                isFunctional = true
            ),
            charKey("nl_z", "z", "Z"),
            charKey("nl_x", "x", "X"),
            charKey("nl_c", "c", "C", listOf("ç")),
            charKey("nl_v", "v", "V"),
            charKey("nl_b", "b", "B"),
            charKey("nl_n", "n", "N", listOf("ng")),
            charKey("nl_m", "m", "M"),
            charKey("nl_s_cedilla", "ş", "Ş", listOf("sh")),
            charKey("nl_c_cedilla", "ç", "Ç", listOf("ch")),
            KeySpec(
                id = "nl_backspace",
                lowerText = "⌫",
                upperText = "⌫",
                actionType = KeyActionType.BACKSPACE,
                widthWeight = 1.25f,
                isFunctional = true
            )
        )

        val row4 = buildBottomRow(ScriptType.NEW_LATIN, includeSmartApostrophe = false)

        return KeyboardLayoutModel(
            scriptType = ScriptType.NEW_LATIN,
            mode = KeyboardMode.ALPHABET,
            rows = listOf(row1, row2, row3, row4)
        )
    }

    /**
     * 2. AMALDAGI O'ZBEK LOTIN ALIFBOSI LAYOUTI
     * Sh/sh, Ch/ch, O‘/o‘, G‘/g‘, Ng/ng va U+02BB / U+2019 apostrof normalizatsiyasi bilan.
     */
    private fun buildTraditionalLatinAlphabet(): KeyboardLayoutModel {
        val oModLower = "o$MODIFIER_TURNED_COMMA"
        val oModUpper = "O$MODIFIER_TURNED_COMMA"
        val gModLower = "g$MODIFIER_TURNED_COMMA"
        val gModUpper = "G$MODIFIER_TURNED_COMMA"

        val row1 = listOf(
            charKey("tl_q", "q", "Q", listOf("1"), "1"),
            charKey("tl_w", "w", "W", listOf("2"), "2"),
            charKey("tl_e", "e", "E", listOf("3"), "3"),
            charKey("tl_r", "r", "R", listOf("4"), "4"),
            charKey("tl_t", "t", "T", listOf("5"), "5"),
            charKey("tl_y", "y", "Y", listOf("6"), "6"),
            charKey("tl_u", "u", "U", listOf("7"), "7"),
            charKey("tl_i", "i", "I", listOf("8"), "8"),
            charKey("tl_o", "o", "O", listOf("9", oModLower, "ö"), "9"),
            charKey("tl_p", "p", "P", listOf("0"), "0"),
            KeySpec(
                id = "tl_o_mod",
                lowerText = oModLower,
                upperText = oModUpper,
                titleCaseText = oModUpper,
                actionType = KeyActionType.DIGRAPH,
                longPressCandidates = listOf("ö")
            )
        )

        val row2 = listOf(
            charKey("tl_a", "a", "A", listOf("@")),
            charKey("tl_s", "s", "S", listOf("sh", "ş")),
            charKey("tl_d", "d", "D", listOf("#")),
            charKey("tl_f", "f", "F", listOf("&")),
            charKey("tl_g", "g", "G", listOf(gModLower, "ğ")),
            charKey("tl_h", "h", "H", listOf("-")),
            charKey("tl_j", "j", "J", listOf("+")),
            charKey("tl_k", "k", "K", listOf("(")),
            charKey("tl_l", "l", "L", listOf(")")),
            KeySpec(
                id = "tl_g_mod",
                lowerText = gModLower,
                upperText = gModUpper,
                titleCaseText = gModUpper,
                actionType = KeyActionType.DIGRAPH,
                longPressCandidates = listOf("ğ")
            )
        )

        val row3 = listOf(
            KeySpec(
                id = "tl_shift",
                lowerText = "⇧",
                upperText = "⇧",
                actionType = KeyActionType.SHIFT,
                widthWeight = 1.25f,
                isFunctional = true
            ),
            charKey("tl_z", "z", "Z"),
            charKey("tl_x", "x", "X"),
            charKey("tl_c", "c", "C", listOf("ch", "ç")),
            charKey("tl_v", "v", "V"),
            charKey("tl_b", "b", "B"),
            KeySpec(
                id = "tl_n",
                lowerText = "n",
                upperText = "N",
                titleCaseText = "N",
                actionType = KeyActionType.CHARACTER,
                longPressCandidates = listOf("ng")
            ),
            charKey("tl_m", "m", "M"),
            KeySpec(
                id = "tl_sh",
                lowerText = "sh",
                upperText = "SH",
                titleCaseText = "Sh",
                actionType = KeyActionType.DIGRAPH,
                longPressCandidates = listOf("ş")
            ),
            KeySpec(
                id = "tl_ch",
                lowerText = "ch",
                upperText = "CH",
                titleCaseText = "Ch",
                actionType = KeyActionType.DIGRAPH,
                longPressCandidates = listOf("ç")
            ),
            KeySpec(
                id = "tl_backspace",
                lowerText = "⌫",
                upperText = "⌫",
                actionType = KeyActionType.BACKSPACE,
                widthWeight = 1.25f,
                isFunctional = true
            )
        )

        val row4 = buildBottomRow(ScriptType.TRADITIONAL_LATIN, includeSmartApostrophe = true)

        return KeyboardLayoutModel(
            scriptType = ScriptType.TRADITIONAL_LATIN,
            mode = KeyboardMode.ALPHABET,
            rows = listOf(row1, row2, row3, row4)
        )
    }

    /**
     * 3. O'ZBEK KIRILL ALIFBOSI LAYOUTI
     * А Б В Г Д Е Ё Ж З И Й К Л М Н О П Р С Т У Ф Х Ц Ч Ш Ъ Ь Э Ю Я + Ў, Ғ, Қ, Ҳ.
     */
    private fun buildCyrillicAlphabet(): KeyboardLayoutModel {
        val row1 = listOf(
            charKey("cy_y_short", "й", "Й", listOf("1"), "1"),
            charKey("cy_ts", "ц", "Ц", listOf("2"), "2"),
            charKey("cy_u", "у", "У", listOf("3", "ў"), "3"),
            charKey("cy_k", "к", "К", listOf("4", "қ"), "4"),
            charKey("cy_ye", "е", "Е", listOf("5", "ё"), "5"),
            charKey("cy_n", "н", "Н", listOf("6", "нг"), "6"),
            charKey("cy_g", "г", "Г", listOf("7", "ғ"), "7"),
            charKey("cy_sh", "ш", "Ш", listOf("8", "щ"), "8"),
            charKey("cy_u_short", "ў", "Ў", listOf("9"), "9"),
            charKey("cy_z", "з", "З", listOf("0"), "0"),
            charKey("cy_x", "х", "Х", listOf("ҳ")),
            charKey("cy_hard", "ъ", "Ъ", listOf("ь"))
        )

        val row2 = listOf(
            charKey("cy_f", "ф", "Ф"),
            charKey("cy_q", "қ", "Қ", listOf("к")),
            charKey("cy_v", "в", "В"),
            charKey("cy_a", "а", "А"),
            charKey("cy_p", "п", "П"),
            charKey("cy_r", "р", "Р"),
            charKey("cy_o", "о", "О"),
            charKey("cy_l", "л", "Л"),
            charKey("cy_d", "д", "Д"),
            charKey("cy_zh", "ж", "Ж"),
            charKey("cy_e", "э", "Э"),
            charKey("cy_yo", "ё", "Ё")
        )

        val row3 = listOf(
            KeySpec(
                id = "cy_shift",
                lowerText = "⇧",
                upperText = "⇧",
                actionType = KeyActionType.SHIFT,
                widthWeight = 1.25f,
                isFunctional = true
            ),
            charKey("cy_ya", "я", "Я"),
            charKey("cy_ch", "ч", "Ч"),
            charKey("cy_s", "с", "С"),
            charKey("cy_m", "м", "М"),
            charKey("cy_i", "и", "И", listOf("ы")),
            charKey("cy_t", "т", "Т"),
            charKey("cy_soft", "ь", "Ь", listOf("ъ")),
            charKey("cy_b", "б", "Б"),
            charKey("cy_yu", "ю", "Ю"),
            charKey("cy_gh", "ғ", "Ғ"),
            charKey("cy_h", "ҳ", "Ҳ"),
            KeySpec(
                id = "cy_backspace",
                lowerText = "⌫",
                upperText = "⌫",
                actionType = KeyActionType.BACKSPACE,
                widthWeight = 1.25f,
                isFunctional = true
            )
        )

        val row4 = buildBottomRow(ScriptType.CYRILLIC, includeSmartApostrophe = false)

        return KeyboardLayoutModel(
            scriptType = ScriptType.CYRILLIC,
            mode = KeyboardMode.ALPHABET,
            rows = listOf(row1, row2, row3, row4)
        )
    }

    /**
     * Raqamlar va asosiy tinish belgilari qatlami (123).
     */
    private fun buildPrimarySymbols(scriptType: ScriptType): KeyboardLayoutModel {
        val row1 = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0").map {
            charKey("sym_$it", it, it)
        }
        val row2 = listOf("-", "/", ":", ";", "(", ")", "$", "&", "@", """).map {
            charKey("sym_$it", it, it)
        }
        val row3 = listOf(
            KeySpec(
                id = "sym_more",
                lowerText = "#+=",
                upperText = "#+=",
                actionType = KeyActionType.MODE_SWITCH,
                widthWeight = 1.3f,
                isFunctional = true
            ),
            charKey("sym_dot", ".", "."),
            charKey("sym_comma", ",", ","),
            charKey("sym_question", "?", "?"),
            charKey("sym_exclaim", "!", "!"),
            KeySpec(
                id = "sym_smart_apos",
                lowerText = "ʻ",
                upperText = "’",
                actionType = KeyActionType.SMART_APOSTROPHE
            ),
            KeySpec(
                id = "sym_backspace",
                lowerText = "⌫",
                upperText = "⌫",
                actionType = KeyActionType.BACKSPACE,
                widthWeight = 1.3f,
                isFunctional = true
            )
        )
        val row4 = listOf(
            KeySpec(
                id = "sym_abc",
                lowerText = "ABC",
                upperText = "ABC",
                actionType = KeyActionType.MODE_SWITCH,
                widthWeight = 1.3f,
                isFunctional = true
            ),
            KeySpec(
                id = "sym_script",
                lowerText = "🌐 ${scriptType.shortBadge}",
                upperText = "🌐 ${scriptType.shortBadge}",
                actionType = KeyActionType.SCRIPT_SWITCH,
                widthWeight = 1.4f,
                isFunctional = true
            ),
            KeySpec(
                id = "sym_space",
                lowerText = scriptType.spacebarTitle,
                upperText = scriptType.spacebarTitle,
                actionType = KeyActionType.SPACE,
                widthWeight = 4.6f
            ),
            charKey("sym_period", ".", ".", listOf(",", "?", "!", ";", ":"), width = 1.0f),
            KeySpec(
                id = "sym_enter",
                lowerText = "↵",
                upperText = "↵",
                actionType = KeyActionType.ENTER,
                widthWeight = 1.5f,
                isFunctional = true
            )
        )

        return KeyboardLayoutModel(scriptType, KeyboardMode.SYMBOLS_PRIMARY, listOf(row1, row2, row3, row4))
    }

    /**
     * Qo'shimcha matematik va maxsus belgilar qatlami (#+=).
     */
    private fun buildSecondarySymbols(scriptType: ScriptType): KeyboardLayoutModel {
        val row1 = listOf("[", "]", "{", "}", "#", "%", "^", "*", "+", "=").map {
            charKey("sym2_$it", it, it)
        }
        val row2 = listOf("_", "\\", "|", "~", "<", ">", "€", "£", "¥", "•").map {
            charKey("sym2_$it", it, it)
        }
        val row3 = listOf(
            KeySpec(
                id = "sym2_123",
                lowerText = "123",
                upperText = "123",
                actionType = KeyActionType.MODE_SWITCH,
                widthWeight = 1.3f,
                isFunctional = true
            ),
            charKey("sym2_deg", "°", "°"),
            charKey("sym2_sec", "§", "§"),
            charKey("sym2_laquo", "«", "«"),
            charKey("sym2_raquo", "»", "»"),
            charKey("sym2_ellipsis", "…", "…"),
            KeySpec(
                id = "sym2_backspace",
                lowerText = "⌫",
                upperText = "⌫",
                actionType = KeyActionType.BACKSPACE,
                widthWeight = 1.3f,
                isFunctional = true
            )
        )
        val row4 = buildPrimarySymbols(scriptType).rows.last()
        return KeyboardLayoutModel(scriptType, KeyboardMode.SYMBOLS_SECONDARY, listOf(row1, row2, row3, row4))
    }

    private fun buildBottomRow(
        scriptType: ScriptType,
        includeSmartApostrophe: Boolean
    ): List<KeySpec> {
        val list = mutableListOf(
            KeySpec(
                id = "key_123",
                lowerText = "123",
                upperText = "123",
                actionType = KeyActionType.MODE_SWITCH,
                widthWeight = 1.25f,
                isFunctional = true
            ),
            KeySpec(
                id = "key_script_switch",
                lowerText = "🌐 ${scriptType.shortBadge}",
                upperText = "🌐 ${scriptType.shortBadge}",
                actionType = KeyActionType.SCRIPT_SWITCH,
                widthWeight = 1.45f,
                isFunctional = true
            )
        )

        if (includeSmartApostrophe) {
            list.add(
                KeySpec(
                    id = "key_smart_apostrophe",
                    lowerText = "ʻ",
                    upperText = "’",
                    actionType = KeyActionType.SMART_APOSTROPHE,
                    widthWeight = 0.95f,
                    longPressCandidates = listOf("ʻ", "’", "'")
                )
            )
        } else {
            list.add(
                KeySpec(
                    id = "key_emoji",
                    lowerText = "😊",
                    upperText = "😊",
                    actionType = KeyActionType.EMOJI_TOGGLE,
                    widthWeight = 0.95f,
                    isFunctional = true
                )
            )
        }

        list.add(
            KeySpec(
                id = "key_space",
                lowerText = scriptType.spacebarTitle,
                upperText = scriptType.spacebarTitle,
                actionType = KeyActionType.SPACE,
                widthWeight = 4.25f
            )
        )
        list.add(
            charKey(
                id = "key_period",
                lower = ".",
                upper = ",",
                popups = listOf(",", "?", "!", ";", ":", "—"),
                width = 0.95f
            )
        )
        list.add(
            KeySpec(
                id = "key_enter",
                lowerText = "↵",
                upperText = "↵",
                actionType = KeyActionType.ENTER,
                widthWeight = 1.45f,
                isFunctional = true
            )
        )
        return list
    }

    private fun charKey(
        id: String,
        lower: String,
        upper: String,
        popups: List<String> = emptyList(),
        topHint: String? = null,
        width: Float = 1.0f
    ): KeySpec = KeySpec(
        id = id,
        lowerText = lower,
        upperText = upper,
        titleCaseText = upper,
        actionType = KeyActionType.CHARACTER,
        widthWeight = width,
        longPressCandidates = popups,
        topHint = topHint
    )
}
