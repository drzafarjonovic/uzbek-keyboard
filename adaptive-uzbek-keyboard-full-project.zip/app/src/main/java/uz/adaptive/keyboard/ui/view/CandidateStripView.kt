package uz.adaptive.keyboard.ui.view

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.ui.theme.KeyboardTheme

/**
 * iPhone iOS 17/18 uslubidagi 3 ustunli Predictive Text (Bashorat va Transliteratsiya) paneli:
 * - 1px vertikal ajratgichlar (iOS hairline dividers)
 * - Markaziy slotda asosiy avtotuzatish/bashorat varianti (iOS yumaloq pill fonida)
 * - Chap slotda foydalanuvchi yozayotgan literal so'z ("...") yoki 2-variant
 * - O'ng slotda 3-variant yoki kontekstli transliteratsiya / omograf alternativi
 * - Yozuv tizimi indikatori (UZ-NL | UZ-TL | UZ-CY) va bir bosishda transliteratsiya (⇄) tugmasi
 */
class CandidateStripView(context: Context) : LinearLayout(context) {

    interface CandidateStripListener {
        fun onCandidateSelected(word: String, index: Int)
        fun onQuickScriptSelected(scriptType: ScriptType)
        fun onTransliterateSelectionClicked()
    }

    var listener: CandidateStripListener? = null
    private val candidateViews = ArrayList<TextView>(3)
    private val dividerViews = ArrayList<View>(2)
    private val scriptBadgeView: TextView
    private val translitButton: TextView
    private var activeScript: ScriptType = ScriptType.NEW_LATIN
    private val density = resources.displayMetrics.density

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val padH = (6 * density).toInt()
        setPadding(padH, (3 * density).toInt(), padH, (3 * density).toInt())
        minimumHeight = (44 * density).toInt()

        // 1. Yozuv tizimi indikatori (bosilganda keyingi alifboga o'tadi)
        scriptBadgeView = TextView(context).apply {
            text = activeScript.shortBadge
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setPadding((8 * density).toInt(), (5 * density).toInt(), (8 * density).toInt(), (5 * density).toInt())
            gravity = Gravity.CENTER
            setOnClickListener {
                activeScript = activeScript.next()
                text = activeScript.shortBadge
                listener?.onQuickScriptSelected(activeScript)
            }
        }
        addView(scriptBadgeView, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))

        // 2. iPhone uslubidagi 3 ta so'z taklifi ustuni + 1px vertikal ajratgichlar
        for (i in 0 until 3) {
            if (i > 0) {
                val divider = View(context)
                dividerViews.add(divider)
                addView(divider, LayoutParams((1f * density).toInt().coerceAtLeast(1), (22 * density).toInt()))
            }

            val tv = TextView(context).apply {
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding((6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt())
                setOnClickListener {
                    val raw = text.toString().removeSurrounding("\"")
                    if (raw.isNotBlank()) {
                        listener?.onCandidateSelected(raw, i)
                    }
                }
            }
            candidateViews.add(tv)
            val lp = LayoutParams(0, LayoutParams.MATCH_PARENT, 1f).apply {
                marginStart = (3 * density).toInt()
                marginEnd = (3 * density).toInt()
            }
            addView(tv, lp)
        }

        // 3. Tezkor 6-yo'nalishli transliteratsiya tugmasi (⇄)
        translitButton = TextView(context).apply {
            text = "⇄"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setPadding((9 * density).toInt(), (5 * density).toInt(), (9 * density).toInt(), (5 * density).toInt())
            gravity = Gravity.CENTER
            setOnClickListener {
                listener?.onTransliterateSelectionClicked()
            }
        }
        addView(translitButton, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))

        applyTheme()
    }

    fun applyTheme(forceDark: Boolean? = null) {
        val palette = KeyboardTheme.resolvePalette(context, forceDark)
        setBackgroundColor(palette.candidateBarBackground)
        scriptBadgeView.setTextColor(palette.accentColor)
        translitButton.setTextColor(palette.accentColor)

        dividerViews.forEach { it.setBackgroundColor(palette.candidateDividerColor) }

        candidateViews.forEachIndexed { idx, tv ->
            tv.setTextColor(palette.primaryKeyText)
            if (idx == 1) {
                // iPhone markaziy avtotuzatish sloti yumaloq pill foniga ega bo'ladi
                val pill = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 7f * density
                    setColor(palette.candidateCenterPillBackground)
                }
                tv.background = pill
            } else {
                tv.background = null
            }
        }
    }

    fun updateScriptBadge(scriptType: ScriptType) {
        activeScript = scriptType
        scriptBadgeView.text = scriptType.shortBadge
    }

    /**
     * iPhone iOS 17/18 tartibida 3 ta taklifni joylashtiradi:
     * - O'rta slot (`candidateViews[1]`): eng yuqori ehtimolli asosiy so'z (Space bosilganda tanlanishi mumkin)
     * - Chap slot (`candidateViews[0]`): foydalanuvchi tergan literal matn yoki 2-variant
     * - O'ng slot (`candidateViews[2]`): 3-variant yoki transliteratsiya alternativi
     */
    fun setSuggestions(suggestions: List<String>, typedLiteral: String = "") {
        val primary = suggestions.getOrNull(0) ?: ""
        val secondary = suggestions.getOrNull(1) ?: ""
        val tertiary = suggestions.getOrNull(2) ?: ""

        if (typedLiteral.isNotBlank() && primary.isNotBlank() && !primary.equals(typedLiteral, ignoreCase = true)) {
            candidateViews[0].text = "\"$typedLiteral\""
            candidateViews[1].text = primary
            candidateViews[2].text = secondary.ifBlank { tertiary }
        } else {
            candidateViews[0].text = secondary
            candidateViews[1].text = primary
            candidateViews[2].text = tertiary
        }
    }
}
