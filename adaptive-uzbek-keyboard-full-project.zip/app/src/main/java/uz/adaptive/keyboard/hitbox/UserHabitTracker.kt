package uz.adaptive.keyboard.hitbox

import android.content.Context
import android.content.SharedPreferences
import kotlin.math.sqrt

/**
 * Foydalanuvchining individual barmoq bosish odatlarini (har bir tugma markazidan o'rtacha
 * gorizontal/vertikal og'ish dx, dy va dispersiya sigmaX, sigmaY) Eksponensial Sirpanuvchi
 * O'rtacha (EMA, alpha = 0.05) yordamida o'rganuvchi modul.
 *
 * Parol maydonlarida hech qanday ma'lumot yozilmaydi.
 */
class UserHabitTracker(context: Context?) {

    companion object {
        private const val PREFS_NAME = "uz_adaptive_hitbox_habits"
        private const val EMA_ALPHA = 0.05f
        private const val MAX_DRIFT_RATIO = 0.18f // Tugma o'lchamining maksimal ±18% gacha siljishi
    }

    data class KeyTouchProfile(
        var offsetX: Float = 0f,
        var offsetY: Float = 0f,
        var scaleSigmaX: Float = 1.0f,
        var scaleSigmaY: Float = 1.0f,
        var sampleCount: Int = 0
    )

    private val prefs: SharedPreferences? =
        context?.applicationContext?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val profiles = HashMap<String, KeyTouchProfile>(128)

    // Backspace bosilmasdan tasdiqlangan oxirgi tegishni kutish buferi
    private var pendingKeyId: String? = null
    private var pendingRawDx: Float = 0f
    private var pendingRawDy: Float = 0f
    private var pendingKeyWidth: Float = 1f
    private var pendingKeyHeight: Float = 1f

    init {
        loadSavedProfiles()
    }

    fun getProfile(keyId: String): KeyTouchProfile {
        return profiles.getOrPut(keyId) { KeyTouchProfile() }
    }

    /**
     * Harf bosilganda vaqtinchalik buferga yoziladi; agar keyingi harakat Backspace bo'lmasa,
     * u haqiqiy muvaffaqiyatli bosish sifatida EMA profilga qo'shiladi.
     */
    fun recordTentativeTouch(
        keyId: String,
        touchX: Float,
        touchY: Float,
        keyCenterX: Float,
        keyCenterY: Float,
        keyWidth: Float,
        keyHeight: Float,
        isSensitiveField: Boolean
    ) {
        if (isSensitiveField || keyWidth <= 0f || keyHeight <= 0f) {
            clearPendingTouch()
            return
        }

        // Oldingi tasdiqlangan tegishni EMA ga qo'shamiz
        commitPendingTouch()

        pendingKeyId = keyId
        pendingRawDx = touchX - keyCenterX
        pendingRawDy = touchY - keyCenterY
        pendingKeyWidth = keyWidth
        pendingKeyHeight = keyHeight
    }

    /**
     * Foydalanuvchi Backspace bossa, oxirgi bosish xato deb topiladi va profilga kiritilmaydi.
     */
    fun onBackspacePressed() {
        clearPendingTouch()
    }

    fun commitPendingTouch() {
        val kId = pendingKeyId ?: return
        val maxDx = pendingKeyWidth * MAX_DRIFT_RATIO
        val maxDy = pendingKeyHeight * MAX_DRIFT_RATIO

        val clampedDx = pendingRawDx.coerceIn(-maxDx, maxDx)
        val clampedDy = pendingRawDy.coerceIn(-maxDy, maxDy)

        val profile = getProfile(kId)
        if (profile.sampleCount == 0) {
            profile.offsetX = clampedDx * 0.25f
            profile.offsetY = clampedDy * 0.25f
        } else {
            profile.offsetX = (1f - EMA_ALPHA) * profile.offsetX + EMA_ALPHA * clampedDx
            profile.offsetY = (1f - EMA_ALPHA) * profile.offsetY + EMA_ALPHA * clampedDy

            val normErrX = kotlin.math.abs(clampedDx - profile.offsetX) / (pendingKeyWidth * 0.5f)
            val normErrY = kotlin.math.abs(clampedDy - profile.offsetY) / (pendingKeyHeight * 0.5f)
            profile.scaleSigmaX = ((1f - EMA_ALPHA) * profile.scaleSigmaX + EMA_ALPHA * (0.85f + normErrX)).coerceIn(0.75f, 1.30f)
            profile.scaleSigmaY = ((1f - EMA_ALPHA) * profile.scaleSigmaY + EMA_ALPHA * (0.85f + normErrY)).coerceIn(0.75f, 1.30f)
        }
        profile.sampleCount++

        if (profile.sampleCount % 25 == 0) {
            saveProfileToPrefs(kId, profile)
        }
        clearPendingTouch()
    }

    private fun clearPendingTouch() {
        pendingKeyId = null
    }

    private fun loadSavedProfiles() {
        val p = prefs ?: return
        for ((k, v) in p.all) {
            if (v is String) {
                val parts = v.split(",")
                if (parts.size == 5) {
                    val prof = KeyTouchProfile(
                        offsetX = parts[0].toFloatOrNull() ?: 0f,
                        offsetY = parts[1].toFloatOrNull() ?: 0f,
                        scaleSigmaX = parts[2].toFloatOrNull() ?: 1f,
                        scaleSigmaY = parts[3].toFloatOrNull() ?: 1f,
                        sampleCount = parts[4].toIntOrNull() ?: 0
                    )
                    profiles[k] = prof
                }
            }
        }
    }

    private fun saveProfileToPrefs(keyId: String, profile: KeyTouchProfile) {
        prefs?.edit()?.putString(
            keyId,
            "${profile.offsetX},${profile.offsetY},${profile.scaleSigmaX},${profile.scaleSigmaY},${profile.sampleCount}"
        )?.apply()
    }
}
