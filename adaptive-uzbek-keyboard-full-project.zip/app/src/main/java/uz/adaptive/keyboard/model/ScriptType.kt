package uz.adaptive.keyboard.model

/**
 * Uchta o'zbek yozuv tizimini ifodalovchi asosiy enum.
 */
enum class ScriptType(
    val code: String,
    val shortBadge: String,
    val displayTitle: String,
    val spacebarTitle: String
) {
    NEW_LATIN(
        code = "NEW_LATIN",
        shortBadge = "UZ-NL",
        displayTitle = "Yangi Lotin (Ş Ç Ö Ğ)",
        spacebarTitle = "O‘zbek • Yangi Lotin"
    ),
    TRADITIONAL_LATIN(
        code = "TRADITIONAL_LATIN",
        shortBadge = "UZ-TL",
        displayTitle = "Amaldagi Lotin (O‘ G‘ Sh Ch)",
        spacebarTitle = "O‘zbek • Lotin"
    ),
    CYRILLIC(
        code = "CYRILLIC",
        shortBadge = "UZ-CY",
        displayTitle = "Ўзбек Кирилл (Ў Ғ Қ Ҳ)",
        spacebarTitle = "Ўзбек • Кирилл"
    );

    fun next(): ScriptType = when (this) {
        NEW_LATIN -> TRADITIONAL_LATIN
        TRADITIONAL_LATIN -> CYRILLIC
        CYRILLIC -> NEW_LATIN
    }

    companion object {
        fun fromCode(code: String?): ScriptType =
            entries.firstOrNull { it.code == code } ?: NEW_LATIN
    }
}

/**
 * Shift va Caps Lock holat mashinasi.
 */
enum class ShiftState {
    UNSHIFTED,
    SINGLE_SHIFT,
    CAPS_LOCK
}

/**
 * Klaviatura qatlami turi (Harflar, Raqamlar/Belgilar, Ikkinchi belgilar).
 */
enum class KeyboardMode {
    ALPHABET,
    SYMBOLS_PRIMARY,
    SYMBOLS_SECONDARY,
    EMOJI_CLIPBOARD
}
