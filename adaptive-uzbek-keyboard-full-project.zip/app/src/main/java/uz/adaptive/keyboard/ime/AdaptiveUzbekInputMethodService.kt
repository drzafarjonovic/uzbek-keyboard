package uz.adaptive.keyboard.ime

import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.ExtractedTextRequest
import android.view.inputmethod.InputConnection
import android.widget.LinearLayout
import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.model.ShiftState
import uz.adaptive.keyboard.nlp.PredictiveTextEngine
import uz.adaptive.keyboard.translit.TranscriptionConverter
import uz.adaptive.keyboard.translit.TransliterationRuleConfig
import uz.adaptive.keyboard.ui.view.AdaptiveKeyboardView
import uz.adaptive.keyboard.ui.view.CandidateStripView
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer

/**
 * Adaptive Uzbek Keyboard — Asosiy Android InputMethodService (IME) xizmati.
 *
 * iPhone (iOS 17/18) ishlash mexanizmlari + Phase 4 (100 816 so'zlik `soz-ustasi.html` NLP) +
 * Phase 5 (6-yo'nalishli `TranscriptionConverter`):
 * - Bo'sh joy (Space) ikki marta tez bosilganda `". "` (nuqta va bo'sh joy) qo'yish va yangi gapni
 *   bosh harf (`SINGLE_SHIFT`) bilan boshlash (iOS Double-Space Period Shortcut).
 * - Bo'sh joy bosilganda avtotuzatish va darhol Backspace bosilganda asl terilgan so'zni qaytarish
 *   (iOS Undo Autocorrect on Backspace).
 * - `⇄` tugmasi bosilganda belgilangan matnni (Selected Text) yoki joriy kiritilgan matnni
 *   6 yo'nalishda (`Yangi Lotin ↔ Eski Lotin ↔ Kirill`) kontekstli transliteratsiya qilish va
 *   noaniq (omograf) so'zlarning alternativlarini takliflar panelida ko'rsatish.
 */
class AdaptiveUzbekInputMethodService : InputMethodService(),
    AdaptiveKeyboardView.KeyboardActionListener,
    CandidateStripView.CandidateStripListener {

    private lateinit var rootContainer: LinearLayout
    private lateinit var candidateStripView: CandidateStripView
    private lateinit var keyboardView: AdaptiveKeyboardView

    lateinit var predictiveEngine: PredictiveTextEngine
        private set
    lateinit var transcriptionConverter: TranscriptionConverter
        private set

    private val composingBuffer = StringBuilder()
    private var previousCommittedWord: String? = null
    private var isCurrentFieldSensitive: Boolean = false

    // iOS Double-Space Period (". ") va Undo-Autocorrect on Backspace holatlari
    private var lastSpaceTapTimeMs: Long = 0L
    private var lastAutoCorrectedOriginal: String? = null
    private var lastAutoCorrectedReplacement: String? = null

    override fun onCreate() {
        super.onCreate()
        predictiveEngine = PredictiveTextEngine()
        // `assets/dict/uz_canonical_dawg.bin` (100 816 ta so'z) va `assets/rules/transliteration_rules.json` ni yuklash
        runCatching {
            assets.open("dict/uz_canonical_dawg.bin").use { stream ->
                predictiveEngine.dictionary.loadFromBinaryStream(stream)
            }
        }
        val ruleConfig = runCatching {
            assets.open("rules/transliteration_rules.json").use { stream ->
                TransliterationRuleConfig.fromJsonStream(stream)
            }
        }.getOrDefault(TransliterationRuleConfig())

        transcriptionConverter = TranscriptionConverter(
            ruleConfig = ruleConfig,
            dictionary = predictiveEngine.dictionary
        )
    }

    override fun onCreateInputView(): View {
        candidateStripView = CandidateStripView(this).apply {
            listener = this@AdaptiveUzbekInputMethodService
        }
        keyboardView = AdaptiveKeyboardView(this).apply {
            actionListener = this@AdaptiveUzbekInputMethodService
        }

        rootContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(
                candidateStripView,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
            addView(
                keyboardView,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }

        updateDefaultSuggestions()
        return rootContainer
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        isCurrentFieldSensitive = PrivacyGuard.isSensitiveInput(info)
        composingBuffer.clear()
        clearUndoAutocorrectState()

        if (::keyboardView.isInitialized) {
            keyboardView.currentWordPrefix = ""
            keyboardView.refreshTheme()
            updateAutoCapShiftState()
        }
        if (::candidateStripView.isInitialized) {
            candidateStripView.applyTheme()
            updateDefaultSuggestions()
        }
    }

    override fun onTextCommit(text: String) {
        val ic = currentInputConnection ?: return
        clearUndoAutocorrectState()

        val engine = predictiveEngine.getEngineForScript(keyboardView.currentScript)
        val normalized = engine.normalizeInput(text)

        ic.commitText(normalized, 1)
        if (!isCurrentFieldSensitive) {
            if (normalized.length == 1 && normalized[0] in ".!?,;:") {
                if (composingBuffer.isNotEmpty()) {
                    previousCommittedWord = composingBuffer.toString()
                    composingBuffer.clear()
                }
                keyboardView.currentWordPrefix = ""
                updateAutoCapShiftState()
                updateDefaultSuggestions()
            } else {
                composingBuffer.append(normalized)
                keyboardView.currentWordPrefix = composingBuffer.toString()
                updateContextualSuggestions(composingBuffer.toString())
            }
        }
    }

    override fun onSmartApostrophe() {
        val ic = currentInputConnection ?: return
        clearUndoAutocorrectState()

        val beforeText = ic.getTextBeforeCursor(1, 0)
        val prevChar = if (!beforeText.isNullOrEmpty()) beforeText[0] else null
        val resolvedApostrophe = UzbekUnicodeNormalizer.resolveSmartApostrophe(prevChar)
        ic.commitText(resolvedApostrophe, 1)

        if (!isCurrentFieldSensitive) {
            composingBuffer.append(resolvedApostrophe)
            keyboardView.currentWordPrefix = composingBuffer.toString()
            updateContextualSuggestions(composingBuffer.toString())
        }
    }

    override fun onBackspace(deleteWholeWord: Boolean) {
        val ic = currentInputConnection ?: return

        // iPhone Undo-Autocorrect: agar Space bosilganda so'z avtotuzatilgan bo'lsa,
        // darhol Backspace bosilishi asl yozilgan so'zni qaytaradi!
        val orig = lastAutoCorrectedOriginal
        val repl = lastAutoCorrectedReplacement
        if (!deleteWholeWord && orig != null && repl != null && composingBuffer.isEmpty()) {
            val expectedSuffix = "$repl "
            val before = ic.getTextBeforeCursor(expectedSuffix.length, 0)?.toString()
            if (before == expectedSuffix) {
                ic.deleteSurroundingText(expectedSuffix.length, 0)
                ic.commitText("$orig ", 1)
                clearUndoAutocorrectState()
                return
            }
        }
        clearUndoAutocorrectState()

        if (deleteWholeWord) {
            deletePreviousWord(ic)
            composingBuffer.clear()
            keyboardView.currentWordPrefix = ""
            updateAutoCapShiftState()
            updateDefaultSuggestions()
            return
        }

        // Amaldagi lotinda O‘ va G‘ (harf + U+02BB) bir bosishda to'liq o'chirilishi uchun tekshiruv
        val beforeTwo = ic.getTextBeforeCursor(2, 0)
        if (beforeTwo != null && beforeTwo.length == 2) {
            val first = beforeTwo[0]
            val second = beforeTwo[1]
            if ((first == 'O' || first == 'o' || first == 'G' || first == 'g') &&
                second in UzbekUnicodeNormalizer.APOSTROPHE_VARIANTS
            ) {
                ic.deleteSurroundingText(2, 0)
                trimComposingBuffer(2)
                updateAutoCapShiftState()
                return
            }
        }

        ic.deleteSurroundingText(1, 0)
        trimComposingBuffer(1)
        updateAutoCapShiftState()
    }

    private fun deletePreviousWord(ic: InputConnection) {
        val before = ic.getTextBeforeCursor(48, 0) ?: return
        if (before.isEmpty()) return
        var deleteCount = 0
        var i = before.length - 1
        while (i >= 0 && before[i].isWhitespace()) {
            deleteCount++
            i--
        }
        while (i >= 0 && !before[i].isWhitespace()) {
            deleteCount++
            i--
        }
        if (deleteCount > 0) {
            ic.deleteSurroundingText(deleteCount, 0)
        }
    }

    private fun trimComposingBuffer(count: Int) {
        if (composingBuffer.isNotEmpty()) {
            val newLen = (composingBuffer.length - count).coerceAtLeast(0)
            composingBuffer.setLength(newLen)
            keyboardView.currentWordPrefix = composingBuffer.toString()
            updateContextualSuggestions(composingBuffer.toString())
        } else {
            updateDefaultSuggestions()
        }
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        val now = System.currentTimeMillis()

        // 1. iPhone Double-Space Period Shortcut (". "):
        // So'zdan keyin 280ms ichida Space ikki marta bosilsa, oldingi bo'sh joy ". " ga aylanadi va Shift yoqiladi
        if (composingBuffer.isEmpty() && (now - lastSpaceTapTimeMs) <= 280L) {
            val beforeTwo = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
            if (beforeTwo.length == 2 && beforeTwo[1] == ' ' && beforeTwo[0].isLetterOrDigit()) {
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                lastSpaceTapTimeMs = 0L
                clearUndoAutocorrectState()
                keyboardView.setShift(ShiftState.SINGLE_SHIFT)
                updateDefaultSuggestions()
                return
            }
        }

        // 2. Joriy yozilayotgan so'zni tugallash va kerak bo'lsa iPhone kabi apostrof/diakritik avtotuzatish
        if (!isCurrentFieldSensitive && composingBuffer.isNotEmpty()) {
            val typedWord = composingBuffer.toString()
            val suggestions = predictiveEngine.getSuggestions(
                currentPrefix = typedWord,
                previousWord = previousCommittedWord,
                scriptType = keyboardView.currentScript,
                shiftState = keyboardView.shiftState,
                maxSuggestions = 3
            )
            val bestCandidate = suggestions.firstOrNull()
            if (bestCandidate != null && shouldAutoCommitOnSpace(typedWord, bestCandidate)) {
                ic.deleteSurroundingText(typedWord.length, 0)
                ic.commitText("$bestCandidate ", 1)
                lastAutoCorrectedOriginal = typedWord
                lastAutoCorrectedReplacement = bestCandidate
                previousCommittedWord = bestCandidate
                predictiveEngine.learnCommittedWord(bestCandidate, keyboardView.currentScript, false)
            } else {
                ic.commitText(" ", 1)
                clearUndoAutocorrectState()
                previousCommittedWord = typedWord
                predictiveEngine.learnCommittedWord(typedWord, keyboardView.currentScript, false)
            }
            composingBuffer.clear()
            keyboardView.currentWordPrefix = ""
            lastSpaceTapTimeMs = now
            updateDefaultSuggestions()
            return
        }

        ic.commitText(" ", 1)
        composingBuffer.clear()
        keyboardView.currentWordPrefix = ""
        lastSpaceTapTimeMs = now
        updateAutoCapShiftState()
        updateDefaultSuggestions()
    }

    /**
     * iPhone kabi faqat yuqori ishonchlilikdagi imlo/apostrof xatolarida (masalan: `ozbek` -> `Oʻzbek`,
     * `galaba` -> `gʻalaba`, `malumot` -> `ma’lumot`) Space bosilganda avtomatik tuzatadi.
     */
    private fun shouldAutoCommitOnSpace(typed: String, candidate: String): Boolean {
        if (typed.equals(candidate, ignoreCase = true)) return false
        val engine = predictiveEngine.getEngineForScript(keyboardView.currentScript)
        val typedCanon = engine.toCanonicalLexiconKey(typed)
        if (predictiveEngine.dictionary.containsCanonicalWord(typedCanon)) {
            return false // Foydalanuvchi yozgan so'zning o'zi lug'atda to'g'ri mavjud bo'lsa o'zgartirmaymiz
        }
        return kotlin.math.abs(typed.length - candidate.length) <= 2
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        clearUndoAutocorrectState()

        if (!isCurrentFieldSensitive && composingBuffer.isNotEmpty()) {
            previousCommittedWord = composingBuffer.toString()
            predictiveEngine.learnCommittedWord(composingBuffer.toString(), keyboardView.currentScript, false)
        }

        val info = currentInputEditorInfo
        val imeAction = info?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE

        if (imeAction != EditorInfo.IME_ACTION_NONE &&
            imeAction != EditorInfo.IME_ACTION_UNSPECIFIED &&
            (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0
        ) {
            ic.performEditorAction(imeAction)
        } else {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
        composingBuffer.clear()
        keyboardView.currentWordPrefix = ""
        updateAutoCapShiftState()
    }

    override fun onCursorMove(deltaChars: Int) {
        val ic = currentInputConnection ?: return
        val keyCode = if (deltaChars > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
        val steps = kotlin.math.abs(deltaChars).coerceAtMost(5)
        for (i in 0 until steps) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        }
    }

    override fun onScriptSwitched(newScript: ScriptType) {
        candidateStripView.updateScriptBadge(newScript)
        // Agar foydalanuvchi so'z yozayotgan paytda 🌐 ni bossa, joriy so'zni ham yangi yozuvga o'giradi
        if (!isCurrentFieldSensitive && composingBuffer.isNotEmpty()) {
            val ic = currentInputConnection
            val currentWord = composingBuffer.toString()
            val detected = transcriptionConverter.detectScript(currentWord)
            val converted = transcriptionConverter.convert(currentWord, detected, newScript)
            if (ic != null && converted != currentWord) {
                ic.deleteSurroundingText(currentWord.length, 0)
                ic.commitText(converted, 1)
                composingBuffer.clear()
                composingBuffer.append(converted)
            }
            keyboardView.currentWordPrefix = composingBuffer.toString()
            updateContextualSuggestions(composingBuffer.toString())
        } else {
            updateDefaultSuggestions()
        }
    }

    override fun onEmojiPanelToggle() {
        candidateStripView.setSuggestions(listOf("😊 👍 ❤️", "🇺🇿 🔥 ✨", "😂 🙏 🤝"))
    }

    override fun onCandidateSelected(word: String, index: Int) {
        val ic = currentInputConnection ?: return
        clearUndoAutocorrectState()

        if (composingBuffer.isNotEmpty()) {
            ic.deleteSurroundingText(composingBuffer.length, 0)
        }
        ic.commitText("$word ", 1)
        previousCommittedWord = word
        predictiveEngine.learnCommittedWord(word, keyboardView.currentScript, isCurrentFieldSensitive)
        composingBuffer.clear()
        keyboardView.currentWordPrefix = ""
        updateDefaultSuggestions()
    }

    override fun onQuickScriptSelected(scriptType: ScriptType) {
        keyboardView.setScript(scriptType)
        onScriptSwitched(scriptType)
    }

    /**
     * Phase 5 — `⇄` tugmasi bosilganda:
     * 1. Agar foydalanuvchi matnni belgilagan bo'lsa (`getSelectedText`), o'sha matnni keyingi
     *    yozuv tizimiga to'liq kontekstli transliteratsiya qiladi (URL, raqam va emojilarni saqlagan holda).
     * 2. Agar belgilangan matn bo'lmasa, kiritish maydonidagi joriy matnni keyingi alifboga o'giradi
     *    va noaniq so'zlarning alternativ variantlarini takliflar paneliga chiqaradi.
     */
    override fun onTransliterateSelectionClicked() {
        val ic = currentInputConnection ?: return
        val targetScript = keyboardView.currentScript.next()
        keyboardView.setScript(targetScript)
        candidateStripView.updateScriptBadge(targetScript)

        if (isCurrentFieldSensitive) return

        // 1. Belgilangan matnni tekshiramiz
        val selected = ic.getSelectedText(0)?.toString()
        if (!selected.isNullOrEmpty()) {
            val result = transcriptionConverter.transliterateWithAlternatives(selected, targetScript)
            ic.commitText(result.primaryOutput, 1)
            if (result.alternatives.isNotEmpty()) {
                candidateStripView.setSuggestions(
                    listOf(result.primaryOutput) + result.alternatives.take(2)
                )
            } else {
                updateDefaultSuggestions()
            }
            return
        }

        // 2. Agar belgilangan matn bo'lmasa, butun maydon matnini o'qiymiz va transliteratsiya qilamiz
        val extracted = ic.getExtractedText(ExtractedTextRequest(), 0)?.text?.toString()
        if (!extracted.isNullOrEmpty()) {
            val result = transcriptionConverter.transliterateWithAlternatives(extracted, targetScript)
            ic.beginBatchEdit()
            ic.setSelection(0, extracted.length)
            ic.commitText(result.primaryOutput, 1)
            ic.endBatchEdit()
            composingBuffer.clear()
            keyboardView.currentWordPrefix = ""

            if (result.alternatives.isNotEmpty()) {
                candidateStripView.setSuggestions(
                    listOf(result.primaryOutput) + result.alternatives.take(2)
                )
            } else {
                updateDefaultSuggestions()
            }
        } else {
            updateDefaultSuggestions()
        }
    }

    /**
     * iPhone kabi gap boshida yoki `.`, `!`, `?`, `\n` dan keyin avtomatik ravishda `SINGLE_SHIFT` yoqadi.
     */
    private fun updateAutoCapShiftState() {
        if (!::keyboardView.isInitialized) return
        if (keyboardView.shiftState == ShiftState.CAPS_LOCK) return

        val ic = currentInputConnection
        val before = ic?.getTextBeforeCursor(3, 0)?.toString() ?: ""
        val shouldAutoCap = before.isEmpty() ||
            before.endsWith("\n") ||
            before.trimEnd().let { trimmed ->
                trimmed.isNotEmpty() && trimmed.last() in ".!?" && before.last().isWhitespace()
            }

        keyboardView.setShift(if (shouldAutoCap) ShiftState.SINGLE_SHIFT else ShiftState.UNSHIFTED)
    }

    private fun clearUndoAutocorrectState() {
        lastAutoCorrectedOriginal = null
        lastAutoCorrectedReplacement = null
    }

    private fun updateDefaultSuggestions() {
        if (!::candidateStripView.isInitialized || !::keyboardView.isInitialized) return
        if (isCurrentFieldSensitive) {
            candidateStripView.setSuggestions(listOf("", "", ""))
            return
        }
        val suggestions = predictiveEngine.getSuggestions(
            currentPrefix = "",
            previousWord = previousCommittedWord,
            scriptType = keyboardView.currentScript,
            shiftState = keyboardView.shiftState,
            maxSuggestions = 3
        )
        candidateStripView.setSuggestions(suggestions)
    }

    private fun updateContextualSuggestions(prefix: String) {
        if (isCurrentFieldSensitive || prefix.isBlank()) {
            updateDefaultSuggestions()
            return
        }
        val suggestions = predictiveEngine.getSuggestions(
            currentPrefix = prefix,
            previousWord = previousCommittedWord,
            scriptType = keyboardView.currentScript,
            shiftState = keyboardView.shiftState,
            maxSuggestions = 3
        )
        candidateStripView.setSuggestions(suggestions, typedLiteral = prefix)
    }
}
