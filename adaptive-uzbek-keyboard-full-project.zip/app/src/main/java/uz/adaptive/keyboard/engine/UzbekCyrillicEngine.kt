package uz.adaptive.keyboard.engine

import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.model.ShiftState
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.MODIFIER_TURNED_COMMA
import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.RIGHT_SINGLE_QUOTE

/**
 * 3. UzbekCyrillicEngine — O'zbek kirill alifbosi dvigateli:
 *    А Б В Г Д Е Ё Ж З И Й К Л М Н О П Р С Т У Ф Х Ц Ч Ш Ъ Ь Э Ю Я + Ў, Ғ, Қ, Ҳ.
 */
class UzbekCyrillicEngine : MultiscriptLanguageEngine {

    override val scriptType: ScriptType = ScriptType.CYRILLIC

    companion object {
        private val LATIN_VOWELS = setOf('a', 'e', 'i', 'o', 'u', 'ö', 'ў')

        // Kirillda Ц (ц) harfi bilan yoziladigan asosiy o'zlashma o'zaklar
        private val CYRILLIC_TS_ROOTS = setOf(
            "sex", "sirk", "siklon", "sivilizatsiya", "silindr", "sement", "selsiy",
            "sentner", "senariy", "senzura", "seremoniya", "sertifikat", "sessiya",
            "sitata", "sitrus", "konstitutsiya", "aksiya", "lektsiya", "leksiya",
            "funksiya", "stansiya", "politsiya", "militsiya", "operatsiya",
            "informatsiya", "transliteratsiya", "integratsiya", "motivatsiya",
            "konferensiya", "tendensiya", "provinsiya", "reaksiya", "redaksiya"
        )
    }

    override fun normalizeInput(rawText: CharSequence): String {
        if (rawText.isEmpty()) return ""
        // Kirill matnidagi o'xshash belgilarni o'zbek kirill standartiga keltirish
        val sb = StringBuilder(rawText.length)
        for (ch in rawText) {
            when (ch) {
                'ӯ' -> sb.append('ў')
                'Ӯ' -> sb.append('Ў')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    override fun toCanonicalLexiconKey(word: CharSequence): String {
        if (word.isEmpty()) return ""
        val lower = normalizeInput(word).lowercase()
        val sb = StringBuilder(lower.length + 6)

        for (i in lower.indices) {
            val ch = lower[i]
            val prev = if (i > 0) lower[i - 1] else '\u0000'
            val isStartOrAfterVowel = (i == 0) || isCyrillicVowel(prev) || prev == 'ъ' || prev == 'ь'

            when (ch) {
                'а' -> sb.append("a")
                'б' -> sb.append("b")
                'в' -> sb.append("v")
                'г' -> sb.append("g")
                'д' -> sb.append("d")
                'е' -> sb.append(if (isStartOrAfterVowel) "ye" else "e")
                'ё' -> sb.append("yo")
                'ж' -> sb.append("j")
                'з' -> sb.append("z")
                'и' -> sb.append("i")
                'й' -> sb.append("y")
                'к' -> sb.append("k")
                'л' -> sb.append("l")
                'м' -> sb.append("m")
                'н' -> sb.append("n")
                'о' -> sb.append("o")
                'п' -> sb.append("p")
                'р' -> sb.append("r")
                'с' -> sb.append("s")
                'т' -> sb.append("t")
                'у' -> sb.append("u")
                'ф' -> sb.append("f")
                'х' -> sb.append("x")
                'ц' -> sb.append(if (i > 0 && isCyrillicVowel(prev)) "ts" else "s")
                'ч' -> sb.append("ch")
                'ш', 'щ' -> sb.append("sh")
                'ъ' -> sb.append(RIGHT_SINGLE_QUOTE)
                'ь' -> {} // Yumshatish belgisi lotinda tushib qoladi (oktyabr -> oktabr)
                'э' -> sb.append("e")
                'ю' -> sb.append("yu")
                'я' -> sb.append("ya")
                'ў' -> sb.append("o").append(MODIFIER_TURNED_COMMA)
                'ғ' -> sb.append("g").append(MODIFIER_TURNED_COMMA)
                'қ' -> sb.append("q")
                'ҳ' -> sb.append("h")
                'ы' -> sb.append("i")
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    override fun fromCanonicalLexiconKey(canonicalWord: String): String {
        if (canonicalWord.isEmpty()) return ""
        val w = canonicalWord.lowercase()
        val sb = StringBuilder(w.length)
        val useInitialTs = CYRILLIC_TS_ROOTS.any { w.startsWith(it) && (it.startsWith("se") || it.startsWith("si")) }

        var i = 0
        while (i < w.length) {
            val ch = w[i]
            val next = if (i + 1 < w.length) w[i + 1] else '\u0000'
            val next2 = if (i + 2 < w.length) w[i + 2] else '\u0000'

            // 1. 3-harfli yo' / g' / o' birikmalari ustuvorligi (masalan: yo‘q -> йўқ, yo‘l -> йўл)
            if (ch == 'y' && next == 'o' && next2 == MODIFIER_TURNED_COMMA) {
                sb.append("йў")
                i += 3
                continue
            }
            if (ch == 'o' && next == MODIFIER_TURNED_COMMA) {
                sb.append('ў')
                i += 2
                continue
            }
            if (ch == 'g' && next == MODIFIER_TURNED_COMMA) {
                sb.append('ғ')
                i += 2
                continue
            }
            if (ch == 's' && next == 'h') {
                sb.append('ш')
                i += 2
                continue
            }
            if (ch == 'c' && next == 'h') {
                sb.append('ч')
                i += 2
                continue
            }
            if (ch == 't' && next == 's') {
                sb.append('ц')
                i += 2
                continue
            }
            // "siya" -> "ция" (konstitutsiya, aksiya, funksiya, operatsiya)
            if (ch == 's' && next == 'i' && next2 == 'y' && i + 3 < w.length && w[i + 3] == 'a' && i > 1) {
                sb.append("ция")
                i += 4
                continue
            }
            if (ch == 'y' && next == 'e') {
                sb.append('е')
                i += 2
                continue
            }
            if (ch == 'y' && next == 'o') {
                sb.append('ё')
                i += 2
                continue
            }
            if (ch == 'y' && next == 'u') {
                sb.append('ю')
                i += 2
                continue
            }
            if (ch == 'y' && next == 'a') {
                sb.append('я')
                i += 2
                continue
            }

            when (ch) {
                'a' -> sb.append('а')
                'b' -> sb.append('б')
                'd' -> sb.append('д')
                'e' -> {
                    val prev = if (i > 0) w[i - 1] else '\u0000'
                    if (i == 0 || prev in LATIN_VOWELS || prev == RIGHT_SINGLE_QUOTE) {
                        sb.append('э')
                    } else {
                        sb.append('е')
                    }
                }
                'f' -> sb.append('ф')
                'g' -> sb.append('г')
                'h' -> sb.append('ҳ')
                'i' -> sb.append('и')
                'j' -> sb.append('ж')
                'k' -> sb.append('к')
                'l' -> sb.append('л')
                'm' -> sb.append('м')
                'n' -> sb.append('н')
                'o' -> sb.append('о')
                'p' -> sb.append('п')
                'q' -> sb.append('қ')
                'r' -> sb.append('р')
                's' -> {
                    if (i == 0 && useInitialTs) sb.append('ц') else sb.append('с')
                }
                't' -> sb.append('т')
                'u' -> sb.append('у')
                'v' -> sb.append('в')
                'x' -> sb.append('х')
                'y' -> sb.append('й')
                'z' -> sb.append('з')
                RIGHT_SINGLE_QUOTE -> sb.append('ъ')
                else -> sb.append(ch)
            }
            i++
        }
        return sb.toString()
    }

    override fun applyCasePattern(word: String, referenceInput: String, shiftState: ShiftState): String {
        if (word.isEmpty()) return word
        if (shiftState == ShiftState.CAPS_LOCK || (referenceInput.length >= 2 && referenceInput.all { !it.isLetter() || it.isUpperCase() })) {
            return word.uppercase()
        }
        if (shiftState == ShiftState.SINGLE_SHIFT || referenceInput.firstOrNull()?.isUpperCase() == true) {
            return word.replaceFirstChar { it.uppercaseChar() }
        }
        return word
    }

    override fun isOrthographicallyValid(word: String): Boolean {
        if (word.isBlank()) return false
        for (ch in word) {
            val lower = ch.lowercaseChar()
            val valid = (lower in 'а'..'я') || lower == 'ё' || lower == 'ў' ||
                lower == 'ғ' || lower == 'қ' || lower == 'ҳ' || ch == '-'
            if (!valid) return false
        }
        return true
    }

    private fun isCyrillicVowel(ch: Char): Boolean = when (ch.lowercaseChar()) {
        'а', 'е', 'ё', 'и', 'о', 'у', 'ў', 'э', 'ю', 'я' -> true
        else -> false
    }
}
