package uz.adaptive.keyboard.util

/**
 * Amaldagi o'zbek lotin alifbosidagi apostrof variantlarini (U+0027, U+2018, U+2019, U+02BB, U+02BC, `)
 * standart Unicode shakliga keltiruvchi va kontekstli qayta ishlovchi normalizator.
 */
object UzbekUnicodeNormalizer {

    // O‘ va G‘ harflari uchun rasmiy Unicode Modifier Letter Turned Comma
    const val MODIFIER_TURNED_COMMA: Char = '\u02BB' // ʻ

    // Tutuq belgisi (ma’no, ta’lim, e’lon) uchun Right Single Quotation Mark
    const val RIGHT_SINGLE_QUOTE: Char = '\u2019' // ’

    // Foydalanuvchi kiritishi mumkin bo'lgan barcha apostrof shakllari
    val APOSTROPHE_VARIANTS: Set<Char> = setOf(
        '\u0027', // ' Standard ASCII Apostrophe
        '\u2018', // ‘ Left Single Quotation Mark
        '\u2019', // ’ Right Single Quotation Mark
        '\u02BB', // ʻ Modifier Letter Turned Comma
        '\u02BC', // ʼ Modifier Letter Apostrophe
        '\u0060', // ` Grave Accent
        '\u00B4'  // ´ Acute Accent
    )

    /**
     * Belgilar ketma-ketligidagi barcha apostrof turlarini O/o va G/g dan keyin kelganda U+02BB ga,
     * boshqa holatlarda (tutuq belgisi sifatida) U+2019 ga normalizatsiya qiladi.
     */
    fun normalizeTraditionalLatin(input: CharSequence): String {
        if (input.isEmpty()) return ""
        val sb = StringBuilder(input.length)
        for (i in input.indices) {
            val ch = input[i]
            if (ch in APOSTROPHE_VARIANTS) {
                val prev = if (i > 0) input[i - 1] else '\u0000'
                if (prev == 'O' || prev == 'o' || prev == 'G' || prev == 'g') {
                    sb.append(MODIFIER_TURNED_COMMA)
                } else {
                    sb.append(RIGHT_SINGLE_QUOTE)
                }
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Kursor oldidagi oxirgi harfga qarab Smart Apostrophe tugmasi qaysi Unicode belgini
     * kiritishi kerakligini aniqlaydi.
     */
    fun resolveSmartApostrophe(precedingChar: Char?): String {
        return if (precedingChar == 'O' || precedingChar == 'o' ||
            precedingChar == 'G' || precedingChar == 'g'
        ) {
            MODIFIER_TURNED_COMMA.toString()
        } else {
            RIGHT_SINGLE_QUOTE.toString()
        }
    }
}
