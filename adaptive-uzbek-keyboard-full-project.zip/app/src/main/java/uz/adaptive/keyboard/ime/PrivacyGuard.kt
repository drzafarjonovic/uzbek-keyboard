package uz.adaptive.keyboard.ime

import android.text.InputType
import android.view.inputmethod.EditorInfo

/**
 * Parol, PIN-kod, bank kartasi va maxfiy maydonlarni aniqlab,
 * foydalanuvchi odatlarini o'rganish va shaxsiy lug'atga yozishni bloklovchi xavfsizlik moduli.
 */
object PrivacyGuard {

    fun isSensitiveInput(editorInfo: EditorInfo?): Boolean {
        if (editorInfo == null) return false
        val inputType = editorInfo.inputType
        val cls = inputType and InputType.TYPE_MASK_CLASS
        val variation = inputType and InputType.TYPE_MASK_VARIATION

        if (cls == InputType.TYPE_CLASS_TEXT) {
            if (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            ) {
                return true
            }
        }

        if (cls == InputType.TYPE_CLASS_NUMBER &&
            variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
        ) {
            return true
        }

        // Inkognito / No Personalized Learning bayrog'ini tekshirish
        val imeOptions = editorInfo.imeOptions
        if ((imeOptions and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0) {
            return true
        }

        return false
    }
}
