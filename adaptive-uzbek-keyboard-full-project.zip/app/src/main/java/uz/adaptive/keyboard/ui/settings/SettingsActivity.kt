package uz.adaptive.keyboard.ui.settings

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import uz.adaptive.keyboard.model.ScriptType
import uz.adaptive.keyboard.ui.view.AdaptiveKeyboardView

/**
 * Klaviatura sozlamalari va Redmi Note 13 da jonli sinovdan o'tkazish oynasi.
 */
class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val density = resources.displayMetrics.density
        val pad = (20 * density).toInt()

        val rootScroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val titleView = TextView(this).apply {
            text = "Adaptive Uzbek Keyboard"
            textSize = 22f
        }
        container.addView(titleView)

        val subtitleView = TextView(this).apply {
            text = "Yangi Lotin (Ş, Ç, Ö, Ğ) • Amaldagi Lotin (O‘, G‘, Sh, Ch) • Kirill (Ў, Ғ, Қ, Ҳ)"
            textSize = 14f
            setPadding(0, (6 * density).toInt(), 0, (16 * density).toInt())
        }
        container.addView(subtitleView)

        // 1. Tizim sozlamalarida klaviaturani yoqish tugmasi
        val enableButton = Button(this).apply {
            text = "1. Tizimda klaviaturani yoqish"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }
        container.addView(enableButton)

        // 2. Klaviaturani tanlash (InputMethodPicker)
        val selectButton = Button(this).apply {
            text = "2. Asosiy klaviatura sifatida tanlash"
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        container.addView(selectButton)

        // 3. Jonli sinov maydoni (Test Sandbox)
        val testInput = EditText(this).apply {
            hint = "Shu yerga yozib uchta alifboni sinab ko‘ring..."
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
        }
        container.addView(testInput)

        // 4. Ichki interaktiv klaviatura prefabrik ko'rinishi (Ilova ichida darhol sinash uchun)
        val previewKeyboard = AdaptiveKeyboardView(this)

        val debugSwitch = Switch(this).apply {
            text = "Dynamic Hitbox chegaralarini ko‘rsatish (Debug Overlay)"
            setOnCheckedChangeListener { _, isChecked ->
                previewKeyboard.showDebugHitboxes = isChecked
            }
        }
        container.addView(debugSwitch)

        val scriptSwitchBtn = Button(this).apply {
            text = "Alifboni almashtirish: ${previewKeyboard.currentScript.displayTitle}"
            setOnClickListener {
                val next = previewKeyboard.currentScript.next()
                previewKeyboard.setScript(next)
                text = "Alifboni almashtirish: ${next.displayTitle}"
            }
        }
        container.addView(scriptSwitchBtn)

        previewKeyboard.actionListener = object : AdaptiveKeyboardView.KeyboardActionListener {
            override fun onTextCommit(text: String) {
                testInput.append(text)
            }
            override fun onSmartApostrophe() {
                testInput.append("ʻ")
            }
            override fun onBackspace(deleteWholeWord: Boolean) {
                val editable = testInput.text
                if (editable.isNotEmpty()) {
                    editable.delete(editable.length - 1, editable.length)
                }
            }
            override fun onEnter() {
                testInput.append("\n")
            }
            override fun onSpace() {
                testInput.append(" ")
            }
            override fun onCursorMove(deltaChars: Int) {
                val pos = (testInput.selectionStart + deltaChars).coerceIn(0, testInput.length())
                testInput.setSelection(pos)
            }
            override fun onScriptSwitched(newScript: ScriptType) {
                scriptSwitchBtn.text = "Alifboni almashtirish: ${newScript.displayTitle}"
            }
            override fun onEmojiPanelToggle() {
                testInput.append("🇺🇿")
            }
        }

        container.addView(
            previewKeyboard,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        rootScroll.addView(container)
        setContentView(rootScroll)
    }
}
