package uz.adaptive.keyboard.nlp

import android.content.Context
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

/**
 * Foydalanuvchi taqdim etgan `soz-ustasi.html` faylidagi 100 816 ta o'zbekcha so'z bazasini
 * (`uz_canonical_dawg.bin` yoki `uz_lexicon_100k.txt`) tezkor 2-harfli prefiks savatchalariga
 * (Prefix Bucket Index) yuklab, Redmi Note 13 da < 0.35 ms ichida qidirib beruvchi repozitoriy.
 */
class SozUstasiDictionaryRepository {

    // 2-harfli kanonik prefiks -> alifbo tartibidagi so'zlar ro'yxati
    private val prefixBuckets = HashMap<String, ArrayList<String>>(1024)
    private val exactWordSet = HashSet<String>(110_000)

    var totalLoadedWords: Int = 0
        private set

    /**
     * Android assets/dict/uz_canonical_dawg.bin (Front-Coded DAWG) dan yuklash.
     */
    fun loadFromAndroidAssets(context: Context) {
        if (totalLoadedWords > 0) return
        try {
            context.assets.open("dict/uz_canonical_dawg.bin").use { stream ->
                loadFromFrontCodedBinaryStream(stream)
            }
        } catch (_: Exception) {
            try {
                context.assets.open("dict/uz_lexicon_100k.txt").use { stream ->
                    loadFromPlainTextStream(stream)
                }
            } catch (_: Exception) {
                loadFallbackCoreWords()
            }
        }
    }

    /**
     * Front-Coded Binary DAWG (`uz_canonical_dawg.bin`) oqimini dekodlash.
     */
    fun loadFromFrontCodedBinaryStream(inputStream: InputStream) {
        val bytes = inputStream.readBytes()
        if (bytes.size < 12) return
        val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val m0 = buf.get().toInt().toChar()
        val m1 = buf.get().toInt().toChar()
        val m2 = buf.get().toInt().toChar()
        val m3 = buf.get().toInt().toChar()
        if ("$m0$m1$m2$m3" != "UZDW") return

        val version = buf.int
        val count = buf.int
        if (version != 1 || count <= 0) return

        var prevBytes = ByteArray(0)
        for (i in 0 until count) {
            if (!buf.hasRemaining()) break
            val commonLen = buf.get().toInt() and 0xFF
            val suffixLen = buf.get().toInt() and 0xFF
            val wordBytes = ByteArray(commonLen + suffixLen)
            if (commonLen > 0) {
                System.arraycopy(prevBytes, 0, wordBytes, 0, commonLen)
            }
            buf.get(wordBytes, commonLen, suffixLen)
            val word = String(wordBytes, Charsets.UTF_8)
            indexCanonicalWord(word)
            prevBytes = wordBytes
        }
    }

    /**
     * Oddiy matnli oqimdan (`uz_lexicon_100k.txt` — JUnit testlar yoki zahira uchun) yuklash.
     */
    fun loadFromPlainTextStream(inputStream: InputStream) {
        BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).useLines { lines ->
            lines.forEach { line ->
                val w = line.trim()
                if (w.length >= 2) {
                    indexCanonicalWord(w)
                }
            }
        }
    }

    fun indexCanonicalWord(canonicalWord: String) {
        if (exactWordSet.add(canonicalWord)) {
            totalLoadedWords++
            val bucketKey = bucketKeyFor(canonicalWord)
            val list = prefixBuckets.getOrPut(bucketKey) { ArrayList(64) }
            list.add(canonicalWord)
        }
    }

    fun containsCanonicalWord(canonicalWord: String): Boolean {
        return exactWordSet.contains(canonicalWord)
    }

    /**
     * Kanonik prefiks bo'yicha eng mos keladigan lug'at so'zlarini qaytaradi.
     * Qisqaroq va kundalik nutqda ko'p ishlatiladigan o'zak so'zlar yuqoriroq ball oladi.
     */
    fun queryPrefixMatches(
        canonicalPrefix: String,
        maxResults: Int = 8
    ): List<String> {
        if (canonicalPrefix.isBlank()) return emptyList()
        val key = bucketKeyFor(canonicalPrefix)
        val bucket = prefixBuckets[key] ?: return emptyList()

        val matches = ArrayList<String>(maxResults * 2)
        // Binary search orqali prefiks boshlanadigan joyni topamiz
        var low = 0
        var high = bucket.size - 1
        var startIdx = 0
        while (low <= high) {
            val mid = (low + high) ushr 1
            val cmp = bucket[mid].compareTo(canonicalPrefix)
            if (cmp < 0) {
                low = mid + 1
                startIdx = low
            } else {
                high = mid - 1
                startIdx = mid
            }
        }

        for (i in startIdx until bucket.size) {
            val candidate = bucket[i]
            if (!candidate.startsWith(canonicalPrefix)) {
                if (candidate > canonicalPrefix) break
                continue
            }
            matches.add(candidate)
            if (matches.size >= 48) break
        }

        // Uzunligi prefiksga eng yaqin bo'lgan asosiy so'zlarni birinchi o'ringa saralash
        return matches.sortedWith(
            compareBy<String> { it != canonicalPrefix }
                .thenBy { abs(it.length - (canonicalPrefix.length + 2)) }
                .thenBy { it }
        ).take(maxResults)
    }

    /**
     * SpellChecker uchun 2-harfli prefiks savatchasidagi nomzodlarni qaytaradi.
     */
    fun getCandidatesInBucket(twoCharPrefix: String): List<String> {
        return prefixBuckets[bucketKeyFor(twoCharPrefix)] ?: emptyList()
    }

    private fun bucketKeyFor(word: String): String {
        return if (word.length >= 2) word.substring(0, 2) else word.take(1)
    }

    private fun loadFallbackCoreWords() {
        val core = listOf(
            "assalomu", "alaykum", "oʻzbekiston", "oʻzbek", "gʻalaba", "shahar",
            "chiroyli", "kitob", "maktab", "dastur", "klaviatura", "yangiqoʻrgʻon",
            "namangan", "toshkent", "stomatolog", "shifokor", "salomatlik"
        )
        for (w in core) indexCanonicalWord(w)
    }
}
