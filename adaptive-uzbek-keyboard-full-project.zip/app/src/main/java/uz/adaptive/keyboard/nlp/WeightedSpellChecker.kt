package uz.adaptive.keyboard.nlp

import uz.adaptive.keyboard.util.UzbekUnicodeNormalizer.MODIFIER_TURNED_COMMA
import kotlin.math.min

/**
 * Fizik tugma qo'shniligi va o'zbekcha fonetik yaqinlik og'irliklariga asoslangan
 * Damerau-Levenshtein avtotuzatish (Autocorrect) moduli.
 */
class WeightedSpellChecker(
    private val dictionary: SozUstasiDictionaryRepository,
    private val morphologyAnalyzer: UzbekMorphologyAnalyzer
) {

    companion object {
        private val oMod = "o$MODIFIER_TURNED_COMMA"
        private val gMod = "g$MODIFIER_TURNED_COMMA"

        // QWERTY klaviaturasidagi qo'shni harflar va o'zbek tilida ko'p adashtiriladigan fonetik juftliklar
        private val LOW_COST_PAIRS: Set<Pair<Char, Char>> = buildSet {
            val groups = listOf(
                "qw", "we", "er", "rt", "ty", "yu", "ui", "io", "op",
                "as", "sd", "df", "fg", "gh", "hj", "jk", "kl",
                "zx", "xc", "cv", "vb", "bn", "nm",
                "xh", "qk", "gc", "sz", "dt", "bp", "ou", "ie", "ea"
            )
            for (g in groups) {
                add(Pair(g[0], g[1]))
                add(Pair(g[1], g[0]))
            }
        }
    }

    /**
     * Kiritilgan kanonik so'zda imlo xatosi bo'lsa, eng yaqin to'g'ri variantlarni topadi.
     */
    fun suggestCorrections(canonicalInput: String, maxSuggestions: Int = 3): List<String> {
        if (canonicalInput.length < 3) return emptyList()
        if (morphologyAnalyzer.analyze(canonicalInput).isValidWord) {
            return listOf(canonicalInput)
        }

        val candidates = LinkedHashSet<String>()

        // 1. Eng ko'p uchraydigan o'/o va g'/g hamda x/h almashinuvlarini darhol tekshiramiz
        val phoneticVariants = generatePhoneticVariants(canonicalInput)
        for (variant in phoneticVariants) {
            if (morphologyAnalyzer.analyze(variant).isValidWord) {
                candidates.add(variant)
                if (candidates.size >= maxSuggestions) return candidates.toList()
            }
        }

        // 2. 2-harfli prefiks savatchasidan Weighted Damerau-Levenshtein bo'yicha eng yaqin so'zlarni qidiramiz
        val bucketWords = dictionary.getCandidatesInBucket(canonicalInput.take(2))
        val scored = ArrayList<Pair<String, Float>>()

        for (word in bucketWords) {
            if (kotlin.math.abs(word.length - canonicalInput.length) > 2) continue
            val dist = computeWeightedDistance(canonicalInput, word)
            if (dist <= 1.65f) {
                scored.add(Pair(word, dist))
            }
        }

        scored.sortBy { it.second }
        for ((w, _) in scored) {
            candidates.add(w)
            if (candidates.size >= maxSuggestions) break
        }

        return candidates.toList()
    }

    private fun generatePhoneticVariants(input: String): List<String> {
        val out = ArrayList<String>(8)
        if (input.contains("o") && !input.contains(oMod)) {
            out.add(input.replaceFirst("o", oMod))
        }
        if (input.contains(oMod)) {
            out.add(input.replaceFirst(oMod, "o"))
        }
        if (input.contains("g") && !input.contains(gMod)) {
            out.add(input.replaceFirst("g", gMod))
        }
        if (input.contains("x")) {
            out.add(input.replaceFirst("x", "h"))
        }
        if (input.contains("h")) {
            out.add(input.replaceFirst("h", "x"))
        }
        if (input.contains("q")) {
            out.add(input.replaceFirst("q", "k"))
        }
        return out
    }

    /**
     * Vaznli Damerau-Levenshtein masofasi:
     * - Qo'shni tugma yoki fonetik juftlik (x/h, q/k, o/o') uchun jarima: 0.45f
     * - Harf tushib qolishi yoki ortiqcha harf: 0.90f
     * - Qo'shni harflar o'rin almashishi (transposition): 0.55f
     */
    fun computeWeightedDistance(a: String, b: String): Float {
        val n = a.length
        val m = b.length
        if (n == 0) return m.toFloat()
        if (m == 0) return n.toFloat()

        val dp = Array(n + 1) { FloatArray(m + 1) }
        for (i in 0..n) dp[i][0] = i * 0.9f
        for (j in 0..m) dp[0][j] = j * 0.9f

        for (i in 1..n) {
            for (j in 1..m) {
                val ca = a[i - 1]
                val cb = b[j - 1]
                val subCost = when {
                    ca == cb -> 0f
                    ca == MODIFIER_TURNED_COMMA || cb == MODIFIER_TURNED_COMMA -> 0.35f
                    Pair(ca, cb) in LOW_COST_PAIRS -> 0.45f
                    else -> 1.0f
                }

                var best = min(
                    min(dp[i - 1][j] + 0.9f, dp[i][j - 1] + 0.9f),
                    dp[i - 1][j - 1] + subCost
                )

                // Transposition (ikki qo'shni harf o'rin almashib qolishi)
                if (i > 1 && j > 1 && ca == b[j - 2] && a[i - 2] == cb) {
                    best = min(best, dp[i - 2][j - 2] + 0.55f)
                }
                dp[i][j] = best
            }
        }
        return dp[n][m]
    }
}
